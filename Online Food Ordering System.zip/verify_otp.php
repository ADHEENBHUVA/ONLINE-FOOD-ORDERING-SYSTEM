<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// Safety gate
if (!isset($_SESSION['reset_email']) || !isset($_SESSION['reset_otp'])) {
    header("Location: forgot_password.php");
    exit();
}

$error = "";

if (isset($_POST['verify_otp'])) {
    $entered_otp = preg_replace("/[^0-9]/", "", $_POST['otp1'] . $_POST['otp2'] . $_POST['otp3'] . $_POST['otp4'] . $_POST['otp5'] . $_POST['otp6']);

    if ($entered_otp == $_SESSION['reset_otp']) {
        // Validation Passed! Set a new marker indicating authorization
        $_SESSION['reset_authorized'] = true;
        header("Location: reset_password.php");
        exit();
    } else {
        $error = "Unauthorized. The token is invalid or has expired.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Token Verification | TastyBytes Premium</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; overflow: hidden; }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 100% 0%, rgba(249, 115, 22, 0.15) 0, transparent 50%), radial-gradient(at 0% 100%, rgba(15, 23, 42, 1) 0, transparent 50%); }
        .otp-input { width: 3.5rem; height: 4rem; text-align: center; font-size: 1.5rem; font-weight: 800; background: rgba(15, 23, 42, 0.8); border: 2px solid #1e293b; color: white; border-radius: 1rem; transition: 0.3s; outline: none; }
        .otp-input:focus { border-color: #f97316; box-shadow: 0 0 15px rgba(249, 115, 22, 0.2); transform: translateY(-2px); }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade { animation: fadeIn 0.6s ease-out forwards; }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex items-center justify-center relative">

    <div class="mesh-bg"></div>

    <div class="w-full max-w-lg p-8 md:p-12 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[3rem] shadow-2xl relative z-10 animate-fade mx-4">

        <div class="flex justify-center mb-8">
            <div class="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(16,185,129,0.2)]">
                <i class="fas fa-shield-cat text-4xl text-emerald-500"></i>
            </div>
        </div>

        <div class="text-center mb-10">
            <h1 class="text-3xl font-800 text-white mb-3 tracking-tight">Enter Secure Token</h1>
            <p class="text-slate-400 text-sm leading-relaxed px-4">An authorization sequence has been dispatched to <br><span class="font-bold text-white"><?php echo $_SESSION['reset_email']; ?></span></p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-2xl mb-8 flex items-center gap-3 animate-fade">
                <i class="fas fa-exclamation-triangle text-lg text-red-500"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="flex justify-center gap-2 sm:gap-4 mb-8">
                <input type="text" name="otp1" maxlength="1" class="otp-input" required autofocus oninput="moveToNext(this, 'otp2')">
                <input type="text" name="otp2" maxlength="1" id="otp2" class="otp-input" required oninput="moveToNext(this, 'otp3')" onkeydown="moveToPrev(event, this, 'otp1')">
                <input type="text" name="otp3" maxlength="1" id="otp3" class="otp-input" required oninput="moveToNext(this, 'otp4')" onkeydown="moveToPrev(event, this, 'otp2')">
                <input type="text" name="otp4" maxlength="1" id="otp4" class="otp-input" required oninput="moveToNext(this, 'otp5')" onkeydown="moveToPrev(event, this, 'otp3')">
                <input type="text" name="otp5" maxlength="1" id="otp5" class="otp-input" required oninput="moveToNext(this, 'otp6')" onkeydown="moveToPrev(event, this, 'otp4')">
                <input type="text" name="otp6" maxlength="1" id="otp6" class="otp-input" required onkeydown="moveToPrev(event, this, 'otp5')">
            </div>

            <button type="submit" name="verify_otp"
                    class="w-full bg-orange-500 hover:bg-orange-600 text-white font-900 py-5 rounded-2xl shadow-xl shadow-orange-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 active:scale-[0.98]">
                Unlock Subsystem <i class="fas fa-unlock"></i>
            </button>
        </form>

        <div class="mt-8 text-center text-xs font-bold text-slate-500">
            <span class="mr-2">Did not receive it?</span>
            <a href="forgot_password.php" class="text-orange-500 hover:text-orange-400 transition-colors">Resend Code</a>
        </div>
    </div>

    <script>
        function moveToNext(current, nextFieldID) {
            // Strips non-numeric
            current.value = current.value.replace(/[^0-9]/g, '');
            if (current.value.length === 1) {
                document.getElementById(nextFieldID).focus();
            }
        }

        function moveToPrev(event, current, prevFieldID) {
            if (event.key === "Backspace" && current.value === "") {
                document.getElementById(prevFieldID).focus();
            }
        }
    </script>
</body>
</html>