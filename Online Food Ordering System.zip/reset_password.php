<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// Safety gate
if (!isset($_SESSION['reset_authorized']) || $_SESSION['reset_authorized'] !== true) {
    header("Location: login.php");
    exit();
}

$error = "";
$success = "";

if (isset($_POST['reset_secure'])) {
    $password = $_POST['npass'];
    $confirm  = $_POST['cpass'];

    // Front-line Check
    if ($password !== $confirm) {
        $error = "Mismatch Error: Security keys do not strongly mirror each other.";
    } else {
        // Strict Validation (Matching login.php logic)
        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';

        if (!preg_match($pattern, $password)) {
            $error = "Violation: Key must be 8-16 chars with Upper, Lower, Number & Special Char.";
        } else {
            // Apply Update
            $email = $_SESSION['reset_email'];
            $stmt = $conn->prepare("UPDATE customers SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $password, $email);

            if ($stmt->execute()) {
                // Clear Security Session Data completely
                unset($_SESSION['reset_email'], $_SESSION['reset_otp'], $_SESSION['reset_id'], $_SESSION['reset_authorized']);

                $success = "Success! Authentication array overwritten. Proceed to terminal.";
                echo "<script>
                    setTimeout(function(){ window.location.href = 'login.php'; }, 2000);
                </script>";
            } else {
                $error = "Critical System Error executing update protocol.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forge Key | TastyBytes Premium</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; overflow: hidden; }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 100% 0%, rgba(249, 115, 22, 0.15) 0, transparent 50%), radial-gradient(at 0% 100%, rgba(15, 23, 42, 1) 0, transparent 50%); }
        .input-focus:focus { box-shadow: 0 0 0 2px #f97316; border-color: #f97316; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade { animation: fadeIn 0.6s ease-out forwards; }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex items-center justify-center relative">

    <div class="mesh-bg"></div>

    <div class="w-full max-w-md p-8 md:p-12 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[2.5rem] shadow-2xl relative z-10 animate-fade mx-4">

        <div class="flex justify-center mb-8">
            <div class="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(59,130,246,0.2)]">
                <i class="fas fa-hammer text-3xl text-blue-500"></i>
            </div>
        </div>

        <div class="text-center mb-10">
            <h1 class="text-3xl font-800 text-white mb-3 tracking-tight">Forge New Key</h1>
            <p class="text-slate-400 text-sm leading-relaxed px-4">Create your new access authorization. Make it robust.</p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-2xl mb-8 flex items-center gap-3 animate-fade">
                <i class="fas fa-triangle-exclamation text-lg"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest leading-relaxed"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <?php if($success != ""): ?>
            <div class="bg-emerald-500/10 border border-emerald-500/50 text-emerald-400 p-4 rounded-2xl mb-8 flex items-center gap-3 animate-fade">
                <i class="fas fa-check-double text-lg"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest leading-relaxed"><?php echo $success; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="space-y-6" onsubmit="return validatePassword();">

            <div>
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 ml-1">New Core Key</label>
                <div class="relative group">
                    <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                    <input type="password" name="npass" id="npass" required placeholder="••••••••"
                           class="w-full bg-slate-950/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-12 text-white outline-none input-focus transition-all">
                    <button type="button" onclick="toggleVisibility('npass', 'eye1')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-orange-500 transition-colors focus:outline-none">
                        <i id="eye1" class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div>
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 ml-1">Verify Symmetry</label>
                <div class="relative group">
                    <i class="fas fa-lock-open absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                    <input type="password" name="cpass" id="cpass" required placeholder="••••••••"
                           class="w-full bg-slate-950/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-12 text-white outline-none input-focus transition-all">
                    <button type="button" onclick="toggleVisibility('cpass', 'eye2')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-orange-500 transition-colors focus:outline-none">
                        <i id="eye2" class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div class="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                <p class="text-[9px] text-slate-500 font-bold uppercase tracking-widest leading-relaxed">
                    <i class="fas fa-circle-info text-orange-500 mr-1"></i> Policy: 8-16 chars, include A, a, 1, and @$!%*?&
                </p>
            </div>

            <button type="submit" name="reset_secure"
                    <?php if($success != "") echo 'disabled'; ?>
                    class="w-full bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white font-900 py-4 rounded-2xl shadow-xl shadow-orange-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 active:scale-[0.98]">
                Commit Override <i class="fas fa-upload"></i>
            </button>
        </form>

    </div>

    <script>
        function toggleVisibility(inputId, iconId) {
            const passInput = document.getElementById(inputId);
            const eyeIcon = document.getElementById(iconId);
            if (passInput.type === "password") {
                passInput.type = "text";
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            } else {
                passInput.type = "password";
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            }
        }

        function validatePassword() {
            const p1 = document.getElementById('npass').value;
            const p2 = document.getElementById('cpass').value;
            if(p1 !== p2){
                alert("Keys do not match!"); return false;
            }
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
            if (!regex.test(p1)) {
                alert("Security Violation: Your password must be 8-16 characters and contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>