<?php
if (session_status() == PHP_SESSION_NONE) {
    session_set_cookie_params(86400 * 30);
session_start();
}

// Clear and Destroy Session
unset($_SESSION['customer_id']);
unset($_SESSION['customer_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logged Out | TastyBytes</title>
    <meta http-equiv="refresh" content="5;url=login.php">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --bg: #f8fafc;
            --text-main: #1e293b;
            --text-muted: #64748b;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: var(--text-main);
        }

        .logout-card {
            background: #ffffff;
            padding: 3rem 2rem;
            width: 100%;
            max-width: 400px;
            border-radius: 28px;
            text-align: center;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
            animation: slideUp 0.6s ease-out;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .icon-circle {
            width: 80px;
            height: 80px;
            background: #f0fdf4;
            color: #22c55e;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 1.5rem auto;
            font-size: 2rem;
        }

        h2 {
            margin: 0 0 0.5rem 0;
            font-size: 1.5rem;
            font-weight: 700;
        }

        p {
            color: var(--text-muted);
            font-size: 1rem;
            margin-bottom: 2rem;
            line-height: 1.5;
        }

        .login-link {
            display: inline-block;
            background: var(--primary);
            color: white;
            text-decoration: none;
            padding: 12px 30px;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2);
        }

        .login-link:hover {
            background: #4338ca;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(79, 70, 229, 0.3);
        }

        .redirect-text {
            margin-top: 1.5rem;
            font-size: 0.8rem;
            color: #94a3b8;
        }
    </style>
</head>
<body>

<div class="logout-card">
    <div class="icon-circle">
        ✓
    </div>
    <h2>Logged Out</h2>
    <p>You have been successfully logged out. <br> Thank you for using TastyBytes!</p>

    <a href="login.php" class="login-link">Login Again</a>

    <div class="redirect-text">
        Redirecting to login in <span id="timer">5</span> seconds...
    </div>
</div>

<script>
    // Simple countdown timer logic
    let seconds = 5;
    const timerElement = document.getElementById('timer');
    const countdown = setInterval(() => {
        seconds--;
        timerElement.textContent = seconds;
        if (seconds <= 0) clearInterval(countdown);
    }, 1000);
</script>

</body>
</html>