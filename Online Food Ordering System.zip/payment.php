<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// Check if cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: index.php");
    exit();
}

$order_placed = false;

if (isset($_POST['place_order'])) {
    $customer_name = mysqli_real_escape_string($conn, $_POST['name']);
    if (!preg_match('/^[a-zA-Z\s]+$/', $customer_name)) {
        echo "<script>alert('Invalid name! Only alphabets and spaces are allowed.'); window.history.back();</script>";
        exit();
    }
    $customer_phone = mysqli_real_escape_string($conn, $_POST['phone']);
    if (!preg_match('/^[0-9]{10}$/', $customer_phone)) {
        echo "<script>alert('Invalid phone number! Please enter exactly 10 digits.'); window.history.back();</script>";
        exit();
    }
    $customer_address = mysqli_real_escape_string($conn, $_POST['address']);
    $payment_method = $_POST['payment_method'];

    foreach ($_SESSION['cart'] as $item) {
        $food_id = $item['food_id']; // Adjusted to match your previous cart key
        $food_name = $item['food_name'];
        $price = $item['price'];
        $quantity = $item['quantity'];
        $total = $price * $quantity;

        $sql = "INSERT INTO orders
        (food_id, food_name, price, quantity, total, customer_name, customer_phone, customer_address, payment_method, order_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isdiissss", $food_id, $food_name, $price, $quantity, $total, $customer_name, $customer_phone, $customer_address, $payment_method);
        $stmt->execute();
    }

    unset($_SESSION['cart']);
    $order_placed = true;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Checkout | FOODIE'S HEAVEN Restaurant</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #ff6b6b;
            --dark: #2d3436;
            --bg: #f8f9fa;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--bg);
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
        }

        .checkout-grid {
            display: grid;
            grid-template-columns: 1.2fr 0.8fr;
            gap: 30px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        }

        h2 {
            margin-top: 0;
            color: var(--dark);
            border-bottom: 2px solid #f1f1f1;
            padding-bottom: 10px;
        }

        /* Form Styling */
        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-sizing: border-box;
            font-family: inherit;
        }

        input:focus {
            border-color: var(--primary);
            outline: none;
        }

        .btn-place {
            background: var(--primary);
            color: white;
            border: none;
            padding: 15px;
            width: 100%;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-place:hover {
            background: #ee5253;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.3);
        }

        /* Success Message Styling */
        .success-view {
            text-align: center;
            padding: 50px;
        }

        .success-view i {
            font-size: 80px;
            color: #2ecc71;
            margin-bottom: 20px;
        }

        .order-item-mini {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            margin-bottom: 10px;
            color: #666;
        }

        .total-row {
            border-top: 2px dashed #eee;
            padding-top: 15px;
            margin-top: 15px;
            font-weight: 600;
            font-size: 1.2rem;
            display: flex;
            justify-content: space-between;
            color: var(--primary);
        }

        @media (max-width: 768px) {
            .checkout-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

    <div class="container">
        <?php if (!$order_placed): ?>
            <div class="checkout-grid">
                <div class="card">
                    <h2><i class="fas fa-truck"></i> Delivery Details</h2>
                    <form method="POST">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="name" placeholder="Enter your name" required oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');">
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="tel" name="phone" placeholder="Enter phone number" required maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                        </div>
                        <div class="form-group">
                            <label>Delivery Address</label>
                            <textarea name="address" rows="3" placeholder="Full address..." required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Payment Method</label>
                            <select name="payment_method">
                                <option value="UPI">UPI / QR Scan</option>
                                <option value="Card">Credit/Debit Card</option>
                            </select>
                        </div>
                        <button type="submit" name="place_order" class="btn-place">Confirm Order</button>
                    </form>
                </div>

                <div class="card" style="height: fit-content;">
                    <h2>Summary</h2>
                    <?php
                    $grand_total = 0;
                    foreach ($_SESSION['cart'] as $item):
                        $subtotal = $item['price'] * $item['quantity'];
                        $grand_total += $subtotal;
                        ?>
                        <div class="order-item-mini">
                            <span><?php echo $item['quantity']; ?>x <?php echo $item['food_name']; ?></span>
                            <span>&#8377;<?php echo number_format($subtotal, 2); ?></span>
                        </div>
                    <?php endforeach; ?>
                    <div class="total-row">
                        <span>Total</span>
                        <span>&#8377;<?php echo number_format($grand_total, 2); ?></span>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <div class="card success-view">
                <i class="fas fa-check-circle"></i>
                <h1>Order Confirmed!</h1>
                <p>Thank you, <strong><?php echo htmlspecialchars($customer_name); ?></strong>. Your delicious meal is being
                    prepared and will be delivered to your address soon.</p>
                <br>
                <a href="index.php" class="btn-place"
                    style="text-decoration: none; display: inline-block; width: auto; padding: 12px 30px;">Order More
                    Food</a>
            </div>
        <?php endif; ?>
    </div>

</body>

</html>