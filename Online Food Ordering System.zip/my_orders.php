<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// 1. SECURITY: Check if customer is logged in
if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];

// 2. DATA: Get all orders for this specific customer
$order_query = "SELECT * FROM orders
                WHERE customer_id='$customer_id'
                ORDER BY order_id DESC";

$order_result = mysqli_query($conn, $order_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="15"> <!-- Auto refresh every 15 seconds for live tracking -->
    <title>Live Tracking | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f8fafc;
        }

        .glass-nav {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .smooth-btn {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .smooth-btn:active {
            transform: scale(0.97);
        }

        .order-card {
            background: white;
            border: 1px solid rgba(226, 232, 240, 0.8);
            border-radius: 2rem;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
        }

        .order-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 25px 35px -5px rgba(0, 0, 0, 0.1);
            border-color: rgba(249, 115, 22, 0.3);
        }

        /* Timeline specific CSS */
        .timeline-container {
            position: relative;
            padding: 2rem 0;
        }

        .timeline-line {
            position: absolute;
            top: 3rem;
            left: 10%;
            right: 10%;
            height: 4px;
            background: #e2e8f0;
            z-index: 1;
            border-radius: 2px;
        }

        .timeline-progress {
            position: absolute;
            top: 3rem;
            left: 10%;
            height: 4px;
            background: #f97316;
            z-index: 2;
            border-radius: 2px;
            transition: width 1s ease-in-out;
        }

        .timeline-step {
            position: relative;
            z-index: 3;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .timeline-icon {
            width: 3rem;
            height: 3rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            font-weight: bold;
            background: white;
            border: 4px solid #e2e8f0;
            color: #94a3b8;
            transition: all 0.5s ease;
            box-shadow: 0 0 0 4px white;
            margin: 0 auto;
        }

        .timeline-step.active .timeline-icon {
            border-color: #f97316;
            background: #f97316;
            color: white;
            box-shadow: 0 10px 15px -3px rgba(249, 115, 22, 0.3), 0 0 0 4px white;
        }

        .timeline-step.completed .timeline-icon {
            border-color: #f97316;
            background: white;
            color: #f97316;
        }

        .timeline-step.completed p.title {
            color: #64748b;
            font-weight: 700;
        }

        .timeline-step.active p.title {
            color: #f97316 !important;
            font-weight: 900 !important;
        }

        .timeline-step:not(.active):not(.completed) p.title {
            color: #cbd5e1;
            font-weight: 600;
        }

        .timeline-step.pulse .timeline-icon {
            animation: pulsing 2s infinite;
        }

        @keyframes pulsing {
            0% {
                box-shadow: 0 0 0 0 rgba(249, 115, 22, 0.4), 0 0 0 4px white;
            }

            70% {
                box-shadow: 0 0 0 15px rgba(249, 115, 22, 0), 0 0 0 4px white;
            }

            100% {
                box-shadow: 0 0 0 0 rgba(249, 115, 22, 0), 0 0 0 4px white;
            }
        }
    </style>
</head>

<body class="pt-32 pb-20 min-h-screen">

    <nav class="glass-nav fixed w-full top-0 z-50 py-4 px-6 md:px-12">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <!-- Logo -->
            <a href="index.php" class="flex items-center gap-3 group">
                <div
                    class="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:bg-orange-600 transition-colors">
                    <i class="fas fa-leaf text-white text-lg"></i>
                </div>
                <span class="text-xl font-900 tracking-tighter text-slate-900">Foodie's <span
                        class="text-orange-500 italic">Heaven.</span></span>
            </a>
            <a href="profile.php"
                class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-5 py-2.5 rounded-full font-bold text-sm smooth-btn flex items-center gap-2">
                <i class="fas fa-user-circle text-lg"></i> Account Console
            </a>
        </div>
    </nav>

    <div class="max-w-5xl mx-auto px-4 md:px-8">
        <div class="mb-12 text-center md:text-left">
            <h1 class="text-4xl md:text-5xl font-900 tracking-tighter uppercase italic text-slate-900">Live <span
                    class="text-orange-500">Tracking.</span></h1>
            <p class="text-slate-500 font-medium mt-2 tracking-wide">Monitor your premium orders via our GPS delivery
                grid.</p>
        </div>

        <?php if (mysqli_num_rows($order_result) == 0): ?>
            <div class="order-card p-16 text-center">
                <div
                    class="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-300">
                    <i class="fas fa-satellite-dish text-4xl"></i>
                </div>
                <h3 class="text-3xl font-900 text-slate-800 tracking-tight">Radar Empty</h3>
                <p class="text-slate-400 font-medium mt-2 mb-8 text-lg">No active gourmet operations detected.</p>
                <a href="index.php#menu-section"
                    class="inline-flex items-center gap-2 bg-orange-500 hover:bg-slate-900 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-sm smooth-btn shadow-xl shadow-orange-500/20 transition-all border border-orange-400">
                    Initate Order
                </a>
            </div>
        <?php else: ?>
            <div class="space-y-12">
                <?php while ($order = mysqli_fetch_assoc($order_result)):
                    $status = strtolower($order['order_status']);
                    $cancelled = false;

                    // Map status to step index [1: Placed, 2: Kitchen, 3: On Way, 4: Delivered]
                    $step = 1;
                    $progress_width = '0%';

                    if ($status == 'pending') {
                        $step = 1;
                        $progress_width = '0%';
                    } elseif ($status == 'preparing') {
                        $step = 2;
                        $progress_width = '33%';
                    } elseif ($status == 'out for delivery' || $status == 'in transit') {
                        $step = 3;
                        $progress_width = '66%';
                    } elseif ($status == 'delivered') {
                        $step = 4;
                        $progress_width = '100%';
                    } elseif ($status == 'cancelled') {
                        $step = 0;
                        $cancelled = true;
                    }
                    ?>
                    <div class="order-card relative overflow-hidden group">

                        <?php if ($cancelled): ?>
                            <!-- Cancelled Banner Overlay -->
                            <div class="absolute top-0 left-0 w-full h-2 bg-rose-500 z-10"></div>
                        <?php else: ?>
                            <div class="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-400 to-rose-500 z-10"></div>
                        <?php endif; ?>

                        <div class="p-6 md:p-8">
                            <!-- Top Summary Row -->
                            <div
                                class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-6 mb-4">
                                <div class="flex items-center gap-4">
                                    <div
                                        class="w-14 h-14 bg-slate-50 rounded-[1rem] flex items-center justify-center text-slate-400 border border-slate-100 shadow-inner">
                                        <i class="fas fa-receipt text-2xl"></i>
                                    </div>
                                    <div>
                                        <div class="flex items-center gap-3 mb-1">
                                            <h3 class="text-2xl font-900 text-slate-900 tracking-tight leading-none">Gourmet Order</h3>
                                            <?php
                                            $badge_color = 'bg-amber-100 text-amber-700 border-amber-200';
                                            if ($status == 'out for delivery' || $status == 'in transit')
                                                $badge_color = 'bg-orange-100 text-orange-600 border-orange-200';
                                            if ($status == 'delivered')
                                                $badge_color = 'bg-emerald-100 text-emerald-600 border-emerald-200';
                                            ?>
                                            <span
                                                class="px-2.5 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest border <?= $badge_color ?>"><?= $order['order_status'] ?></span>
                                        </div>
                                        <p
                                            class="text-slate-400 font-bold text-xs uppercase tracking-widest flex items-center gap-2 mt-1">
                                            <i class="far fa-clock text-orange-500"></i>
                                            <?= date('d M Y, h:i A', strtotime($order['order_date'])) ?>
                                        </p>
                                    </div>
                                </div>
                                <div
                                    class="text-left md:text-right bg-slate-50 px-5 py-3 rounded-[1rem] border border-slate-100">
                                    <p class="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-0.5">Amount
                                        Settled</p>
                                    <h4 class="text-2xl font-900 text-slate-900 tracking-tighter leading-none">
                                        &#8377;<?= number_format($order['total_amount'], 2) ?></h4>
                                </div>
                            </div>

                            <!-- Visual Timeline Area -->
                            <?php if (!$cancelled): ?>
                                <div
                                    class="bg-slate-50/50 rounded-[2rem] p-6 lg:p-8 mb-8 border border-slate-100 shadow-sm overflow-hidden relative">
                                    <!-- Desktop Timeline -->
                                    <div class="hidden sm:block timeline-container">
                                        <div class="timeline-line"></div>
                                        <div class="timeline-progress" style="width: <?= $progress_width ?>"></div>

                                        <div class="flex justify-between relative z-10 px-8">
                                            <!-- Step 1 -->
                                            <div
                                                class="timeline-step <?= $step >= 1 ? 'completed' : '' ?> <?= $step == 1 ? 'active pulse' : '' ?>">
                                                <div class="timeline-icon"><i class="fas fa-clipboard-check"></i></div>
                                                <p class="mt-4 title text-sm tracking-tight">Order Placed</p>
                                                <p class="text-[10px] uppercase font-bold text-slate-400 tracking-widest mt-1">
                                                    Confirmed</p>
                                            </div>
                                            <!-- Step 2 -->
                                            <div
                                                class="timeline-step <?= $step >= 2 ? 'completed' : '' ?> <?= $step == 2 ? 'active pulse' : '' ?>">
                                                <div class="timeline-icon"><i class="fas fa-fire-burner"></i></div>
                                                <p class="mt-4 title text-sm tracking-tight">Preparing</p>
                                                <p class="text-[10px] uppercase font-bold text-slate-400 tracking-widest mt-1">In
                                                    Kitchen</p>
                                            </div>
                                            <!-- Step 3 -->
                                            <div
                                                class="timeline-step <?= $step >= 3 ? 'completed' : '' ?> <?= $step == 3 ? 'active pulse' : '' ?>">
                                                <div class="timeline-icon"><i class="fas fa-motorcycle"></i></div>
                                                <p class="mt-4 title text-sm tracking-tight">On the Way</p>
                                                <p class="text-[10px] uppercase font-bold text-slate-400 tracking-widest mt-1">
                                                    Dispatched</p>
                                            </div>
                                            <!-- Step 4 -->
                                            <div class="timeline-step <?= $step >= 4 ? 'completed active pulse' : '' ?>">
                                                <div class="timeline-icon"><i class="fas fa-box-open"></i></div>
                                                <p class="mt-4 title text-sm tracking-tight">Delivered</p>
                                                <p class="text-[10px] uppercase font-bold text-slate-400 tracking-widest mt-1">Enjoy
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Mobile Fallback Timeline -->
                                    <div class="sm:hidden flex items-center justify-between border-b border-slate-200 pb-4 mb-4">
                                        <span class="text-xs font-black uppercase tracking-widest text-slate-400">Current
                                            Phase:</span>
                                        <span class="px-2.5 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest border <?= $badge_color ?>">
                                            <?php
                                                if(strtolower($order['order_status']) == 'in transit' || strtolower($order['order_status']) == 'out for delivery') {
                                                    echo "On the Way";
                                                } else {
                                                    echo $order['order_status'];
                                                }
                                            ?>
                                </span>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div
                                    class="bg-rose-50 border border-rose-200 rounded-[2rem] p-6 lg:p-8 mb-8 text-center shadow-inner">
                                    <i class="fas fa-ban text-4xl text-rose-400 mb-3"></i>
                                    <h3 class="text-2xl font-900 text-rose-700 tracking-tight">Order Cancelled</h3>
                                    <p class="text-rose-500 font-bold text-sm mt-1">This transition has been voided by the operator.
                                    </p>
                                </div>
                            <?php endif; ?>

                            <!-- Executive Info & OTP Module -->
                            <?php
                            if (!empty($order['delivery_person_id']) && $status !== 'delivered' && !$cancelled):
                                $dp_id = $order['delivery_person_id'];
                                $dp_query = "SELECT name, phone, vehicle_number FROM delivery_person WHERE id='$dp_id'";
                                $dp_res = mysqli_query($conn, $dp_query);
                                if ($dp_row = mysqli_fetch_assoc($dp_res)):
                                    ?>
                                    <div class="mb-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
                                        <!-- Driver Profile -->
                                        <div
                                            class="lg:col-span-2 bg-gradient-to-r from-slate-900 to-slate-800 rounded-3xl p-6 flex flex-col sm:flex-row justify-between items-center gap-6 shadow-xl relative overflow-hidden">
                                            <i
                                                class="fas fa-motorcycle absolute -right-6 -bottom-6 text-7xl text-white/5 pointer-events-none"></i>
                                            <div class="flex items-center gap-5 relative z-10 w-full">
                                                <div
                                                    class="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center text-white border border-white/20 backdrop-blur-md shrink-0">
                                                    <i class="fas fa-helmet-safety text-2xl drop-shadow-lg"></i>
                                                </div>
                                                <div class="flex-1">
                                                    <div class="flex items-center justify-between mb-1">
                                                        <p class="text-[9px] font-black uppercase tracking-[0.3em] text-orange-400">
                                                            Assigned Executive</p>
                                                        <span
                                                            class="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded text-[9px] uppercase font-black flex items-center gap-1 backdrop-blur-md">
                                                            <div class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></div>
                                                            Tracking
                                                        </span>
                                                    </div>
                                                    <h4 class="font-900 text-2xl text-white tracking-tight mb-2">
                                                        <?= htmlspecialchars($dp_row['name']) ?></h4>
                                                    <div class="flex flex-wrap items-center gap-4 text-xs font-bold text-slate-300">
                                                        <span
                                                            class="bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2"><i
                                                                class="fas fa-phone text-orange-400"></i>
                                                            <?= htmlspecialchars($dp_row['phone']) ?></span>
                                                        <span
                                                            class="bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2"><i
                                                                class="fas fa-id-card text-orange-400"></i>
                                                            <?= htmlspecialchars($dp_row['vehicle_number']) ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- OTP Display block -->
                                        <?php if ($status === 'out for delivery' && !empty($order['delivery_otp'])): ?>
                                            <div
                                                class="bg-orange-500 rounded-3xl p-6 flex flex-col items-center justify-center text-center shadow-xl shadow-orange-500/30 relative overflow-hidden">
                                                <div
                                                    class="absolute inset-0 bg-white/10 rotate-12 scale-[2.0] mix-blend-overlay pointer-events-none">
                                                </div>
                                                <p
                                                    class="text-[10px] font-black uppercase tracking-[0.3em] text-orange-100 mb-1 relative z-10">
                                                    Delivery OTP</p>
                                                <h2 class="text-4xl font-900 text-white tracking-[0.2em] relative z-10 drop-shadow-md">
                                                    <?= $order['delivery_otp'] ?></h2>
                                                <p
                                                    class="text-[9px] font-bold uppercase tracking-widest text-orange-200 mt-2 relative z-10">
                                                    Share with rider</p>
                                            </div>
                                        <?php else: ?>
                                            <div
                                                class="bg-slate-100 rounded-3xl p-6 flex flex-col items-center justify-center text-center border-2 border-dashed border-slate-300">
                                                <i class="fas fa-lock text-slate-300 text-2xl mb-2"></i>
                                                <p class="text-[10px] font-black uppercase tracking-[0.1em] text-slate-400 leading-tight">
                                                    OTP Generates upon dispatch</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; endif; ?>

                            <!-- Order Details Breakdown -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
                                <!-- Items -->
                                <div>
                                    <p
                                        class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-4 pb-2 border-b border-slate-200 flex items-center gap-2">
                                        <i class="fas fa-utensils text-orange-500"></i> Culinary Summary
                                    </p>
                                    <div class="space-y-4">
                                        <?php
                                        $oid = $order['order_id'];
                                        $items_q = "SELECT i.*, f.food_name, f.description FROM order_items i JOIN food_items f ON i.food_id=f.food_id WHERE i.order_id='$oid'";
                                        $items_r = mysqli_query($conn, $items_q);
                                        while ($item = mysqli_fetch_assoc($items_r)):
                                            ?>
                                            <div class="flex justify-between items-start gap-4">
                                                <div class="font-bold text-slate-800 flex items-start gap-3">
                                                    <span
                                                        class="bg-orange-100 text-orange-600 px-2 py-0.5 rounded-lg font-black text-xs shrink-0 mt-0.5 border border-orange-200 shadow-sm"><?= $item['quantity'] ?>x</span>
                                                    <span class="leading-tight"><?= htmlspecialchars($item['food_name']) ?></span>
                                                </div>
                                                <div class="font-black text-slate-900 border-b-2 border-slate-100 pb-0.5">
                                                    &#8377;<?= number_format($item['price'] * $item['quantity'], 2) ?>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    </div>
                                </div>

                                <!-- Logistics -->
                                <div class="bg-slate-50/50 p-6 rounded-[2rem] border border-slate-100">
                                    <p
                                        class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-4 pb-2 border-b border-slate-200 flex items-center gap-2">
                                        <i class="fas fa-map-location-dot text-orange-500"></i> Drop Details
                                    </p>
                                    <div class="mb-4">
                                        <p class="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Destination
                                        </p>
                                        <p class="text-sm font-semibold text-slate-800 leading-relaxed">
                                            <?= htmlspecialchars($order['address']) ?></p>
                                    </div>
                                    <div>
                                        <p class="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Network Base
                                        </p>
                                        <p class="text-sm font-semibold text-slate-800 leading-relaxed flex items-center gap-2">
                                            <i class="fas fa-phone text-orange-500 text-xs"></i>
                                            <?= htmlspecialchars($order['phone']) ?></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Action Footer -->
                            <?php if ($status == 'delivered'):
                                $f_check = mysqli_query($conn, "SELECT feedback_id FROM feedback WHERE order_id='$oid'");
                                ?>
                                <div class="mt-8 pt-6 border-t border-slate-100 flex justify-end">
                                    <?php if (mysqli_num_rows($f_check) > 0): ?>
                                        <button disabled class="bg-emerald-50 text-emerald-600 px-8 py-3 rounded-xl font-black uppercase text-xs tracking-widest border border-emerald-200 flex items-center gap-3 cursor-not-allowed opacity-80">
                                            <i class="fas fa-check-double text-lg"></i> Evaluation Recorded
                                        </button>
                                    <?php else: ?>
                                        <a href="feedback.php?order_id=<?= $oid ?>" class="bg-slate-900 hover:bg-orange-500 text-white px-8 py-3 rounded-xl font-black uppercase text-xs tracking-widest smooth-btn flex items-center gap-3 hover:shadow-xl hover:shadow-orange-500/30">
                                            <i class="fas fa-star text-lg text-amber-400"></i> Submit Audit
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>