<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// Check Login
if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];

// Fetch customer details
$stmt = $conn->prepare("SELECT * FROM customers WHERE customer_id = ?");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Count Orders
$stmt_orders = $conn->prepare("SELECT COUNT(*) as total_orders FROM orders WHERE customer_id = ?");
$stmt_orders->bind_param("i", $customer_id);
$stmt_orders->execute();
$total_orders = $stmt_orders->get_result()->fetch_assoc()['total_orders'];

// Cart Count
$cart_count = (isset($_SESSION['cart'])) ? count($_SESSION['cart']) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Profile | FOODIE'S HEAVEN</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f8fafc;
        }
        .profile-banner {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            height: 280px;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .avatar-container {
            margin-top: -75px;
        }
        .stat-card {
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
        }
        .btn-luxury {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-luxury:hover {
            transform: scale(1.02);
            filter: brightness(1.1);
        }
    </style>
</head>
<body class="min-h-screen">

    <div class="profile-banner w-full flex items-center justify-center relative overflow-hidden">
        <div class="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
        <div class="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/10 rounded-full -ml-32 -mb-32 blur-3xl"></div>

        <div class="text-center z-10">
            <h1 class="text-white text-3xl md:text-4xl font-800 tracking-tighter uppercase italic">Your <span class="text-orange-500">Profile</span></h1>
            <p class="text-slate-400 text-sm font-medium mt-2 tracking-widest uppercase">Member Since <?= date('Y', strtotime($user['created_at'] ?? '2026')) ?></p>
        </div>
    </div>

    <div class="max-w-4xl mx-auto px-4 pb-20">
        <div class="glass-card rounded-[3rem] shadow-2xl p-8 md:p-12 relative -mt-20">

            <div class="avatar-container flex flex-col items-center">
                <div class="w-32 h-32 bg-white rounded-full p-2 shadow-xl">
                    <div class="w-full h-full bg-slate-100 rounded-full flex items-center justify-center text-4xl text-slate-400 font-black border-4 border-slate-50">
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    </div>
                </div>
                <div class="text-center mt-4">
                    <h2 class="text-2xl font-800 text-slate-800 tracking-tight"><?= htmlspecialchars($user['name']) ?></h2>
                    <p class="text-slate-400 font-medium"><?= htmlspecialchars($user['email']) ?></p>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4 mt-10">
                <div class="stat-card bg-slate-50 p-6 rounded-[2rem] border border-slate-100 text-center">
                    <i class="fas fa-box-open text-orange-500 text-xl mb-2"></i>
                    <span class="block text-2xl font-900 text-slate-800"><?= $total_orders ?></span>
                    <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Orders</label>
                </div>
                <div class="stat-card bg-slate-50 p-6 rounded-[2rem] border border-slate-100 text-center">
                    <i class="fas fa-shopping-cart text-blue-500 text-xl mb-2"></i>
                    <span class="block text-2xl font-900 text-slate-800"><?= $cart_count ?></span>
                    <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">In Cart</label>
                </div>
            </div>

            <div class="mt-10 space-y-4">
                <div class="flex justify-between items-center p-5 bg-white border border-slate-100 rounded-2xl">
                    <span class="text-xs font-black uppercase text-slate-400 tracking-widest">Phone Frequency</span>
                    <span class="font-bold text-slate-700"><?= htmlspecialchars($user['phone']) ?></span>
                </div>
                <div class="flex justify-between items-center p-5 bg-white border border-slate-100 rounded-2xl">
                    <span class="text-xs font-black uppercase text-slate-400 tracking-widest">Security ID</span>
                    <span class="font-bold text-slate-700">#<?= str_pad($customer_id, 5, '0', STR_PAD_LEFT) ?></span>
                </div>

                <a href="membership.php" class="flex justify-between items-center p-5 bg-gradient-to-r from-amber-500 to-orange-600 border border-amber-400 rounded-2xl group hover:shadow-lg hover:shadow-amber-500/20 transition-all cursor-pointer">
                    <div class="flex items-center gap-3">
                        <i class="fas fa-crown text-white text-xl group-hover:scale-110 transition-transform"></i>
                        <span class="text-xs font-black uppercase text-white/90 tracking-widest">VIP Membership</span>
                    </div>
                    <?php if($user['is_vip'] == 1 && ($user['membership_expiry'] ?? '') >= date('Y-m-d')): ?>
                        <span class="font-black text-white text-xs bg-white/20 px-3 py-1 rounded-lg">Active (<?= date('d/m/Y', strtotime($user['membership_expiry'])) ?>)</span>
                    <?php else: ?>
                        <span class="font-black text-white text-xs px-3 py-1 rounded-lg border border-white/30 hover:bg-white hover:text-amber-500 transition-colors">Upgrade Now <i class="fas fa-arrow-right ml-1"></i></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
                <a href="index.php" class="btn-luxury flex flex-col items-center justify-center p-4 bg-slate-100 rounded-2xl text-slate-600 hover:bg-slate-200">
                    <i class="fas fa-house-chimney mb-2"></i>
                    <span class="text-[10px] font-black uppercase">Home</span>
                </a>
                <a href="my_orders.php" class="btn-luxury flex flex-col items-center justify-center p-4 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-200">
                    <i class="fas fa-receipt mb-2"></i>
                    <span class="text-[10px] font-black uppercase">History</span>
                </a>
                <a href="customer_profile_update.php" class="btn-luxury flex flex-col items-center justify-center p-4 bg-orange-500 rounded-2xl text-white shadow-lg shadow-orange-200">
                    <i class="fas fa-user-pen mb-2"></i>
                    <span class="text-[10px] font-black uppercase">Edit</span>
                </a>
                <a href="change_password.php" class="btn-luxury flex flex-col items-center justify-center p-4 bg-emerald-500 rounded-2xl text-white shadow-lg shadow-emerald-200">
                    <i class="fas fa-shield-halved mb-2"></i>
                    <span class="text-[10px] font-black uppercase">Security</span>
                </a>
            </div>

            <div class="mt-6">
                <a href="logout.php" class="w-full flex items-center justify-center gap-3 py-4 bg-rose-50 text-rose-500 rounded-2xl font-black uppercase text-xs tracking-[0.2em] hover:bg-rose-500 hover:text-white transition-all duration-300">
                    <i class="fas fa-power-off"></i> logout
                </a>
            </div>

        </div>

        <p class="text-center mt-10 text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] opacity-50">
            Food's Heaven Executive Dining System &copy; 2026
        </p>
    </div>

</body>
</html>