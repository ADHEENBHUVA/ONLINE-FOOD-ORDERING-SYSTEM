<?php
/**
 * TastyBytes Premium Login Portal
 * Full Logic, Design Integration & Secure Password Validation
 */

if (session_status() == PHP_SESSION_NONE) {
    session_set_cookie_params(86400 * 30);
session_start();
}

$conn = new mysqli("localhost", "root", "", "online_food");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$error = "";

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // 1. BACKEND VALIDATION (Matches the 8-16 char, complex requirement)
    $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';

    if (!preg_match($pattern, $password)) {
        $error = "Security Policy: Password must be 8-16 chars with Upper, Lower, Number & Special Char.";
    } else {
        $sql = "SELECT * FROM customers WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            if ($row['password'] == $password) {
                $_SESSION['customer_id'] = $row['customer_id'];
                $_SESSION['customer_name'] = $row['name'];

                /* LOGIN HISTORY RECORDING */
                $customer_id = $row['customer_id'];
                $ip = $_SERVER['REMOTE_ADDR'];
                $device = mysqli_real_escape_string($conn, $_SERVER['HTTP_USER_AGENT']);

                $stmt2 = $conn->prepare("INSERT INTO customer_login_history (customer_id, ip_address, device) VALUES (?, ?, ?)");
                $stmt2->bind_param("iss", $customer_id, $ip, $device);
                $stmt2->execute();

                header("Location: index.php");
                exit();
            } else {
                $error = "Incorrect credentials. Please verify your security key.";
            }
        } else {
            $error = "This email identity is not registered.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; }
        .food-bg {
            background-image: url('https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80');
            background-size: cover; background-position: center;
        }
        .input-focus:focus { box-shadow: 0 0 0 2px #f97316; border-color: #f97316; }
        .smooth-btn { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .smooth-btn:active { transform: scale(0.97); }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex selection:bg-orange-500 selection:text-white">

    <!-- Left Branding Panel (Hidden on Mobile) -->
    <div class="hidden lg:flex lg:w-[45%] food-bg relative overflow-hidden flex-col justify-between p-12">
        <div class="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-slate-900/80 z-0"></div>

        <div class="relative z-10">
            <a href="index.php" class="inline-flex items-center gap-3 group">
                <div class="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:scale-105 transition-transform">
                    <i class="fas fa-leaf text-white text-xl"></i>
                </div>
                <span class="text-2xl font-900 tracking-tighter text-white">Foodie's <span class="text-orange-500 italic">Heaven.</span></span>
            </a>
        </div>

        <div class="relative z-10 max-w-lg">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-6 font-bold text-xs tracking-widest uppercase text-orange-400">
                <span class="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span> Identity Portal
            </div>
            <h1 class="text-6xl font-900 text-white leading-[1.1] tracking-tighter mb-6">Welcome<br>Back.</h1>
            <p class="text-lg text-slate-300 font-medium leading-relaxed">Sign in to track your premium orders in real-time and explore your personalized gourmet menu.</p>
        </div>

        <div class="relative z-10 text-xs font-bold tracking-widest uppercase text-slate-500">
            &copy; 2026 Foodie's Heaven.
        </div>
    </div>

    <!-- Right Login Panel -->
    <div class="w-full lg:w-[55%] flex items-center justify-center p-6 sm:p-12 relative">
        <!-- Ambient Glow -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-orange-500/10 blur-[120px] rounded-full pointer-events-none"></div>

        <div class="w-full max-w-md relative z-10">
            <!-- Mobile Header (Visible only on mobile) -->
            <div class="lg:hidden flex justify-center mb-10">
                <a href="index.php" class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30">
                        <i class="fas fa-leaf text-white text-lg"></i>
                    </div>
                    <span class="text-2xl font-900 tracking-tighter text-white">Foodie's <span class="text-orange-500 italic">Heaven.</span></span>
                </a>
            </div>

            <div class="mb-10 text-center lg:text-left">
                <h2 class="text-3xl font-900 text-white tracking-tight mb-2">Sign In</h2>
                <p class="text-slate-400 font-medium">Enter your credentials to access your account.</p>
            </div>

            <?php if($error != ""): ?>
                <div class="bg-rose-500/10 border border-rose-500/30 text-rose-400 px-5 py-4 rounded-2xl mb-8 flex items-start gap-4">
                    <i class="fas fa-shield-halved mt-0.5"></i>
                    <p class="text-sm font-semibold leading-relaxed"><?= $error; ?></p>
                </div>
            <?php endif; ?>

            <form method="POST" action="" onsubmit="return validatePassword();" class="space-y-6">
                <!-- Email -->
                <div>
                    <label class="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-2 ml-1">Email Address</label>
                    <div class="relative group">
                        <i class="fas fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                        <input type="email" name="email" required placeholder="you@example.com"
                               class="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-14 pr-5 text-white outline-none input-focus font-medium">
                    </div>
                </div>

                <!-- Password -->
                <div>
                    <div class="flex justify-between items-center mb-2 ml-1 pr-1">
                        <label class="text-xs font-extrabold uppercase tracking-widest text-slate-500">Security Key</label>
                        <a href="forgot_password.php" class="text-[10px] font-bold text-slate-500 hover:text-orange-500 transition-colors">Forgot String?</a>
                    </div>
                    <div class="relative group">
                        <i class="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                        <input type="password" name="password" id="passInput" required placeholder="••••••••"
                               class="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-14 pr-14 text-white outline-none input-focus font-medium">
                        <button type="button" onclick="toggleVisibility()" class="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors focus:outline-none">
                            <i id="eyeIcon" class="fas fa-eye"></i>
                        </button>
                    </div>
                    <p class="text-[10px] text-slate-600 font-semibold mt-2 ml-1 block"><i class="fas fa-shield-check text-orange-500 mr-1"></i> Policy: 8-16 chars. Must include Upper, Lower, Number, and Special (@$!%*?&).</p>
                </div>

                <!-- Submit Button -->
                <button type="submit" name="login" class="w-full bg-orange-500 text-white font-900 py-4 rounded-2xl uppercase tracking-widest text-sm smooth-btn flex justify-center items-center gap-3 shadow-xl shadow-orange-500/20 mt-4">
                    Authenticate <i class="fas fa-arrow-right"></i>
                </button>
            </form>

            <div class="mt-10 text-center">
                <p class="text-slate-400 font-medium">
                    Don't have an account?
                    <a href="register.php" class="text-white font-bold hover:text-orange-500 transition-colors ml-1 border-b border-transparent hover:border-orange-500 pb-0.5">Create Profile</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        function toggleVisibility() {
            const input = document.getElementById('passInput');
            const icon = document.getElementById('eyeIcon');
            if(input.type === 'password') { input.type = 'text'; icon.className = 'fas fa-eye-slash'; }
            else { input.type = 'password'; icon.className = 'fas fa-eye'; }
        }

        function validatePassword() {
            const pass = document.getElementById('passInput').value;
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
            if (!regex.test(pass)) {
                alert("Security Authorization Failed: Password must strictly match the 8-16 character alphanumeric and special string policy.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
