<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

/* ================= 1. SESSION RECOGNITION ================= */
$user_id = $_SESSION['user_id'] ?? $_SESSION['customer_id'] ?? null;

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$msg = "";
$msg_type = "";

/* ================= 2. UPDATE QUANTITY LOGIC ================= */
if (isset($_GET['update_qty'])) {
    $id = $_GET['id'];
    $action = $_GET['update_qty'];

    if (isset($_SESSION['cart'][$id])) {
        if ($action == 'plus') {
            if ($_SESSION['cart'][$id]['quantity'] < 10) {
                $_SESSION['cart'][$id]['quantity']++;
            } else {
                $msg = "Maximum quantity reached (10 units).";
                $msg_type = "error";
            }
        } elseif ($action == 'minus') {
            if ($_SESSION['cart'][$id]['quantity'] > 1) {
                $_SESSION['cart'][$id]['quantity']--;
            } else {
                unset($_SESSION['cart'][$id]);
            }
        }
    }
    if (!$msg) {
        header("Location: cart.php");
        exit();
    }
}

/* ================= 3. REMOVE ITEM ================= */
if (isset($_GET['remove'])) {
    $id = $_GET['remove'];
    unset($_SESSION['cart'][$id]);
    header("Location: cart.php");
    exit();
}

/* ================= 4. CALCULATE SUBTOTAL ================= */
$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

/* ================= 5. APPLY PROMO LOGIC (ONE-TIME USE CHECK) ================= */
if (isset($_POST['apply_promo'])) {
    if (!$user_id) {
        $msg = "Sign in required to apply coupons.";
        $msg_type = "error";
    } else {
        $promo_input = strtoupper(trim(mysqli_real_escape_string($conn, $_POST['promo_code'])));

        // A. Check if code exists and is active
        $query = $conn->query("SELECT * FROM promo_codes WHERE promo_code = '$promo_input' AND status='Active'");

        if($query && $query->num_rows > 0) {
            $promo_data = $query->fetch_assoc();
            $min_required = (float)$promo_data['min_order_amt'];

            // B. ONE-TIME USE CHECK: Check if this user has used this code in any past order
            // Note: This assumes your 'orders' table has a column 'promo_used'
            $usage_check = $conn->query("SELECT order_id FROM orders WHERE customer_id = '$user_id' AND promo_used = '$promo_input'");

            if ($usage_check->num_rows > 0) {
                $msg = "You have already used this promo code once.";
                $msg_type = "error";
            }
            // C. FIRST USER CHECK: If it's a first order code, check if user has any previous orders
            else if ($promo_data['type'] == 'FIRST_USER') {
                $order_history = $conn->query("SELECT order_id FROM orders WHERE customer_id = '$user_id'");
                if ($order_history->num_rows > 0) {
                    $msg = "This code is only valid for your very first order.";
                    $msg_type = "error";
                } else if ($subtotal < $min_required) {
                    $msg = "Add &#8377;" . ($min_required - $subtotal) . " more to use this code.";
                    $msg_type = "error";
                } else {
                    $_SESSION['applied_promo'] = $promo_data;
                    $msg = "First order discount applied!";
                    $msg_type = "success";
                }
            }
            // D. MINIMUM AMOUNT CHECK
            else if($subtotal < $min_required) {
                $msg = "Add &#8377;" . ($min_required - $subtotal) . " more to use this code.";
                $msg_type = "error";
            } else {
                $_SESSION['applied_promo'] = $promo_data;
                $msg = "Promo code '$promo_input' applied!";
                $msg_type = "success";
            }
        } else {
            $msg = "Invalid or expired promo code.";
            $msg_type = "error";
        }
    }
}

if (isset($_POST['remove_promo'])) {
    $_SESSION['applied_promo'] = null;
    header("Location: cart.php");
    exit();
}

/* ================= 6. FINAL BILL CALCULATION ================= */
$discount_amount = 0;
if (!empty($_SESSION['applied_promo'])) {
    $min_required = (float)$_SESSION['applied_promo']['min_order_amt'];
    if($subtotal >= $min_required) {
        $percent = $_SESSION['applied_promo']['discount_percent'];
        $discount_amount = ($subtotal * $percent) / 100;
    } else {
        $_SESSION['applied_promo'] = null;
        $msg = "Code removed: Order value too low.";
        $msg_type = "error";
    }
}

$final_total = $subtotal - $discount_amount;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gourmet Cart | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8fafc; overflow-x: hidden; }
        .glass-nav { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0, 0, 0, 0.05); }
        .ultra-card { background: rgba(255,255,255,0.8); backdrop-filter: blur(24px); border: 1px solid rgba(255,255,255,0.5); border-radius: 2rem; box-shadow: 0 40px 100px -20px rgba(0,0,0,0.08), inset 0 0 0 1px rgba(255,255,255,1); transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
        .item-row { transition: all 0.3s ease; border: 1px solid transparent; }
        .item-row:hover { background: #ffffff; border-color: rgba(249, 115, 22, 0.2); transform: scale(1.01); box-shadow: 0 20px 40px -10px rgba(249,115,22,0.1); }
        .qty-btn { transition: all 0.2s; }
        .qty-btn:active { transform: scale(0.9); }
        .input-glow:focus { box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.15); border-color: #f97316; }
        .bg-mesh { background-image: radial-gradient(at 0% 0%, hsla(28,100%,74%,0.15) 0px, transparent 50%), radial-gradient(at 100% 100%, hsla(210,100%,80%,0.15) 0px, transparent 50%); }
    </style>
</head>
<body class="bg-mesh min-h-screen pt-32 pb-20 flex flex-col">

<!-- Navigation -->
<nav class="glass-nav fixed w-full top-0 z-50 py-4 px-6 md:px-12">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
        <a href="index.php" class="flex items-center gap-3 group">
            <div class="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:bg-slate-900 transition-colors duration-500">
                <i class="fas fa-leaf text-white text-lg"></i>
            </div>
            <span class="text-xl font-900 tracking-tighter text-slate-900">Foodie's <span class="text-orange-500 italic">Heaven.</span></span>
        </a>
        <div class="flex items-center gap-6">
            <a href="index.php#menu-section" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors hidden md:block">Back to Menu</a>
            <div class="bg-slate-100 text-slate-800 px-4 py-2 rounded-full font-black text-xs uppercase tracking-widest flex items-center gap-2">
                <i class="fas fa-lock text-slate-400"></i> Secure Session
            </div>
        </div>
    </div>
</nav>

<div class="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8">
    <div class="flex flex-col items-center text-center mb-16 relative">
        <div class="absolute -top-10 lg:-top-20 w-40 lg:w-64 h-40 lg:h-64 bg-orange-500/20 rounded-full blur-[80px] -z-10"></div>
        <h1 class="text-5xl lg:text-7xl font-900 tracking-tighter text-slate-900 italic mb-4">Your <span class="text-orange-500 relative">Selection<svg class="absolute w-full h-3 -bottom-1 left-0 text-orange-200" viewBox="0 0 100 10" preserveAspectRatio="none"><path d="M0 5 Q 50 15 100 5" stroke="currentColor" stroke-width="4" fill="transparent"/></svg></span></h1>
        <p class="text-slate-500 font-medium text-lg">Review your premium culinary choices before proceeding.</p>
    </div>

    <?php if ($msg): ?>
        <div class="max-w-3xl mx-auto mb-10 p-5 rounded-2xl font-bold text-sm flex items-center gap-4 animate-pulse <?= $msg_type == 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-lg shadow-emerald-500/10' : 'bg-rose-50 text-rose-700 border border-rose-200 shadow-lg shadow-rose-500/10' ?>">
            <div class="w-10 h-10 <?= $msg_type == 'success' ? 'bg-emerald-100' : 'bg-rose-100' ?> rounded-full flex items-center justify-center shrink-0">
                <i class="fas <?= $msg_type == 'success' ? 'fa-check' : 'fa-exclamation' ?> text-lg"></i>
            </div>
            <?= $msg ?>
        </div>
    <?php endif; ?>

    <div class="flex flex-col xl:flex-row gap-10 lg:gap-14">

        <!-- Cart Items List (Left Side) -->
        <div class="flex-1 space-y-6">
            <?php if (empty($_SESSION['cart'])): ?>
                <div class="ultra-card flex flex-col items-center justify-center py-32 px-4 text-center">
                    <div class="w-32 h-32 bg-slate-50 rounded-full flex items-center justify-center mb-8 shadow-inner border-[8px] border-white">
                        <i class="fas fa-shopping-basket text-4xl text-slate-300"></i>
                    </div>
                    <h3 class="text-3xl font-900 text-slate-800 mb-3 tracking-tight">Your cart is empty</h3>
                    <p class="text-slate-500 font-medium mb-10 text-lg">Indulge in our exquisite menu offerings.</p>
                    <a href="index.php#menu-section" class="bg-orange-500 text-white px-10 py-4 rounded-2xl font-black uppercase text-sm tracking-[0.2em] shadow-xl shadow-orange-500/30 hover:bg-slate-900 transition-all duration-300 hover:-translate-y-1">
                        Discover Menu
                    </a>
                </div>
            <?php else: ?>
                <div class="ultra-card p-4 sm:p-8">
                    <div class="flex justify-between items-center mb-6 pb-4 border-b border-slate-100 px-2 lg:px-4">
                        <span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Item Detail</span>
                        <span class="text-[10px] font-black uppercase tracking-widest text-slate-400 hidden sm:block">Amount</span>
                    </div>

                    <div class="space-y-4">
                        <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                        <div class="item-row bg-slate-50/50 rounded-[2rem] p-4 flex flex-col sm:flex-row shadow-sm gap-6 items-center relative">
                            <!-- Image -->
                            <div class="relative shrink-0">
                                <div class="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden shadow-lg border border-white/50">
                                    <img src="images/<?= htmlspecialchars($item['image']) ?>" class="w-full h-full object-cover">
                                </div>
                                <a href="cart.php?remove=<?= $id ?>" class="absolute -top-3 -right-3 w-8 h-8 bg-white text-rose-500 rounded-full shadow-lg flex items-center justify-center hover:bg-rose-500 hover:text-white transition-colors cursor-pointer border border-rose-100">
                                    <i class="fas fa-times text-xs"></i>
                                </a>
                            </div>

                            <!-- Details -->
                            <div class="flex-1 w-full text-center sm:text-left">
                                <h3 class="text-2xl font-900 text-slate-900 tracking-tight leading-tight mb-2"><?= htmlspecialchars($item['food_name']) ?></h3>
                                <p class="text-orange-500 font-black text-lg">&#8377;<?= number_format($item['price'], 2) ?></p>
                            </div>

                            <!-- Controls & Subtotal -->
                            <div class="flex flex-row sm:flex-col lg:flex-row items-center justify-between sm:justify-center gap-6 w-full sm:w-auto mt-4 sm:mt-0 pt-4 sm:pt-0 border-t sm:border-none border-slate-200">
                                <!-- Quantity -->
                                <div class="flex items-center bg-white border border-slate-200 p-1.5 rounded-2xl shadow-sm">
                                    <a href="cart.php?id=<?= $id ?>&update_qty=minus" class="qty-btn w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-500 hover:bg-slate-900 hover:text-white rounded-xl font-bold"><i class="fas fa-minus text-xs"></i></a>
                                    <span class="w-12 text-center font-900 text-xl text-slate-800"><?= $item['quantity'] ?></span>
                                    <a href="cart.php?id=<?= $id ?>&update_qty=plus" class="qty-btn w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-500 hover:bg-orange-500 hover:text-white rounded-xl font-bold"><i class="fas fa-plus text-xs"></i></a>
                                </div>

                                <!-- Subtotal -->
                                <div class="text-right min-w-[100px]">
                                    <p class="text-[10px] font-black text-slate-400 tracking-widest uppercase mb-1 hidden sm:block">Subtotal</p>
                                    <p class="text-2xl font-900 text-slate-900 tracking-tighter">&#8377;<?= number_format($item['price'] * $item['quantity'], 2) ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Order Summary & Checkout Action (Right Side) -->
        <?php if (!empty($_SESSION['cart'])): ?>
        <div class="w-full xl:w-[420px] 2xl:w-[480px]">
            <div class="ultra-card p-8 lg:p-10 sticky top-28 border-t-8 border-t-slate-900">
                <div class="flex items-center gap-4 mb-8">
                    <div class="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-800">
                        <i class="fas fa-receipt text-xl"></i>
                    </div>
                    <h2 class="text-2xl font-900 uppercase italic tracking-tight text-slate-900">Order Summary</h2>
                </div>

                <!-- Promo Section -->
                <div class="mb-10 p-6 bg-slate-50 rounded-3xl border border-slate-100">
                    <?php if (!$user_id): ?>
                        <div class="flex flex-col items-center justify-center text-center py-4">
                            <i class="fas fa-ticket-alt text-3xl text-slate-300 mb-3"></i>
                            <p class="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Sign in to unlock coupons</p>
                            <a href="login.php" class="bg-white border border-slate-200 px-6 py-2 rounded-xl text-[10px] font-bold text-slate-600 hover:text-orange-500 transition-colors uppercase tracking-widest shadow-sm">Authorize</a>
                        </div>
                    <?php else: ?>
                        <form method="POST" class="relative">
                            <label class="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 ml-1">VIP Voucher Code</label>
                            <div class="flex h-14 relative group">
                                <i class="fas fa-ticket absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-orange-500 transition-colors z-10"></i>
                                <input type="text" name="promo_code" class="input-glow w-full bg-white border-2 border-slate-200 rounded-2xl pl-12 pr-24 font-black text-slate-800 uppercase tracking-widest shadow-sm" placeholder="ENTER CODE" <?= !empty($_SESSION['applied_promo']) ? 'disabled value="'.$_SESSION['applied_promo']['promo_code'].'"' : '' ?>>

                                <div class="absolute right-1.5 top-1.5 bottom-1.5 flex items-center">
                                <?php if (empty($_SESSION['applied_promo'])): ?>
                                    <button type="submit" name="apply_promo" class="h-full bg-slate-900 hover:bg-orange-500 text-white px-5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-colors shadow-md">Apply</button>
                                <?php else: ?>
                                    <button type="submit" name="remove_promo" class="h-full bg-rose-50 hover:bg-rose-100 text-rose-500 border border-rose-200 px-4 rounded-xl font-black text-[10px] uppercase tracking-widest transition-colors shadow-sm"><i class="fas fa-times"></i></button>
                                <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>

                <!-- Calculations -->
                <div class="space-y-5 mb-8 border-b border-dashed border-slate-200 pb-8">
                    <div class="flex justify-between items-center text-slate-500 font-bold text-sm">
                        <span>Items Total</span>
                        <span class="text-slate-800 font-black">&#8377;<?= number_format($subtotal, 2) ?></span>
                    </div>

                    <?php if ($discount_amount > 0): ?>
                    <div class="flex justify-between items-center bg-emerald-50 text-emerald-600 px-4 py-3 rounded-xl border border-emerald-100 font-bold text-sm">
                        <span class="flex items-center gap-2"><i class="fas fa-tag"></i> Promo Saved</span>
                        <span class="font-black">- &#8377;<?= number_format($discount_amount, 2) ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="flex justify-between items-end mb-10">
                    <div>
                        <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Amount to Pay</p>
                        <h2 class="text-5xl font-900 text-slate-900 tracking-tighter">&#8377;<?= number_format($final_total, 2) ?></h2>
                    </div>
                </div>

                <a href="checkout.php" class="relative group block w-full bg-slate-900 text-white text-center rounded-[1.5rem] font-black uppercase text-sm tracking-[0.2em] overflow-hidden transition-all shadow-xl shadow-slate-900/20 active:scale-95">
                    <div class="absolute inset-0 bg-orange-500 translate-y-[100%] group-hover:translate-y-0 transition-transform duration-500 ease-in-out"></div>
                    <div class="relative py-6 flex flex-col items-center justify-center gap-1 z-10 text-white">
                        <span class="flex items-center gap-3">Secure Checkout <i class="fas fa-arrow-right"></i></span>
                    </div>
                </a>

                <div class="mt-6 flex flex-col items-center gap-3">
                    <div class="flex items-center justify-center gap-2 opacity-50">
                        <i class="fab fa-cc-visa text-2xl"></i>
                        <i class="fab fa-cc-mastercard text-2xl"></i>
                        <i class="fab fa-google-pay text-2xl"></i>
                    </div>
                    <span class="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400">256-bit Encryption Security</span>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

</body>
</html>
