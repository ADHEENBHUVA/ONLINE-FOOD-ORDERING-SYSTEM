<?php
// Prevent redeclaring PHPMailer classes if already loaded elsewhere
if (!class_exists('PHPMailer\PHPMailer\Exception')) {
    require_once __DIR__ . '/Admin/PHPMailer/src/Exception.php';
    require_once __DIR__ . '/Admin/PHPMailer/src/PHPMailer.php';
    require_once __DIR__ . '/Admin/PHPMailer/src/SMTP.php';
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Sends an email notification using PHPMailer.
 * 
 * @param string|array $to Single email address or array of email addresses
 * @param string $subject Email subject
 * @param string $body Email HTML body content
 * @return bool True on success, False on failure
 */
function sendOrderEmail($to, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';                     // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'foodiesheaven01@gmail.com';               // SMTP username
        $mail->Password   = 'xnrz phfh zeua wmsn';                  // SMTP password or App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption
        $mail->Port       = 587;                                    // TCP port to connect to

        // Recipients
        $mail->setFrom('foodiesheaven01@gmail.com', 'Foodies Heaven Notification');
        
        if (is_array($to)) {
            foreach ($to as $emailAddress) {
                if(!empty($emailAddress)){
                    $mail->addAddress($emailAddress);
                }
            }
        } else {
            if(!empty($to)){
                $mail->addAddress($to);
            }
        }

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        
        // Add some basic styling to the email body
        $styledBody = "
        <div style='font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px;'>
            <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 20px; border-radius: 10px; border: 1px solid #eeeeee;'>
                <h2 style='color: #f97316; text-align: center;'>Foodie's Heaven</h2>
                <hr style='border: 0; border-top: 1px solid #eeeeee; margin-bottom: 20px;' />
                <div style='color: #333333; line-height: 1.6;'>
                    $body
                </div>
                <hr style='border: 0; border-top: 1px solid #eeeeee; margin-top: 20px;' />
                <p style='text-align: center; color: #999999; font-size: 12px;'>
                    Thank you for choosing Foodie's Heaven!<br>
                    This is an automated notification. Please do not reply to this email.
                </p>
            </div>
        </div>";

        $mail->Body = $styledBody;
        $mail->AltBody = strip_tags(str_replace(['<br>', '</p>', '</h1>', '</h2>', '</h3>', '</div>'], "\n", $body));

        $mail->send();
        return true;
    } catch (Exception $e) {
        // Log error if needed: error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

// Global Admin Email configuration for easy access
define('ADMIN_EMAIL', 'foodiesheaven01@gmail.com'); // Update with actual admin email
?>
