<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

$message = "";
$msg_type = "";

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $password = $_POST['password'];

    // PHP Backend Validation: Name (Alphabets and spaces only)
    if (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        $message = "Invalid name! Only alphabets and spaces are allowed.";
        $msg_type = "error";
    } 
    // PHP Backend Validation: Phone Number (10 digits only)
    elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $message = "Invalid phone number! Please enter exactly 10 digits.";
        $msg_type = "error";
    } 
    else {
        // PHP Backend Validation: Complexity Check
        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';
        if (!preg_match($pattern, $password)) {
            $message = "Password does not meet security requirements!";
            $msg_type = "error";
        } else {
            // Check if email already exists
            $check = $conn->prepare("SELECT * FROM customers WHERE email=?");
            $check->bind_param("s", $email);
            $check->execute();
            $result = $check->get_result();

            if ($result->num_rows > 0) {
                $message = "This email is already registered!";
                $msg_type = "error";
            } else {
                $stmt = $conn->prepare("INSERT INTO customers (name, email, phone, address, password) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $name, $email, $phone, $address, $password);

                if ($stmt->execute()) {
                    $message = "Registration Successful! You can login now.";
                    $msg_type = "success";
                } else {
                    $message = "Something went wrong. Please try again.";
                    $msg_type = "error";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; }
        .food-bg {
            background-image: url('https://images.unsplash.com/photo-1574484284002-952d92456975?auto=format&fit=crop&w=1200&q=80');
            background-size: cover; background-position: center;
        }
        .input-focus:focus { box-shadow: 0 0 0 2px #f97316; border-color: #f97316; }
        .smooth-btn { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .smooth-btn:active { transform: scale(0.97); }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex selection:bg-orange-500 selection:text-white overflow-x-hidden">

    <!-- Right Branding Panel (Hidden on Mobile) - Swapped sides for register -->
    <div class="hidden lg:flex lg:w-[40%] food-bg relative overflow-hidden flex-col justify-between p-12 order-2">
        <div class="absolute inset-0 bg-gradient-to-b from-slate-900/90 via-slate-900/50 to-slate-900/90 z-0"></div>

        <div class="relative z-10 flex justify-end">
            <a href="index.php" class="inline-flex items-center gap-3 group">
                <span class="text-2xl font-900 tracking-tighter text-white">Foodie's <span class="text-orange-500 italic">Heaven.</span></span>
                <div class="w-12 h-12 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20 group-hover:bg-orange-500 transition-colors">
                    <i class="fas fa-leaf text-white text-xl"></i>
                </div>
            </a>
        </div>

        <div class="relative z-10 max-w-lg text-right ml-auto mt-20">
            <h1 class="text-5xl font-900 text-white leading-[1.1] tracking-tighter mb-6">Join The<br>Elite.</h1>
            <p class="text-lg text-slate-300 font-medium leading-relaxed">Create your premium account to unlock exclusive VIP discounts, real-time tracking, and our signature menu.</p>
        </div>

        <div class="relative z-10 text-xs font-bold tracking-widest uppercase text-slate-500 text-right mt-auto pt-20">
            &copy; 2026 Foodie's Heaven.
        </div>
    </div>

    <!-- Left Registration Panel -->
    <div class="w-full lg:w-[60%] flex items-center justify-center p-6 sm:p-12 relative order-1 min-h-screen overflow-y-auto">
        <div class="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-indigo-500/10 blur-[120px] rounded-full pointer-events-none"></div>

        <div class="w-full max-w-lg relative z-10 my-8">
            <!-- Mobile Header -->
            <div class="lg:hidden flex justify-center mb-10">
                <a href="index.php" class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30">
                        <i class="fas fa-leaf text-white text-lg"></i>
                    </div>
                    <span class="text-2xl font-900 tracking-tighter text-white">Foodie's <span class="text-orange-500 italic">Heaven.</span></span>
                </a>
            </div>

            <div class="mb-10 text-center lg:text-left">
                <h2 class="text-3xl font-900 text-white tracking-tight mb-2">Create Profile</h2>
                <p class="text-slate-400 font-medium">Input your personal details to construct your identity.</p>
            </div>

            <?php if ($message != ""): ?>
                <div class="<?= ($msg_type == 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-rose-500/10 border-rose-500/30 text-rose-400' ?> border px-5 py-4 rounded-2xl mb-8 flex items-start gap-4">
                    <i class="fas <?= ($msg_type == 'success') ? 'fa-check-circle' : 'fa-shield-halved' ?> mt-0.5"></i>
                    <p class="text-sm font-semibold leading-relaxed"><?= $message; ?></p>
                </div>
            <?php endif; ?>

            <form name="registerForm" method="POST" onsubmit="return validateForm();" class="space-y-5">

                <!-- Dual Inputs: Name & Phone -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                        <label class="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-2 ml-1">Full Name</label>
                        <div class="relative group">
                            <i class="fas fa-user absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                            <input type="text" name="name" required placeholder="John Doe" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');"
                                   class="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-3.5 pl-12 pr-5 text-white outline-none input-focus font-medium text-sm">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-2 ml-1">Phone Number</label>
                        <div class="relative group">
                            <i class="fas fa-phone absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                            <input type="tel" name="phone" required placeholder="9876543210" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');"
                                   class="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-3.5 pl-12 pr-5 text-white outline-none input-focus font-medium text-sm">
                        </div>
                    </div>
                </div>

                <!-- Email -->
                <div>
                    <label class="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-2 ml-1">Email Identity</label>
                    <div class="relative group">
                        <i class="fas fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                        <input type="email" name="email" required placeholder="you@example.com"
                               class="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-3.5 pl-12 pr-5 text-white outline-none input-focus font-medium text-sm">
                    </div>
                </div>

                <!-- Address -->
                <div>
                    <label class="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-2 ml-1">Primary Address</label>
                    <div class="relative group">
                        <i class="fas fa-location-dot absolute left-5 top-4 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                        <textarea name="address" required placeholder="Enter full delivery address..." rows="3"
                               class="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-3 pl-12 pr-5 text-white outline-none input-focus font-medium text-sm resize-none"></textarea>
                    </div>
                </div>

                <!-- Password -->
                <div>
                    <label class="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-2 ml-1">Master Security Key</label>
                    <div class="relative group">
                        <i class="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                        <input type="password" name="password" id="passwordField" required placeholder="••••••••"
                               class="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-3.5 pl-12 pr-12 text-white outline-none input-focus font-medium text-sm">
                        <button type="button" onclick="togglePassword()" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors focus:outline-none">
                            <i id="eyeIcon" class="fas fa-eye"></i>
                        </button>
                    </div>
                    <p class="text-[10px] text-slate-600 font-semibold mt-2 ml-1 block"><i class="fas fa-shield-check text-orange-500 mr-1"></i> Policy: 8-16 chars. Must include Upper, Lower, Number, and Special (@$!%*?&).</p>
                </div>

                <div class="pt-2">
                    <button type="submit" name="register" class="w-full bg-orange-500 text-white font-900 py-4 rounded-2xl uppercase tracking-widest text-sm smooth-btn shadow-xl shadow-orange-500/20">
                        Create Valid Identity
                    </button>
                </div>
            </form>

            <div class="mt-8 text-center">
                <p class="text-slate-400 text-sm font-medium">
                    Already have an authorized profile?
                    <a href="login.php" class="text-white font-bold hover:text-orange-500 transition-colors ml-1 border-b border-transparent hover:border-orange-500 pb-0.5">Authenticate</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById('passwordField');
            const icon = document.getElementById('eyeIcon');
            if(input.type === 'password') { input.type = 'text'; icon.className = 'fas fa-eye-slash'; }
            else { input.type = 'password'; icon.className = 'fas fa-eye'; }
        }

        function validateForm() {
            const pass = document.getElementById('passwordField').value;
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
            if (!regex.test(pass)) {
                alert("Security Requirement Failed\n\nYour password must strictly be 8-16 characters and include:\n- One Uppercase letter\n- One Lowercase letter\n- One Number\n- One Special character (@$!%*?&)");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
