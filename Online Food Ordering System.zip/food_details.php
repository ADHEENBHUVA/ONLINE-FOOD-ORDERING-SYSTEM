<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// Check if id is set
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

// Security: Use real_escape_string or prepared statements to prevent SQL injection
$food_id = mysqli_real_escape_string($conn, $_GET['id']);

$sql = "SELECT * FROM food_items WHERE food_id = '$food_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 0) {
    echo "<div style='text-align:center; margin-top:50px;'><h2>Food not found!</h2><a href='index.php'>Back to Menu</a></div>";
    exit();
}

$row = mysqli_fetch_assoc($result);

// Get feedback count for this item
$feedback_query = "SELECT COUNT(DISTINCT f.feedback_id) as review_count, AVG(f.rating) as avg_rating
                   FROM feedback f
                   JOIN order_items oi ON f.order_id = oi.order_id
                   WHERE oi.food_id = '$food_id'";
$feedback_res = mysqli_query($conn, $feedback_query);
$feedback_data = mysqli_fetch_assoc($feedback_res);
$review_count = $feedback_data['review_count'] ?? 0;
$avg_rating = round($feedback_data['avg_rating'] ?? 0, 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($row['food_name']) ?> | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #fafafa; -webkit-font-smoothing: antialiased; }
        .glass-nav { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0, 0, 0, 0.05); }
        .smooth-btn { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .smooth-btn:active { transform: scale(0.97); }
    </style>
</head>
<body class="pt-32 pb-20 min-h-screen">

<nav class="glass-nav fixed w-full top-0 z-50 py-4 px-6 md:px-12">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
        <!-- Logo -->
        <a href="index.php" class="flex items-center gap-3 group">
            <div class="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:bg-orange-600 transition-colors">
                <i class="fas fa-leaf text-white text-lg"></i>
            </div>
            <span class="text-xl font-900 tracking-tighter text-slate-900">Foodie's <span class="text-orange-500 italic">Heaven.</span></span>
        </a>
        <a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-5 py-2.5 rounded-full font-bold text-sm smooth-btn flex items-center gap-2">
            <i class="fas fa-arrow-left"></i> Back to Home
        </a>
    </div>
</nav>

<div class="max-w-6xl mx-auto px-6 lg:px-12">
    <div class="bg-white rounded-[3rem] shadow-[0_40px_100px_rgba(0,0,0,0.08)] overflow-hidden flex flex-col lg:flex-row border border-slate-100">

        <!-- Imagery Left -->
        <div class="w-full lg:w-1/2 relative h-[400px] lg:h-[700px] bg-slate-100">
            <img src="images/<?= $row['image']; ?>" class="w-full h-full object-cover" onerror="this.src='https://placehold.co/800x800?text=Premium+Selection'">
            <div class="absolute top-6 left-6 bg-white/90 backdrop-blur text-slate-900 px-4 py-2 rounded-2xl shadow-xl font-bold text-sm flex items-center gap-2">
                <div class="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></div>
                Chef's Special
            </div>
        </div>

        <!-- Content Right -->
        <div class="w-full lg:w-1/2 p-8 lg:p-16 flex flex-col justify-center">

            <div class="mb-8">
                <h1 class="text-4xl lg:text-6xl font-900 text-slate-900 tracking-tighter leading-tight mb-4"><?= htmlspecialchars($row['food_name']) ?></h1>

                <div class="flex flex-wrap items-center gap-4">
                    <div class="bg-slate-50 border border-slate-200 px-4 py-2 rounded-xl flex items-center gap-2 shadow-sm">
                        <i class="fas fa-star text-amber-500"></i>
                        <span class="font-bold text-slate-800"><?= $avg_rating ?> <span class="text-slate-400 font-medium text-sm">(<?= $review_count ?>)</span></span>
                    </div>
                    <?php if($review_count > 50): ?>
                    <div class="bg-orange-500/10 border border-orange-500/20 text-orange-600 px-4 py-2 rounded-xl font-black text-xs uppercase tracking-widest hidden sm:flex items-center gap-2">
                        <i class="fas fa-fire-flame-curved"></i> Highly Recommended
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="w-16 h-1 bg-slate-200 rounded-full mb-8"></div>

            <p class="text-lg text-slate-500 font-medium leading-relaxed mb-10">
                <?= !empty($row['description']) ? nl2br(htmlspecialchars($row['description'])) : 'A premium signature dish meticulously crafted by our executive chefs, featuring only the finest hand-selected ingredients.' ?>
            </p>

            <div class="mt-auto">
                <div class="flex items-baseline gap-2 mb-6">
                    <span class="text-5xl font-900 text-slate-900 tracking-tighter">&#8377;<?= number_format($row['price'], 0) ?></span>
                    <span class="text-slate-400 font-bold uppercase tracking-widest text-xs">/ portion</span>
                </div>

                <form action="cart.php" method="POST" class="flex flex-col sm:flex-row gap-4">
                    <input type="hidden" name="food_id" value="<?= $row['food_id'] ?>">

                    <div class="flex items-center bg-slate-100 rounded-2xl p-2 shrink-0">
                        <button type="button" onclick="let input=this.nextElementSibling; if(parseInt(input.value)>1) input.value=parseInt(input.value)-1;"
                                class="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center text-slate-600 hover:text-orange-500 font-black transition-colors">
                            <i class="fas fa-minus text-xs"></i>
                        </button>
                        <input type="number" name="quantity" value="1" min="1" max="10" readonly class="w-16 text-center bg-transparent font-black text-lg text-slate-900 border-none outline-none appearance-none">
                        <button type="button" onclick="let input=this.previousElementSibling; if(parseInt(input.value)<10) input.value=parseInt(input.value)+1;"
                                class="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center text-slate-600 hover:text-orange-500 font-black transition-colors">
                            <i class="fas fa-plus text-xs"></i>
                        </button>
                    </div>

                    <button type="submit" name="add_to_cart" class="flex-1 bg-orange-500 text-white font-900 text-lg rounded-2xl smooth-btn shadow-xl shadow-orange-500/20 flex items-center justify-center gap-3 py-4 sm:py-0">
                        <i class="fas fa-shopping-bag"></i> Add to Selection
                    </button>
                </form>

                <div class="mt-8 flex items-center gap-6 justify-center sm:justify-start">
                    <div class="flex items-center gap-2 text-slate-400 text-xs font-bold uppercase tracking-wider">
                        <i class="fas fa-truck-fast text-slate-400"></i> Fast Prep
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>
