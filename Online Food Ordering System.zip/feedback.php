<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

if(!isset($_SESSION['customer_id'])){
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];

if(!isset($_GET['order_id'])){
    header("Location: my_orders.php");
    exit();
}

$order_id = $_GET['order_id'];

// Check if feedback already given
$check = mysqli_query($conn,
    "SELECT * FROM feedback
     WHERE order_id='$order_id'
     AND customer_id='$customer_id'"
);

if(mysqli_num_rows($check) > 0){
    // Use an attractive "already submitted" view instead of plain echo
    $already_done = true;
} else {
    $already_done = false;
}

// Submit feedback
if(isset($_POST['submit_feedback'])){
    $rating = mysqli_real_escape_string($conn, $_POST['rating']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $insert = "INSERT INTO feedback (order_id, customer_id, rating, message)
               VALUES ('$order_id', '$customer_id', '$rating', '$message')";

    mysqli_query($conn, $insert);
    header("Location: my_orders.php?status=thankyou");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate Your Experience | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; }
        .executive-form { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); }
        .star-rating { display: flex; flex-direction: row-reverse; justify-content: center; gap: 12px; }
        .star-rating input { display: none; }
        .star-rating label { font-size: 40px; color: #e2e8f0; cursor: pointer; transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); }
        .star-rating input:checked ~ label, .star-rating label:hover, .star-rating label:hover ~ label { color: #f59e0b; transform: scale(1.1); }
        .input-elegant { transition: 0.3s; }
        .input-elegant:focus { outline: none; border-color: #f97316; box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.1); }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6">

<div class="max-w-md w-full relative">
    <!-- Ambient Glows -->
    <div class="absolute -top-10 -left-10 w-40 h-40 bg-orange-500/20 blur-3xl rounded-full pointer-events-none"></div>
    <div class="absolute -bottom-10 -right-10 w-40 h-40 bg-amber-500/10 blur-3xl rounded-full pointer-events-none"></div>

    <div class="mb-8 flex justify-between items-center px-4 relative z-10">
        <a href="my_orders.php" class="text-slate-500 hover:text-orange-500 transition-colors flex items-center gap-2 text-sm font-bold uppercase tracking-widest">
            <i class="fas fa-arrow-left"></i> Live Tracking
        </a>
    </div>

    <div class="executive-form rounded-[2.5rem] shadow-2xl border border-white p-8 sm:p-10 relative z-10 bg-white text-center">

        <?php if($already_done): ?>
            <div class="mb-6">
                <div class="w-24 h-24 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center text-4xl shadow-sm mx-auto mb-6">
                    <i class="fas fa-check-double"></i>
                </div>
                <h2 class="text-3xl font-900 text-slate-800 tracking-tight mb-2">Feedback Received</h2>
                <p class="text-slate-500 font-medium">You have already rated this specific order. Thank you for your valuable insight.</p>
                <a href="my_orders.php" class="mt-8 block w-full bg-slate-900 hover:bg-emerald-500 text-white font-900 py-4 rounded-xl text-xs uppercase tracking-[0.2em] shadow-xl transition-all active:scale-[0.98]">
                    Return to Dashboard
                </a>
            </div>
        <?php else: ?>
            <div class="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-slate-900 text-amber-500 rounded-[2rem] flex items-center justify-center text-4xl shadow-xl shadow-slate-900/20 border-4 border-slate-50 group">
                <i class="fas fa-star group-hover:rotate-180 transition-transform duration-700"></i>
            </div>

            <div class="mt-12 mb-8">
                <h2 class="text-3xl font-900 text-slate-800 tracking-tight">Rate Your Meal</h2>
                <p class="text-slate-400 font-medium text-sm mt-1">Help us perfect the Foodie's Heaven experience.</p>
            </div>

            <form method="POST">
                <div class="mb-8">
                    <p class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Select Quality Score</p>
                    <div class="star-rating">
                        <input type="radio" id="s5" name="rating" value="5" required/><label for="s5" class="fas fa-star"></label>
                        <input type="radio" id="s4" name="rating" value="4"/><label for="s4" class="fas fa-star"></label>
                        <input type="radio" id="s3" name="rating" value="3"/><label for="s3" class="fas fa-star"></label>
                        <input type="radio" id="s2" name="rating" value="2"/><label for="s2" class="fas fa-star"></label>
                        <input type="radio" id="s1" name="rating" value="1"/><label for="s1" class="fas fa-star"></label>
                    </div>
                </div>

                <div class="mb-8 text-left">
                    <label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-1">Additional Comments</label>
                    <textarea name="message" rows="4" placeholder="Tell us about the flavors, presentation, and delivery speed..."
                              class="input-elegant w-full bg-slate-50 border border-slate-200 p-4 rounded-2xl font-medium text-sm text-slate-800 resize-none"></textarea>
                </div>

                <button type="submit" name="submit_feedback"
                        class="w-full bg-slate-900 hover:bg-orange-500 text-white font-900 py-4 rounded-xl text-xs uppercase tracking-[0.2em] shadow-xl hover:shadow-orange-500/20 transition-all active:scale-[0.98]">
                    Submit Evaluation
                </button>
            </form>
        <?php endif; ?>

    </div>
</div>

</body>
</html>
