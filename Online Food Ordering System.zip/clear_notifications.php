<?php
session_start();
include("db.php");

$type = $_GET['type'] ?? '';
$user_id = null;

if ($type == 'customer' && isset($_SESSION['customer_id'])) {
    $user_id = $_SESSION['customer_id'];
    $conn->query("UPDATE notifications SET is_read=1 WHERE user_id='$user_id' AND user_type='customer'");
    header("Location: " . ($_SERVER['HTTP_REFERER'] ?: 'index.php'));
} elseif ($type == 'admin' && isset($_SESSION['admin_id'])) {
    $conn->query("UPDATE notifications SET is_read=1 WHERE user_type='admin'");
    header("Location: Admin/dashboard.php");
} elseif ($type == 'delivery' && isset($_SESSION['delivery_id'])) {
    $conn->query("UPDATE notifications SET is_read=1 WHERE user_type='delivery'");
    header("Location: Delivery/dashboard.php");
} else {
    header("Location: index.php");
}
exit();
?>
