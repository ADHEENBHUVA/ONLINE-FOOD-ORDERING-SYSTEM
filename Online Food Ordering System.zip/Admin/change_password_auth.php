<?php
session_set_cookie_params(86400 * 30);
session_start();
// Import PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$conn = new mysqli("localhost", "root", "", "online_food");

// 1. Get Admin Details
$admin_id = $_SESSION['admin_id'];
$admin = $conn->query("SELECT email FROM admin WHERE admin_id = $admin_id")->fetch_assoc();
$admin_email = $admin['email'];

$message = "";
$step = isset($_SESSION['verified']) ? 2 : 1;

/* --- ACTION: SEND CODE --- */
if (isset($_POST['send_code'])) {
    $otp = rand(100000, 999999);
    $_SESSION['otp_code'] = $otp;
    $subject = "Security Verification Code";
    $mail_message = "Admin Access Request\n\nYour 6-digit verification code is: $otp\nThis code expires in 10 minutes.";
    $headers = "From: security@foodiesheaven.com";

    // Attempt to send physical mail
    @mail($admin_email, $subject, $mail_message, $headers);

    // Fallback UI alert for local development (consistent with forgot_password.php)
    echo "<script>\n        alert('🔐 Local Admin Development: OTP Code is [ " . $otp . " ]');\n    </script>";

    $message = "Verification code sent to $admin_email";
}

/* --- ACTION: VERIFY CODE --- */
if (isset($_POST['verify_code'])) {
    if ($_POST['otp_input'] == $_SESSION['otp_code']) {
        $_SESSION['verified'] = true;
        $step = 2;
        $message = "Code verified. Update your password below.";
    } else {
        $message = "Invalid code. Please try again.";
    }
}

/* --- ACTION: UPDATE PASSWORD --- */
if (isset($_POST['update_pass'])) {
    $hashed = password_hash($_POST['new_pass'], PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE admin SET password = ? WHERE admin_id = ?");
    $stmt->bind_param("si", $hashed, $admin_id);
    if ($stmt->execute()) {
        unset($_SESSION['otp_code'], $_SESSION['verified']);
        $message = "Password updated! Redirecting...";
        header("refresh:2;url=dashboard.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Admin Security Auth</title>
    <?php include("admin_theme_loader.php"); ?>
</head>
<body class="bg-slate-900 text-white flex items-center justify-center min-h-screen font-sans">

<div class="w-full max-w-md bg-slate-800 p-10 rounded-[2.5rem] border border-slate-700 shadow-2xl text-center relative">
    <a href="dashboard.php" class="absolute top-8 left-8 text-slate-500 hover:text-white transition-colors group flex items-center gap-2 text-[10px] font-black uppercase tracking-widest">
        <i class="fas fa-arrow-left group-hover:-translate-x-1 transition-transform"></i> Back
    </a>
    <h1 class="text-3xl font-black italic uppercase mb-2">Security <span class="text-orange-500">Vault</span></h1>
    <p class="text-slate-400 text-xs font-bold uppercase tracking-widest mb-8">Admin Verification</p>

    <?php if($message): ?>
        <p class="mb-6 p-3 bg-orange-500/10 text-orange-400 text-xs font-bold rounded-xl"><?= $message ?></p>
    <?php endif; ?>

    <?php if($step == 1): ?>
        <form method="POST" class="space-y-6">
            <div class="bg-slate-900 p-6 rounded-2xl border border-slate-700">
                <i class="fas fa-shield-halved text-4xl text-orange-500 mb-4"></i>
                <p class="text-sm text-slate-300">Identity check required for <?=$admin_email?></p>
            </div>

            <?php if(!isset($_SESSION['otp_code'])): ?>
                <button name="send_code" class="w-full bg-orange-500 py-4 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-orange-600 transition shadow-lg shadow-orange-500/20">Send Code to Email</button>
            <?php else: ?>
                <input type="text" name="otp_input" maxlength="6" placeholder="000000" class="w-full bg-slate-900 border-2 border-slate-700 p-4 rounded-2xl text-center text-3xl font-black tracking-[0.5em] focus:border-orange-500 outline-none">
                <button name="verify_code" class="w-full bg-white text-slate-900 py-4 rounded-2xl font-black uppercase text-xs tracking-widest transition">Verify Code</button>
            <?php endif; ?>
        </form>

    <?php else: ?>
        <form method="POST" class="space-y-4 text-left">
            <label class="text-[10px] font-black uppercase text-slate-500 ml-2">New Password</label>
            <input type="password" name="new_pass" required class="w-full bg-slate-900 p-4 rounded-2xl border border-slate-700 outline-none focus:border-orange-500">
            <button name="update_pass" class="w-full bg-orange-500 py-4 rounded-2xl font-black uppercase text-xs tracking-widest mt-4">Confirm New Master Key</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>