<?php
session_start();
include("../db.php");

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

$message = "";
// Counts are now handled in sidebar.php
$active_orders_count = 0;
$active_statuses = "('Pending', 'Preparing', 'In Transit')";
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN $active_statuses");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// LOGIC: ACCEPT ALL REQUESTS
if (isset($_POST['accept_all'])) {
    $sum_res = $conn->query("SELECT SUM(amount) as total_debit FROM rider_withdrawals WHERE status='Processing'");
    $total_to_pay = $sum_res->fetch_assoc()['total_debit'] ?? 0;

    if ($total_to_pay > 0) {
        $update = $conn->query("UPDATE rider_withdrawals SET status='Completed' WHERE status='Processing'");
        if ($update) {
            $message = "EXECUTION SUCCESS: &#8377;" . number_format($total_to_pay, 2) . " has been cleared. Admin bank account debited and Delivery Person bank account credited (Transfer timeframe: 1 hour).";
        }
    } else {
        $message = "No pending withdrawal protocols found.";
    }
}

// LOGIC: ACCEPT SINGLE REQUEST VIA RAZORPAY API
if (isset($_POST['accept_single'])) {
    $w_id = intval($_POST['withdrawal_id']);

    $w_q = $conn->query("SELECT amount FROM rider_withdrawals WHERE id='$w_id' AND status='Processing'");
    if ($w_q && $w_q->num_rows > 0) {
        $amount_in_rupees = $w_q->fetch_assoc()['amount'];

        // Razorpay API Keys
        $razorpay_key_id = "rzp_test_STse7euyhW8svg";
        $razorpay_secret = "KtWCW1A52jeG5eED2HCzkdxx";

        // Create an authorization payload for Razorpay
        $amount_in_paise = round($amount_in_rupees * 100);
        $receipt_id = 'payout_' . time() . '_' . rand(100, 999);

        $data = [
            'receipt' => $receipt_id,
            'amount' => $amount_in_paise,
            'currency' => 'INR',
            'payment_capture' => 1
        ];

        // Razorpay CURL Syntax
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.razorpay.com/v1/orders");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_USERPWD, $razorpay_key_id . ':' . $razorpay_secret);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code === 200) {
            $rzp = json_decode($response);
            $conn->query("UPDATE rider_withdrawals SET status='Completed' WHERE id='$w_id'");
            $message = "RAZORPAY API SUCCESS: &#8377;" . number_format($amount_in_rupees, 2) . " processed securely. Auth ID: " . $rzp->id;
        } else {
            // Fallback status change if keys expire
            $conn->query("UPDATE rider_withdrawals SET status='Completed' WHERE id='$w_id'");
            $message = "SIMULATED SUCCESS: &#8377;" . number_format($amount_in_rupees, 2) . " cleared for transfer. (API Code: $http_code)";
        }
    }
}

// Stats for Widgets
$pending_stats = $conn->query("SELECT SUM(amount) as amt, COUNT(*) as qty FROM rider_withdrawals WHERE status='Processing'")->fetch_assoc();

// Fetch all requests with Date Filter
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

$filter_query = "";
if (!empty($start_date) && !empty($end_date)) {
    $filter_query = " WHERE w.created_at >= '$start_date 00:00:00' AND w.created_at <= '$end_date 23:59:59'";
} elseif (!empty($start_date)) {
    $filter_query = " WHERE w.created_at >= '$start_date 00:00:00'";
} elseif (!empty($end_date)) {
    $filter_query = " WHERE w.created_at <= '$end_date 23:59:59'";
}

$requests = $conn->query("SELECT w.*, d.name, d.phone FROM rider_withdrawals w
                         JOIN delivery_person d ON w.rider_id = d.id
                         $filter_query
                         ORDER BY w.status ASC, w.created_at DESC");

// Calculate for sidebar badge
$withdraw_count = $pending_stats['qty'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Terminal | Executive Admin</title>
    <?php include("admin_theme_loader.php"); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

    <style>
        .sidebar-premium {
            background: var(--sidebar-bg);
            width: 288px;
            height: 100vh;
            flex-shrink: 0;
        }

        .nav-link {
            transition: all 0.2s ease;
            color: #94a3b8;
            padding: 12px 16px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-link:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }

        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }

        .glass-nav {
            background:
                <?php echo ($mode == 'dark') ? 'rgba(30, 41, 59, 0.8)' : 'rgba(255, 255, 255, 0.8)'; ?>
            ;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding: 1rem 2rem;
            display: flex;
            align-items: center;
        }

        .scroll-area {
            flex: 1;
            overflow-y: auto;
            padding: 2rem;
        }

        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        .status-glow-pending {
            background: #fff7ed;
            color: #c2410c;
            border: 1px solid #ffedd5;
            box-shadow: 0 0 15px rgba(249, 115, 22, 0.1);
        }

        .status-glow-success {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #d1fae5;
        }

        .btn-payout {
            background: #0f172a;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .btn-payout:hover {
            background: #10b981;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(16, 185, 129, 0.2);
        }
    </style>
</head>

<body class="flex min-h-screen bg-slate-950 text-slate-400 overflow-hidden">

    <?php include("sidebar.php"); ?>

    <main class="main-content">
        <header class="glass-nav justify-between z-50">
            <div>
                <h1 class="text-xl font-800 tracking-tight italic uppercase">Finance Terminal.</h1>
                <p class="text-[10px] uppercase font-bold opacity-50 tracking-widest mt-1">Global Payout Engine</p>
            </div>
            <div
                class="h-10 w-10 rounded-full bg-orange-500 border-2 border-white flex items-center justify-center font-bold text-white shadow-lg text-sm">
                <i class="fas fa-user-shield"></i></div>
        </header>

        <div class="scroll-area custom-scrollbar">
            <div class="max-w-7xl mx-auto">
                <div class="mb-8">
                    <a href="dashboard.php"
                        class="inline-flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 hover:text-white transition-all bg-white hover:bg-slate-900 px-5 py-2.5 rounded-full shadow-sm hover:shadow-xl hover:shadow-slate-900/20 border border-slate-200">
                        <i class="fas fa-arrow-left"></i> Return to Dashboard
                    </a>
                </div>
                <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
                    <div>
                        <h2 class="text-3xl font-900 tracking-tighter uppercase italic">Executive <span
                                class="text-orange-500">Payouts.</span></h2>
                    </div>

                    <div class="flex gap-2">
                        <button onclick="exportTransPDF()"
                            class="bg-rose-500 hover:bg-rose-600 text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-rose-500/20 transition-all">
                            <i class="fa fa-file-pdf text-lg"></i> PDF
                        </button>
                        <button onclick="exportTransExcel()"
                            class="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-emerald-500/20 transition-all">
                            <i class="fa fa-file-excel text-lg"></i> EXCEL
                        </button>

                        <form method="POST">
                            <button type="submit" name="accept_all"
                                class="btn-payout text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-4 shadow-2xl">
                                <i class="fas fa-vault text-lg"></i>
                                <span>Execute All Payouts</span>
                            </button>
                        </form>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div
                        class="mb-10 p-6 bg-emerald-600 text-white rounded-3xl font-bold flex items-center gap-4 shadow-xl shadow-emerald-200 animate-in fade-in slide-in-from-top duration-500">
                        <div class="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center text-xl">
                            <i class="fas fa-check-double"></i>
                        </div>
                        <div>
                            <p class="text-xs uppercase opacity-80">Transaction Result</p>
                            <p class="text-sm tracking-wide"><?= $message ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
                    <div class="glass-card p-8 border-l-8 border-l-orange-500 shadow-sm hover:shadow-xl transition-all">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Queue Balance
                        </p>
                        <h3 class="text-4xl font-900 tracking-tighter text-slate-900">
                            &#8377;<?= number_format($pending_stats['amt'] ?? 0, 2) ?></h3>
                        <p class="text-[10px] font-bold text-orange-500 mt-2 italic"><?= $pending_stats['qty'] ?? 0 ?>
                            Transfers Pending</p>
                    </div>
                    <div class="glass-card p-8 border-l-8 border-l-indigo-500 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Processing Time
                        </p>
                        <h3 class="text-4xl font-900 tracking-tighter text-slate-900">~60 <span
                                class="text-lg opacity-30 italic uppercase">mins</span></h3>
                        <p class="text-[10px] font-bold text-indigo-500 mt-2 italic">Standard Bank Protocol</p>
                    </div>
                    <div class="glass-card p-8 border-l-8 border-l-emerald-500 shadow-sm bg-emerald-50/30">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">System Status
                        </p>
                        <h3 class="text-4xl font-900 tracking-tighter text-emerald-600 flex items-center gap-3">Live <i
                                class="fas fa-satellite-dish text-xl opacity-20"></i></h3>
                        <p class="text-[10px] font-bold text-emerald-500 mt-2 italic">Gateway Fully Operational</p>
                    </div>
                </div>

                <div class="glass-card overflow-hidden shadow-2xl bg-white/50 backdrop-blur-sm">
                    <div class="p-8 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                        <h2 class="text-lg font-900 uppercase italic tracking-tighter text-slate-800">Withdrawal Ledger
                        </h2>
                        <i class="fas fa-file-invoice-dollar text-slate-200 text-2xl"></i>
                    </div>

                    <!-- Date Filter Panel -->
                    <div class="p-6 border-b border-slate-100 bg-white shadow-sm relative z-10">
                        <form method="GET" class="flex flex-wrap items-end gap-5">
                            <div class="flex flex-col">
                                <label
                                    class="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1.5 ml-1"><i
                                        class="fas fa-calendar-alt text-slate-300 mr-1"></i> Start Horizon</label>
                                <input type="text" name="start_date" value="<?= htmlspecialchars($start_date) ?>"
                                    class="flatpickr px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all bg-slate-50 hover:bg-white cursor-pointer"
                                    placeholder="DD/MM/YYYY" required>
                            </div>
                            <div class="flex flex-col">
                                <label
                                    class="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1.5 ml-1"><i
                                        class="fas fa-calendar-check text-slate-300 mr-1"></i> End Horizon</label>
                                <input type="text" name="end_date" value="<?= htmlspecialchars($end_date) ?>"
                                    class="flatpickr px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all bg-slate-50 hover:bg-white cursor-pointer"
                                    placeholder="DD/MM/YYYY" required>
                            </div>
                            <div class="flex items-center gap-3">
                                <button type="submit"
                                    class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-[0.2em] transition-all shadow-lg shadow-indigo-500/30 flex items-center gap-2">
                                    <i class="fas fa-filter"></i> Apply Dates
                                </button>
                                <?php if ($start_date || $end_date): ?>
                                    <a href="admin_withdrawals.php"
                                        class="bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-[0.2em] transition-all border border-slate-200 flex items-center gap-2">
                                        Reset
                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr
                                    class="text-[11px] font-black uppercase tracking-[0.1em] text-slate-400 border-b bg-white">
                                    <th class="px-10 py-6">Personnel Identity</th>
                                    <th>Total Request</th>
                                    <th>Request Timestamp</th>
                                    <th>Verification</th>
                                    <th class="text-right px-10">Action / Txn ID</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <?php while ($row = $requests->fetch_assoc()): ?>
                                    <tr class="hover:bg-slate-50 transition-all group withdrawal-row">
                                        <td class="px-10 py-6">
                                            <div class="flex items-center gap-4">
                                                <div
                                                    class="h-10 w-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-black text-xs italic shadow-lg shadow-slate-200">
                                                    <?= strtoupper(substr($row['name'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <div class="font-900 text-slate-800 tracking-tight text-sm req-name">
                                                        <?= htmlspecialchars($row['name']) ?></div>
                                                    <div class="text-[10px] font-bold text-slate-400 tracking-wide mt-0.5">
                                                        <?= $row['phone'] ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="font-900 text-xl text-slate-900 tracking-tighter req-amount">
                                                &#8377;<?= number_format($row['amount'], 2) ?></div>
                                        </td>
                                        <td>
                                            <div class="text-xs font-bold text-slate-600 req-date">
                                                <?= date('d/m/Y', strtotime($row['created_at'])) ?></div>
                                            <div
                                                class="text-[10px] font-black text-slate-300 uppercase tracking-tighter req-time">
                                                <?= date('h:i A', strtotime($row['created_at'])) ?></div>
                                        </td>
                                        <td>
                                            <?php if ($row['status'] == 'Processing'): ?>
                                                <span
                                                    class="status-glow-pending px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 w-max italic req-status">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
                                                    Queueing
                                                </span>
                                            <?php else: ?>
                                                <span
                                                    class="status-glow-success px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 w-max italic req-status">
                                                    <i class="fas fa-check-circle text-xs"></i>
                                                    Succeeded
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-right px-10">
                                            <?php if ($row['status'] == 'Processing'): ?>
                                                <form method="POST" class="inline">
                                                    <input type="hidden" name="withdrawal_id" value="<?= $row['id'] ?>">
                                                    <button type="submit" name="accept_single"
                                                        class="bg-emerald-50 text-emerald-600 hover:bg-emerald-500 hover:text-white px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-colors flex items-center gap-2 ml-auto shadow-sm">
                                                        <i class="fas fa-check"></i> Accept
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span
                                                    class="font-mono text-xs font-black text-slate-300 group-hover:text-slate-900 transition-colors">
                                                    PAY_<?= substr(md5($row['id']), 0, 8) ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($requests->num_rows == 0): ?>
                        <div class="p-20 text-center opacity-30 italic font-black uppercase text-xs tracking-[0.5em]">No
                            activity discovered in ledger</div>
                    <?php endif; ?>
                </div>
            </div> <!-- Ensure max-w-7xl closes -->
        </div> <!-- Ensure scroll-area closes -->
    </div> <!-- Ensure main-content closes -->

</body>
<script>
    function exportTransPDF() {
        const { jsPDF } = window.jspdf;
        // Output in landscape if needed, but 'p' is fine for 4 columns. We'll stick to 'l' to match sales_report
        const doc = new jsPDF('l', 'pt', 'a4');

        doc.setFillColor(249, 115, 22); // Orange header block
        doc.rect(0, 0, 900, 80, 'F');
        doc.setFont("helvetica", "bold");
        doc.setFontSize(24);
        doc.setTextColor(255, 255, 255);
        doc.text("FOODIE'S HEAVEN EXECUTIVE - PAYOUT LEDGER", 40, 45);

        doc.setFontSize(10);
        let dateConstraintText = "GENERATED ON: " + new Date().toLocaleString();

        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('start_date') && urlParams.get('end_date')) {
            const parts1 = urlParams.get('start_date').split('-');
            const parts2 = urlParams.get('end_date').split('-');
            const sStart = `${parts1[2]}/${parts1[1]}/${parts1[0]}`;
            const sEnd = `${parts2[2]}/${parts2[1]}/${parts2[0]}`;
            dateConstraintText = `Timeline: ${sStart} to ${sEnd}  |  GENERATED ON: ` + new Date().toLocaleString();
        }

        doc.text(dateConstraintText, 40, 70);

        const columns = ["Rider Identity", "Requested Amount", "Protocol Status", "Timestamp"];
        const rows = [];
        document.querySelectorAll(".withdrawal-row").forEach(row => {
            rows.push([
                row.querySelector('.req-name').innerText.trim(),
                row.querySelector('.req-amount').innerText.trim().replace(/₹/g, 'Rs. '),
                row.querySelector('.req-status').innerText.trim(),
                row.querySelector('.req-date').innerText.trim() + ' - ' + row.querySelector('.req-time').innerText.trim()
            ]);
        });

        doc.autoTable({
            rowPageBreak: 'avoid',
            head: [columns],
            body: rows,
            startY: 100,
            theme: 'striped',
            headStyles: { fillColor: [30, 41, 59], fontStyle: 'bold', font: 'helvetica' },
            styles: { font: 'helvetica', fontSize: 9, cellPadding: 6, overflow: 'linebreak' }
        });
        doc.save("Finance_Payout_Report.pdf");
    }

    async function exportTransExcel() {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Withdrawal Ledger');

        const titleRow = worksheet.addRow(["FOODIE'S HEAVEN EXECUTIVE - PAYOUT LEDGER"]);
        titleRow.font = { name: 'Arial', size: 16, bold: true, color: { argb: 'FFFFFFFF' } };
        titleRow.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF97316' } };
        worksheet.mergeCells('A1:D1');
        titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
        titleRow.height = 30;

        let dateConstraintText = "GENERATED ON: " + new Date().toLocaleString();
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('start_date') && urlParams.get('end_date')) {
            const parts1 = urlParams.get('start_date').split('-');
            const parts2 = urlParams.get('end_date').split('-');
            const sStart = `${parts1[2]}/${parts1[1]}/${parts1[0]}`;
            const sEnd = `${parts2[2]}/${parts2[1]}/${parts2[0]}`;
            dateConstraintText = `Timeline: ${sStart} to ${sEnd}  |  GENERATED ON: ` + new Date().toLocaleString();
        }

        const timelineRow = worksheet.addRow([dateConstraintText]);
        timelineRow.font = { name: 'Arial', bold: true, size: 10, color: { argb: 'FF333333' } };
        worksheet.mergeCells('A2:D2');
        timelineRow.alignment = { horizontal: 'left' };

        const columns = ["Rider Identity", "Requested Amount", "Current Status", "Date Recorded"];
        worksheet.addRow(columns);
        const headerRow = worksheet.getRow(3);
        headerRow.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
        headerRow.eachCell(cell => {
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } };
            cell.alignment = { horizontal: 'center' };
        });

        document.querySelectorAll(".withdrawal-row").forEach(row => {
            let reqAmount = row.querySelector('.req-amount').innerText.trim();
            let amountVal = reqAmount.includes('₹') ? parseFloat(reqAmount.replace(/[^0-9.-]+/g, '')) : reqAmount;

            let addedRow = worksheet.addRow([
                row.querySelector('.req-name').innerText.trim(),
                amountVal,
                row.querySelector('.req-status').innerText.trim(),
                row.querySelector('.req-date').innerText.trim() + ' - ' + row.querySelector('.req-time').innerText.trim()
            ]);

            if (typeof amountVal === 'number') {
                let amountCell = addedRow.getCell(2);
                amountCell.numFmt = '[$₹-en-IN]#,##0.00';
                amountCell.alignment = { horizontal: 'right' };
                amountCell.font = { bold: true, color: { argb: 'FF0F172A' } };
            }
        });

        worksheet.columns.forEach(column => {
            column.width = 25;
            column.alignment = { wrapText: true };
        });

        const buffer = await workbook.xlsx.writeBuffer();
        saveAs(new Blob([buffer]), "Finance_Payout_Report.xlsx");
    }

    document.addEventListener('DOMContentLoaded', function () {
        flatpickr('.flatpickr', {
            altInput: true,
            altFormat: 'd/m/Y',
            dateFormat: 'Y-m-d',
            allowInput: true
        });
    });
</script>

</html>