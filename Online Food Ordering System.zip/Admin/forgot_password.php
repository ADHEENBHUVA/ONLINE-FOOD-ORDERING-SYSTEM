<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

$error = "";

if (isset($_POST['send_otp'])) {
    $email = $conn->real_escape_string($_POST['email']);

    // Verify admin email exists
    $stmt = $conn->prepare("SELECT admin_id, name FROM admin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $otp = rand(100000, 999999);

        $_SESSION['admin_reset_email'] = $email;
        $_SESSION['admin_reset_otp'] = $otp;
        $_SESSION['admin_reset_id'] = $row['admin_id'];

        require_once "../email_helper.php";
        $subject = "Foodie's Heaven Admin: Password Recovery";
        $body = "<h3>Master Key Recovery</h3>
                 <p>Hello " . $row['name'] . ",</p>
                 <p>Your Admin Recovery Code is: <strong style='font-size: 24px; color: #f97316;'> " . $otp . " </strong></p>
                 <p>Do not share this code. It is for internal use only.</p>";
        
        sendOrderEmail($email, $subject, $body);

        echo "<script>
            alert('🔐 Local Admin Development: OTP Code is [ " . $otp . " ]');
            window.location.href = 'verify_otp.php';
        </script>";
        exit();
    } else {
        $error = "Unauthorized. Admin Identity not found.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Recovery | Foodie's Heaven</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #020617; overflow: hidden; }
        .input-luxury { background: rgba(30, 41, 59, 0.5); border: 1px solid rgba(71, 85, 105, 0.3); backdrop-filter: blur(8px); transition: 0.4s; }
        .input-luxury:focus { border-color: #f97316; background: rgba(15, 23, 42, 0.8); box-shadow: 0 0 20px rgba(249, 115, 22, 0.1); }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 0% 0%, rgba(249, 115, 22, 0.1) 0, transparent 50%), radial-gradient(at 100% 100%, rgba(59, 130, 246, 0.1) 0, transparent 50%); }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex items-center justify-center relative">

    <div class="mesh-bg"></div>

    <div class="w-full max-w-md p-10 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[2.5rem] shadow-2xl relative z-10 mx-4">

        <div class="text-center mb-10">
            <h1 class="text-3xl font-800 text-white mb-3 tracking-tight">Master Key Recovery</h1>
            <p class="text-slate-400 text-sm leading-relaxed">Provide your authorized admin email address.</p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-2xl mb-8 flex items-center gap-3">
                <i class="fas fa-shield-halved text-lg"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="space-y-6">
            <div class="space-y-3">
                <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Administration Email</label>
                <div class="relative">
                    <i class="fas fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                    <input type="email" name="email" required placeholder="admin@domain.com"
                           class="w-full input-luxury rounded-2xl py-4.5 py-4 pl-14 pr-6 text-white outline-none text-sm">
                </div>
            </div>

            <button type="submit" name="send_otp"
                    class="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:to-orange-700 text-white font-900 py-5 rounded-2xl shadow-xl shadow-orange-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 hover:scale-[1.01]">
                Dispatch OTP <i class="fas fa-paper-plane"></i>
            </button>
        </form>

        <div class="mt-8 text-center border-t border-slate-800/50 pt-6">
            <a href="login.php" class="text-slate-500 hover:text-white text-[10px] font-bold uppercase tracking-[0.2em] transition-colors flex items-center justify-center gap-2">
                <i class="fas fa-arrow-left"></i> Abort Terminal
            </a>
        </div>
    </div>

</body>
</html>