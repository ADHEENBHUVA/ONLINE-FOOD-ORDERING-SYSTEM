<?php
session_set_cookie_params(86400 * 30);
session_start();

// Check Admin Login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

// Database Connection
$conn = new mysqli("localhost", "root", "", "online_food");
if ($conn->connect_error)
    die("Connection Failed: " . $conn->connect_error);

// 3. ADD THE COUNTING CODE HERE (Right after connection)
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// Load Theme Settings (Assuming you have this table for dynamic mode)
$theme_query = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_query);

// Add Food Logic
if (isset($_POST['add_food'])) {
    $food_name = $_POST['food_name'];
    $category_id = $_POST['category_id'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    if ($price <= 0) {
        echo "<script>alert('Price must be greater than 0');</script>";
    } else {
        $image = "";
        if (!empty($_FILES['image']['name'])) {
            $file_name = $_FILES['image']['name'];
            $file_tmp = $_FILES['image']['tmp_name'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            if (strpos($_FILES['image']['type'], 'image/') !== 0) {
                echo "<script>alert('Only authentic image formats are allowed!');</script>";
            } else {
                $image = time() . "_" . $file_name;
                move_uploaded_file($file_tmp, "../images/" . $image);
                $stmt = $conn->prepare("INSERT INTO food_items (food_name, category_id, price, description, image, status) VALUES (?, ?, ?, ?, ?, 'Available')");
                $stmt->bind_param("sidss", $food_name, $category_id, $price, $description, $image);
                $stmt->execute();
                header("Location: manage_food.php?msg=added");
                exit();
            }
        }
    }
}

// Delete Food
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM food_items WHERE food_id=$id");
    header("Location: manage_food.php?msg=deleted");
    exit();
}

$categories = $conn->query("SELECT * FROM categories");

$search_query = "";
$where_clause = "";
if (isset($_GET['search'])) {
    $search_query = $conn->real_escape_string($_GET['search']);
    $where_clause = " WHERE f.food_name LIKE '%$search_query%' OR c.category_name LIKE '%$search_query%' ";
}

$foods = $conn->query("
    SELECT f.*, c.category_name
    FROM food_items f
    LEFT JOIN categories c ON f.category_id = c.category_id
    $where_clause
    ORDER BY f.food_id DESC
");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Management | Executive Admin</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <style>
        :root {
            --primary: #f97316;
        }

        /* 1. LOCK BODY TO SCREEN SIZE */
        body {
            font-family: '<?php echo $theme['font_family'] ?? 'Plus Jakarta Sans'; ?>', sans-serif;
            background-color:
                <?php echo ($theme['mode'] == "dark") ? "#0f172a" : "#f8fafc"; ?>
            ;
            color:
                <?php echo ($theme['mode'] == "dark") ? "#f1f5f9" : "#1e293b"; ?>
            ;
            margin: 0;
            height: 100vh;
            overflow: hidden;
            /* Prevents whole page from scrolling */
        }

        /* 2. LAYOUT WRAPPERS */
        .app-container {
            display: flex;
            height: 100vh;
            width: 100%;
        }

        .sidebar-premium {
            background: #0f172a;
            width: 288px;
            height: 100vh;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
        }

        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
            height: 100vh;
        }

        /* 3. INTERNAL SCROLLABLE AREA */
        .scroll-section {
            flex: 1;
            overflow-y: auto;
            padding: 2rem;
        }

        /* Glass Header (Fixed at top of content area) */
        .glass-nav {
            background:
                <?php echo ($theme['mode'] == 'dark') ? 'rgba(15, 23, 42, 0.8)' : 'rgba(255, 255, 255, 0.8)'; ?>
            ;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            height: 72px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            padding: 0 2rem;
            z-index: 50;
        }

        /* DESIGN COMPONENTS */
        .nav-link {
            transition: all 0.2s ease;
            color: #94a3b8;
        }

        .nav-link:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }

        .nav-link.active {
            background: var(--primary);
            color: white !important;
            box-shadow: 0 10px 15px -3px rgba(249, 115, 22, 0.3);
        }

        .premium-card {
            background:
                <?php echo ($theme['mode'] == "dark") ? "#1e293b" : "#ffffff"; ?>
            ;
            border-radius: 1.5rem;
            border: 1px solid
                <?php echo ($theme['mode'] == "dark") ? "rgba(255,255,255,0.05)" : "#e2e8f0"; ?>
            ;
            transition: all 0.3s ease;
        }

        .input-style {
            background-color:
                <?php echo ($theme['mode'] == "dark") ? "#0f172a" : "#f9fafb"; ?>
            ;
            border: 1.5px solid
                <?php echo ($theme['mode'] == "dark") ? "#334155" : "#e5e7eb"; ?>
            ;
            color: inherit;
        }

        /* 4. MODERN SCROLLBAR */
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 10px;
        }

        .food-row:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
    </style>
</head>

<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo"
                class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

        <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

            <a href="dashboard.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Dashboard</span>
                </div>
            </a>

            <a href="manage_food.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Manage Food</span>
                </div>
                <span
                    class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
            </a>

            <a href="manage_categories.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Categories</span>
                </div>
            </a>

            <a href="manage_promo.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Coupons</span>
                </div>
                <span
                    class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
            </a>

            <a href="manage_orders.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Active Orders</span>
                </div>
                <?php if ($active_orders_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
                        <?php echo $active_orders_count; ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="manage_customers.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Customer Base</span>
                </div>
            </a>
            <a href="manage_vip.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
                <div class="flex items-center gap-3">
                    <i class="fas fa-star w-5"></i>
                    <span class="font-semibold text-sm">VIP Members</span>
                </div>
            </a>

            <div class="my-4 border-t border-slate-800/50 mx-4"></div>
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

            <a href="admin_feedback.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Feedback</span>
                </div>
            </a>

            <a href="manage_delivery_person.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Fleet Status</span>
                </div>
                <span class="relative flex h-2 w-2">
                    <span
                        class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
            </a>

            <a href="admin_withdrawals.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Rider Payouts</span>
                </div>
                <?php if (isset($withdraw_count) && $withdraw_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                        <?= $withdraw_count ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="sales_report.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Sales Analytics</span>
                </div>
            </a>

            <a href="delivery_settings.php"
                class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
                <div class="flex items-center gap-4">
                    <div
                        class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                        <i
                            class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
                    </div>
                    <div class="flex flex-col">
                        <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP
                            Customers</span>
                        <span
                            class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics
                            & Rules</span>
                    </div>
                </div>
                <i
                    class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

                <div
                    class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity">
                </div>
            </a>

            <a href="change_theme.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Change Theme</span>
                </div>
                <span
                    class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
            </a>

            <a href="change_password_auth.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
                <div
                    class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                </div>

                <div class="flex items-center gap-3 relative z-10">
                    <div
                        class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
                        <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
                    </div>

                    <div class="flex flex-col">
                        <span
                            class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access
                            Security</span>
                        <span
                            class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update
                            Master Key</span>
                    </div>
                </div>

                <div class="relative z-10 flex items-center">
                    <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]">
                    </div>
                    <i
                        class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
                </div>
            </a>
        </nav>

        <div class="p-6 border-t border-slate-800/50">
            <a href="logout.php"
                class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
                <i class="fas fa-power-off"></i>
                <span class="font-bold text-sm">Sign Out</span>
            </a>
        </div>
    </aside>

    <div class="main-content">
        <header class="glass-nav justify-between">
            <div>
                <h1 class="text-xl font-800 tracking-tight italic uppercase">Inventory Control</h1>
                <p class="text-[10px] uppercase font-bold opacity-50 tracking-widest mt-1">Global Cuisine Management</p>
            </div>
            <div class="flex items-center gap-3 bg-white/50 px-4 py-2 rounded-2xl border">
                <span class="relative flex h-2 w-2">
                    <span
                        class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span class="text-[10px] font-bold uppercase tracking-widest">Inventory Live</span>
            </div>
        </header>

        <div class="scroll-section custom-scrollbar">

            <?php if(isset($_GET['msg']) && ($_GET['msg'] == 'added' || $_GET['msg'] == 'deleted')): ?>
                <div id="msg-alert" class="mb-6 p-5 rounded-2xl flex items-center justify-center gap-3 shadow-2xl <?= $_GET['msg'] == 'added' ? 'bg-emerald-500' : 'bg-rose-500' ?> text-white transform transition-all duration-500 hover:scale-[1.01] animate-pulse z-50">
                    <i class="fas <?= $_GET['msg'] == 'added' ? 'fa-check-circle' : 'fa-trash-alt' ?> text-xl"></i>
                    <span class="font-bold tracking-wide">
                        <?= $_GET['msg'] == 'added' ? 'Food Item Added Successfully!' : 'Food Item Deleted Permanently.' ?>
                    </span>
                </div>
                <script>
                    setTimeout(() => {
                        const alertBox = document.getElementById('msg-alert');
                        if(alertBox) {
                            alertBox.style.opacity = '0';
                            alertBox.style.transform = 'scale(0.95) translateY(-10px)';
                            setTimeout(() => {
                                alertBox.style.display = 'none';
                                const url = new URL(window.location);
                                url.searchParams.delete('msg');
                                window.history.replaceState({}, document.title, url);
                            }, 500);
                        }
                    }, 10000);
                </script>
            <?php endif; ?>

            <div class="premium-card p-8 mb-10 shadow-xl relative overflow-hidden">
                <div class="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
                    <i data-lucide="plus-circle" class="w-32 h-32 text-orange-500"></i>
                </div>
                <h3 class="text-lg font-bold mb-8 flex items-center gap-3 italic">
                    <i data-lucide="file-plus" class="text-orange-500"></i> Register New Cuisine Item
                </h3>

                <form method="POST" enctype="multipart/form-data"
                    class="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
                    <div class="space-y-2">
                        <label class="text-[10px] font-bold uppercase text-slate-400 ml-1">Item Name</label>
                        <input type="text" name="food_name" placeholder="Item Name" required
                            class="w-full input-style rounded-2xl p-4 text-sm font-medium outline-none">
                    </div>

                    <div class="space-y-2">
                        <label class="text-[10px] font-bold uppercase text-slate-400 ml-1">Category</label>
                        <select name="category_id" required
                            class="w-full input-style rounded-2xl p-4 text-sm font-medium appearance-none outline-none">
                            <option value="">Choose Cuisine...</option>
                            <?php while ($cat = $categories->fetch_assoc()) { ?>
                                <option value="<?= $cat['category_id']; ?>"><?= $cat['category_name']; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="space-y-2">
                        <label class="text-[10px] font-bold uppercase text-slate-400 ml-1">Price (&#8377;)</label>
                        <input type="number" name="price" placeholder="500" min="1" step="1" required
                            class="w-full input-style rounded-2xl p-4 text-sm font-medium outline-none">
                    </div>

                    <div class="space-y-2">
                        <label class="text-[10px] font-bold uppercase text-slate-400 ml-1">
                            Dish Image (All Formats)
                        </label>
                        <input type="file" name="image" accept="image/*" required
                            class="w-full input-style rounded-2xl p-3 text-xs file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-[10px] file:font-bold file:bg-orange-50 file:text-orange-700">
                    </div>

                    <div class="md:col-span-2 space-y-2">
                        <label class="text-[10px] font-bold uppercase text-slate-400 ml-1">Description</label>
                        <textarea name="description" placeholder="Appetizing description..." rows="1"
                            class="w-full input-style rounded-2xl p-4 text-sm font-medium outline-none"></textarea>
                    </div>

                    <div class="md:col-span-3 pt-2">
                        <button type="submit" name="add_food"
                            class="bg-slate-900 text-white font-extrabold px-10 py-4 rounded-2xl shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-3">
                            <i data-lucide="arrow-up-right" class="w-4 h-4"></i> Confirm and Upload Item
                        </button>
                    </div>
                </form>
            </div>

            <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                <h2 class="text-xl font-800 tracking-tight italic uppercase">Active Menu Items</h2>
                <form method="GET" class="w-full md:w-80 relative group">
                    <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4"></i>
                    <input type="text" name="search" placeholder="Search dish..."
                        value="<?= htmlspecialchars($search_query); ?>"
                        class="w-full pl-10 pr-4 py-3 bg-white border rounded-2xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 outline-none transition-all text-sm font-medium">
                </form>
            </div>

            <div class="premium-card overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-slate-50/50 border-b">
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    Cuisine Details</th>
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    Price</th>
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    Status</th>
                                <th
                                    class="px-8 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">
                                    Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php if ($foods->num_rows > 0) {
                                while ($row = $foods->fetch_assoc()) { ?>
                                    <tr class="food-row transition-colors">
                                        <td class="px-8 py-5">
                                            <div class="flex items-center gap-4">
                                                <img src="../images/<?= $row['image']; ?>"
                                                    class="w-12 h-12 object-cover rounded-xl shadow-sm border"
                                                    onerror="this.src='https://placehold.co/100x100?text=Food'">
                                                <div>
                                                    <p class="font-bold text-sm tracking-tight"><?= $row['food_name']; ?></p>
                                                    <span
                                                        class="text-[9px] font-black uppercase tracking-widest text-slate-400"><?= $row['category_name']; ?></span>
                                                    <?php if (!empty($row['description'])): ?>
                                                        <p class="text-[10px] text-slate-500 mt-1.5 max-w-xs line-clamp-2 leading-snug italic"
                                                            title="<?= htmlspecialchars($row['description']) ?>">
                                                            <?= htmlspecialchars($row['description']) ?>
                                                        </p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-8 py-5 font-900 text-emerald-600 italic">
                                            &#8377;<?= number_format($row['price']); ?></td>
                                        <td class="px-8 py-5">
                                            <span
                                                class="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-[9px] font-black uppercase border border-emerald-100">
                                                <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                                                <?= $row['status']; ?>
                                            </span>
                                        </td>
                                        <td class="px-8 py-5 text-center">
                                            <div class="flex justify-center gap-2">
                                                <a href="update_food.php?id=<?= $row['food_id']; ?>"
                                                    class="p-2 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                                </a>
                                                <a href="?delete=<?= $row['food_id']; ?>"
                                                    onclick="return confirm('Delete permanently?')"
                                                    class="p-2 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white transition-all shadow-sm">
                                                    <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php }
                            } else { ?>
                                <tr>
                                    <td colspan="4" class="py-20 text-center opacity-30 italic text-sm">No items found.</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="h-10"></div>
        </div>
    </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>

</html>