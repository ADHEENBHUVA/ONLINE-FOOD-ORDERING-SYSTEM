<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Security Check
if (!isset($_SESSION['admin_id'])) {
    exit("Access Denied");
}
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    exit("Session Timeout. Please login again.");
}
$_SESSION['admin_last_activity'] = time();

// Fetch all order data
$query = "SELECT order_id, total_amount, payment_method, order_status, order_date FROM orders ORDER BY order_id DESC";
$result = $conn->query($query);

// Set headers to force download
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Sales_Report_".date('Y-m-d').".xls");
header("Pragma: no-cache");
header("Expires: 0");

// Create the Excel Table Structure
echo '<table border="1">';
echo '<tr>
        <th style="background-color: #f97316; color: white;">Order ID</th>
        <th style="background-color: #f97316; color: white;">Gross Amount (&#8377;)</th>
        <th style="background-color: #f97316; color: white;">Payment Method</th>
        <th style="background-color: #f97316; color: white;">Status</th>
        <th style="background-color: #f97316; color: white;">Transaction Date</th>
      </tr>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>ORD-' . $row['order_id'] . '</td>';
        echo '<td>&#8377;' . number_format($row['total_amount'], 2) . '</td>';
        echo '<td>' . strtoupper($row['payment_method']) . '</td>';
        echo '<td>' . $row['order_status'] . '</td>';
        echo '<td>' . date("d/m/Y h:i A", strtotime($row['order_date'])) . '</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="5">No records found</td></tr>';
}
echo '</table>';
?>