<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Check Admin Login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

$msg = "";
// Load Theme Settings
include("admin_theme_loader.php");
$theme_query = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_query);

// 3. ADD THE COUNTING CODE HERE (Right after connection)
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

$withdraw_count_res = $conn->query("SELECT COUNT(*) as total FROM rider_withdrawals WHERE status='Processing'");
$withdraw_count = $withdraw_count_res ? $withdraw_count_res->fetch_assoc()['total'] : 0;

// ================= DELETE LOGIC =================
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM delivery_person WHERE id=$id");
    header("Location: manage_delivery_person.php");
    exit();
}

// ================= TOGGLE STATUS LOGIC =================
if (isset($_GET['toggle_status'])) {
    $id = intval($_GET['toggle_status']);
    $result = $conn->query("SELECT status FROM delivery_person WHERE id=$id");
    if($row = $result->fetch_assoc()){
        $new_status = ($row['status'] == "Active") ? "Offline" : "Active";
        $conn->query("UPDATE delivery_person SET status='$new_status' WHERE id=$id");
    }
    header("Location: manage_delivery_person.php");
    exit();
}

// ================= ADD / UPDATE LOGIC =================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $vehicle_type = mysqli_real_escape_string($conn, $_POST['vehicle_type']);
    $vehicle_number = mysqli_real_escape_string($conn, $_POST['vehicle_number']);

    if (isset($_POST['update_delivery'])) {
        if (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
            header("Location: manage_delivery_person.php?msg=invalid_name");
            exit();
        }
        if (!preg_match('/^[0-9]{10}$/', $phone)) {
            header("Location: manage_delivery_person.php?msg=invalid_phone");
            exit();
        }
        $conn->query("UPDATE delivery_person SET name='$name', phone='$phone', email='$email', vehicle_type='$vehicle_type', vehicle_number='$vehicle_number' WHERE id=$id");
        header("Location: manage_delivery_person.php?msg=updated");
        exit();
    }
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $result = $conn->query("SELECT * FROM delivery_person WHERE id=$id");
    $edit_data = $result->fetch_assoc();
}

// UPDATED QUERY: Fetch delivery persons and count their completed orders from the orders table
$delivery = $conn->query("SELECT dp.*,
    (SELECT COUNT(*) FROM orders o WHERE o.delivery_person_id = dp.id AND o.order_status = 'Delivered') as total_orders
    FROM delivery_person dp ORDER BY dp.id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fleet Logistics | Executive Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

    <style>
        :root { --primary: #f97316; }

        body {
            font-family: '<?php echo $theme['font_family'] ?? 'Plus Jakarta Sans'; ?>', sans-serif;
            background-color: <?php echo ($theme['mode']=="dark") ? "#0f172a" : "#f8fafc"; ?>;
            color: <?php echo ($theme['mode']=="dark") ? "#f1f5f9" : "#1e293b"; ?>;
            margin: 0;
            height: 100vh;
            overflow: hidden;
        }

        .app-container { display: flex; height: 100vh; width: 100%; }

        .sidebar-premium {
            background: #0f172a;
            width: 288px;
            height: 100vh;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
        }

        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
            height: 100vh;
        }

        .scroll-area {
            flex: 1;
            overflow-y: auto;
            padding: 2rem;
        }

        .glass-nav {
            background: <?php echo ($theme['mode'] == 'dark') ? 'rgba(15, 23, 42, 0.8)' : 'rgba(255, 255, 255, 0.8)'; ?>;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            height: 72px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            padding: 0 2rem;
            z-index: 50;
        }

        .nav-link { transition: all 0.2s ease; color: #94a3b8; }
        .nav-link:hover { color: #fff; background: rgba(255,255,255,0.05); }
        .nav-link.active { background: var(--primary); color: white !important; box-shadow: 0 10px 15px -3px rgba(249, 115, 22, 0.3); }

        .custom-card {
            background: <?php echo ($theme['mode']=="dark") ? "#1e293b" : "#ffffff"; ?>;
            border-radius: 1.5rem;
            border: 1px solid <?php echo ($theme['mode']=="dark") ? "rgba(255,255,255,0.05)" : "#e2e8f0"; ?>;
        }

        .export-btn {
            padding: 10px 20px; border-radius: 12px; font-weight: 800; font-size: 11px;
            text-transform: uppercase; transition: 0.3s; display: flex; align-items: center; gap: 8px;
        }
        .btn-excel { background: #10b981; color: white; }
        .btn-pdf { background: #f97316; color: white; }

        /* Custom Scrollbar for Sidebar */
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>
<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo" class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

    <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

        <a href="dashboard.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Dashboard</span>
            </div>
        </a>

        <a href="manage_food.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Manage Food</span>
            </div>
            <span class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
        </a>

        <a href="manage_categories.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Categories</span>
            </div>
        </a>

        <a href="manage_promo.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Coupons</span>
            </div>
            <span class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
        </a>

        <a href="manage_orders.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
    <div class="flex items-center gap-3">
        <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
        <span class="font-semibold text-sm">Active Orders</span>
    </div>
    <?php if($active_orders_count > 0): ?>
        <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
            <?php echo $active_orders_count; ?>
        </span>
    <?php endif; ?>
</a>

        <a href="manage_customers.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Customer Base</span>
            </div>
        </a>
        <a href="manage_vip.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
            <div class="flex items-center gap-3">
                <i class="fas fa-star w-5"></i>
                <span class="font-semibold text-sm">VIP Members</span>
            </div>
        </a>

        <div class="my-4 border-t border-slate-800/50 mx-4"></div>
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

        <a href="admin_feedback.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Feedback</span>
            </div>
        </a>

        <a href="manage_delivery_person.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Fleet Status</span>
            </div>
            <span class="relative flex h-2 w-2">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
        </a>

        <a href="admin_withdrawals.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Rider Payouts</span>
            </div>
            <?php if(isset($withdraw_count) && $withdraw_count > 0): ?>
            <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                <?= $withdraw_count ?>
            </span>
            <?php endif; ?>
        </a>

        <a href="sales_report.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Sales Analytics</span>
            </div>
        </a>

        <a href="delivery_settings.php" class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
        <div class="flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                <i class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
            </div>
            <div class="flex flex-col">
                <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP Customers</span>
                <span class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics & Rules</span>
            </div>
        </div>
        <i class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

        <div class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </a>

        <a href="change_theme.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Change Theme</span>
            </div>
            <span class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
        </a>

        <a href="change_password_auth.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

    <div class="flex items-center gap-3 relative z-10">
        <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
            <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
        </div>

        <div class="flex flex-col">
            <span class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access Security</span>
            <span class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update Master Key</span>
        </div>
    </div>

    <div class="relative z-10 flex items-center">
        <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]"></div>
        <i class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
    </div>
</a>
    </nav>

    <div class="p-6 border-t border-slate-800/50">
        <a href="logout.php" class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
            <i class="fas fa-power-off"></i>
            <span class="font-bold text-sm">Sign Out</span>
        </a>
    </div>

</aside>

    <div class="main-content">
        <header class="glass-nav justify-between">
            <div>
                <h1 class="text-xl font-800 tracking-tight italic uppercase">Fleet Logistics</h1>
                <p class="text-[10px] uppercase font-bold opacity-50 tracking-widest mt-1">Personnel Inventory</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="admin_withdrawals.php" class="relative bg-orange-50 text-orange-600 px-4 py-2 rounded-xl border border-orange-200 hover:bg-orange-600 hover:text-white transition-all flex items-center gap-2 shadow-sm group">
                    <i class="fas fa-wallet transition-transform"></i>
                    <span class="text-[10px] font-black uppercase tracking-widest">Withdrawal Status</span>
                    <?php if($withdraw_count > 0): ?>
                        <span class="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-md animate-bounce">
                            <?= $withdraw_count ?>
                        </span>
                    <?php endif; ?>
                </a>

                <button onclick="exportFleetPDF()" class="bg-rose-500 hover:bg-rose-600 text-white px-6 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-rose-500/20 transition-all"><i class="fas fa-file-pdf text-lg"></i> PDF</button>
                <button onclick="exportFleetExcel()" class="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-emerald-500/20 transition-all"><i class="fas fa-file-excel text-lg"></i> EXCEL</button>
            </div>
        </header>

        <div class="scroll-area custom-scrollbar">
            <div class="grid grid-cols-1 xl:grid-cols-3 gap-10">

                <?php if($edit_data): ?>
                <div class="xl:col-span-1">
                    <div class="custom-card p-8 shadow-xl sticky top-0">
                        <h2 class="text-xl font-800 mb-6 flex items-center gap-3 italic"><i data-lucide="edit" class="text-orange-500"></i> Update Rider</h2>
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="id" value="<?= $edit_data['id'] ?? '' ?>">
                            <div>
                                <label class="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-1">Full Identity Name</label>
                                <input type="text" name="name" value="<?= htmlspecialchars($edit_data['name'] ?? '') ?>" required oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');" class="w-full mt-1 px-4 py-3 bg-slate-500/5 border border-slate-400/20 rounded-xl outline-none transition">
                            </div>
                            <div class="grid grid-cols-1 gap-4">
                                <div>
                                    <label class="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-1">Phone</label>
                                    <input type="tel" name="phone" value="<?= htmlspecialchars($edit_data['phone'] ?? '') ?>" required maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');" class="w-full mt-1 px-4 py-3 bg-slate-500/5 border border-slate-400/20 rounded-xl outline-none transition">
                                </div>
                                <div>
                                    <label class="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-1">Email</label>
                                    <input type="email" name="email" value="<?= htmlspecialchars($edit_data['email'] ?? '') ?>" class="w-full mt-1 px-4 py-3 bg-slate-500/5 border border-slate-400/20 rounded-xl outline-none transition">
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <input type="text" name="vehicle_type" placeholder="Vehicle" value="<?= htmlspecialchars($edit_data['vehicle_type'] ?? '') ?>" class="w-full mt-1 px-4 py-3 bg-slate-500/5 border border-slate-400/20 rounded-xl outline-none transition text-sm">
                                <input type="text" name="vehicle_number" placeholder="Plate No." value="<?= htmlspecialchars($edit_data['vehicle_number'] ?? '') ?>" class="w-full mt-1 px-4 py-3 bg-slate-500/5 border border-slate-400/20 rounded-xl outline-none transition text-sm">
                            </div>
                            <div class="pt-4">
                                <button type="submit" name="update_delivery" class="w-full bg-blue-600 text-white font-black py-4 rounded-xl hover:bg-blue-700 transition shadow-lg">Save Changes</button>
                                <a href="manage_delivery_person.php" class="block text-center mt-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Abort Edit</a>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <div class="xl:col-span-<?= $edit_data ? '2' : '3' ?>">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="riderTable">
                        <?php while($row = $delivery->fetch_assoc()): ?>
                        <div class="bg-white rounded-2xl p-6 shadow-md border border-slate-100 relative group overflow-hidden rider-card">
                            <div class="flex justify-between items-start mb-4 relative z-10">
                                <div class="flex items-center gap-3">
                                    <div class="h-12 w-12 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center font-black text-lg"><?= strtoupper(substr($row['name'], 0, 1)) ?></div>
                                    <div>
                                        <div class="font-900 text-lg tracking-tight text-slate-800 rider-name"><?= htmlspecialchars($row['name']) ?></div>
                                        <div class="text-[10px] font-bold text-slate-400 flex items-center gap-1.5 mt-0.5 rider-phone"><?= htmlspecialchars($row['phone']) ?></div>
                                    </div>
                                </div>
                                <span class="px-3 py-1.5 rounded-lg text-[9px] font-black <?= $row['status'] == "Active" ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400' ?> uppercase tracking-widest rider-status"><?= $row['status'] ?></span>
                            </div>

                            <div class="bg-slate-50 rounded-xl p-4 mb-5 border border-slate-100 relative z-10 flex justify-between items-center">
                                <div><p class="text-[9px] font-black text-slate-400 uppercase tracking-widest">Vehicle</p><p class="text-sm font-800 text-slate-700 rider-v-type"><?= htmlspecialchars($row['vehicle_type']) ?></p></div>
                                <div class="text-center"><p class="text-[9px] font-black text-slate-400 uppercase tracking-widest">Orders</p><p class="text-sm font-800 text-slate-700 rider-orders"><?= $row['total_orders'] ?></p></div>
                                <div class="text-right"><p class="text-[9px] font-black text-slate-400 uppercase tracking-widest">Plate</p><p class="text-xs font-black text-orange-500 uppercase tracking-widest rider-v-num"><?= htmlspecialchars($row['vehicle_number']) ?></p></div>
                            </div>

                            <div class="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                                <a href="delivery_person_details.php?id=<?= $row['id'] ?>" class="relative h-9 w-9 flex items-center justify-center bg-teal-50 text-teal-600 rounded-xl hover:bg-teal-500 hover:text-white transition-all shadow-sm" title="Performance Details">
                                    <i data-lucide="line-chart" class="w-4 h-4"></i>
                                    <?php if($row['total_orders'] > 0): ?>
                                    <span class="absolute -top-2 -right-2 bg-orange-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full border border-white shadow-sm">
                                        <?= $row['total_orders'] ?>
                                    </span>
                                    <?php endif; ?>
                                </a>

                                <a href="?edit=<?= $row['id'] ?>" class="h-9 w-9 flex items-center justify-center bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-500 hover:text-white transition-all shadow-sm"><i data-lucide="edit-2" class="w-4 h-4"></i></a>
                                <a href="?toggle_status=<?= $row['id'] ?>" class="h-9 w-9 flex items-center justify-center bg-amber-50 text-amber-600 rounded-xl hover:bg-amber-500 hover:text-white transition-all shadow-sm"><i data-lucide="power" class="w-4 h-4"></i></a>
                                <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Remove rider?')" class="h-9 w-9 flex items-center justify-center bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-500 hover:text-white transition-all shadow-sm"><i data-lucide="trash-2" class="w-4 h-4"></i></a>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();

        function exportFleetPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('p', 'pt', 'a4');
            doc.setFillColor(249, 115, 22);
            doc.rect(0, 0, 600, 80, 'F');
            doc.setFont("helvetica", "bold");
            doc.setFontSize(24);
            doc.setTextColor(255, 255, 255);
            doc.text("FLEET LOGISTICS PERSONNEL LOG", 40, 45);
            doc.setFontSize(10);
            doc.text("GENERATED ON: " + new Date().toLocaleString(), 40, 65);
            const columns = ["Rider Name", "Phone", "Status", "Total Orders", "Vehicle", "Plate Number"];
            const rows = [];
            document.querySelectorAll(".rider-card").forEach(card => {
                rows.push([
                    card.querySelector('.rider-name').innerText.trim(),
                    card.querySelector('.rider-phone').innerText.trim(),
                    card.querySelector('.rider-status').innerText.trim(),
                    card.querySelector('.rider-orders').innerText.trim(),
                    card.querySelector('.rider-v-type').innerText.trim(),
                    card.querySelector('.rider-v-num').innerText.trim()
                ]);
            });
            doc.autoTable({ rowPageBreak: 'avoid', head: [columns], body: rows, startY: 100, theme: 'striped', headStyles: { fillColor: [30, 41, 59], fontStyle: 'bold' }, styles: { fontSize: 9 } });
            doc.save("Fleet_Inventory_Report.pdf");
        }

        async function exportFleetExcel() {
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Fleet Personnel');
            const titleRow = worksheet.addRow(["ANNAPURNA EXECUTIVE - OFFICIAL FLEET INVENTORY"]);
            titleRow.font = { name: 'Arial Black', size: 16, bold: true, color: { argb: 'FFFFFFFF' } };
            titleRow.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF97316' } };
            worksheet.mergeCells('A1:E1');
            titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
            titleRow.height = 35;
            const headerRow = worksheet.addRow(["Rider Name", "Phone", "Current Status", "Total Orders", "Vehicle Type", "Plate Number"]);
            headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
            headerRow.eachCell(cell => { cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } }; });
            document.querySelectorAll(".rider-card").forEach(card => {
                worksheet.addRow([
                    card.querySelector('.rider-name').innerText.trim(),
                    card.querySelector('.rider-phone').innerText.trim(),
                    card.querySelector('.rider-status').innerText.trim(),
                    card.querySelector('.rider-orders').innerText.trim(),
                    card.querySelector('.rider-v-type').innerText.trim(),
                    card.querySelector('.rider-v-num').innerText.trim()
                ]);
            });
            worksheet.columns.forEach(col => col.width = 25);
            worksheet.getColumn(4).width = 15; // Make the 'Total Orders' column a bit narrower
            const buffer = await workbook.xlsx.writeBuffer();
            saveAs(new Blob([buffer]), "Fleet_Logistics_Inventory.xlsx");
        }
    </script>
</body>
</html>