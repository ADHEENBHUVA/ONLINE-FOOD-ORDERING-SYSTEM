<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

if (!isset($_SESSION['admin_id'])) {
    exit("Unauthorized Access");
}
// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    exit("Session Timeout. Please login again.");
}
$_SESSION['admin_last_activity'] = time();

// Set browser headers to force Excel download
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Customer_Registry_".date('Y-m-d').".xls");
header("Pragma: no-cache");
header("Expires: 0");

// Fetch Customer Data with Last Access Join
$query = "SELECT c.customer_id, c.name, c.email, c.phone, c.created_at, MAX(l.login_time) AS last_login
          FROM customers c
          LEFT JOIN customer_login_history l ON c.customer_id = l.customer_id
          GROUP BY c.customer_id
          ORDER BY c.customer_id ASC";
$result = $conn->query($query);

echo '<table border="1">';
echo '<tr>
        <th style="background-color: #f97316; color: white;">UID</th>
        <th style="background-color: #f97316; color: white;">Name</th>
        <th style="background-color: #f97316; color: white;">Email</th>
        <th style="background-color: #f97316; color: white;">Phone</th>
        <th style="background-color: #f97316; color: white;">Registration Date</th>
        <th style="background-color: #f97316; color: white;">Last Access Date & Time</th>
      </tr>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Format the last login date
        $access = ($row['last_login']) ? date("d/m/Y h:i A", strtotime($row['last_login'])) : 'Never Logged In';

        echo '<tr>';
        echo '<td>#' . $row['customer_id'] . '</td>';
        echo '<td>' . htmlspecialchars($row['name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['email']) . '</td>';
        echo '<td>' . $row['phone'] . '</td>';
        echo '<td>' . date("d/m/Y", strtotime($row['created_at'])) . '</td>';
        echo '<td>' . $access . '</td>';
        echo '</tr>';
    }
}
echo '</table>';
?>