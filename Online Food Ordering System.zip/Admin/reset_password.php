<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

if (!isset($_SESSION['admin_reset_authorized']) || $_SESSION['admin_reset_authorized'] !== true) {
    header("Location: login.php");
    exit();
}

$error = "";
$success = "";

if (isset($_POST['reset_secure'])) {
    $password = $_POST['npass'];
    $confirm  = $_POST['cpass'];

    if ($password !== $confirm) {
        $error = "Mismatch Error: Security keys do not strongly mirror each other.";
    } else {
        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';
        if (!preg_match($pattern, $password)) {
            $error = "Violation: Key must be 8-16 chars with Upper, Lower, Number & Special Char.";
        } else {
            $email = $_SESSION['admin_reset_email'];
            $stmt = $conn->prepare("UPDATE admin SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $password, $email);

            if ($stmt->execute()) {
                unset($_SESSION['admin_reset_email'], $_SESSION['admin_reset_otp'], $_SESSION['admin_reset_id'], $_SESSION['admin_reset_authorized']);
                $success = "Success! Authentication array overwritten. Proceed to terminal.";
                echo "<script>setTimeout(function(){ window.location.href = 'login.php'; }, 2000);</script>";
            } else {
                $error = "Critical System Error executing update protocol.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forge Master Key | Foodie's Heaven</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #020617; overflow: hidden; }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 100% 0%, rgba(59, 130, 246, 0.15) 0, transparent 50%), radial-gradient(at 0% 100%, rgba(249, 115, 22, 0.1) 0, transparent 50%); }
        .input-luxury { background: rgba(30, 41, 59, 0.5); border: 1px solid rgba(71, 85, 105, 0.3); backdrop-filter: blur(8px); transition: 0.4s; }
        .input-luxury:focus { border-color: #f97316; background: rgba(15, 23, 42, 0.8); box-shadow: 0 0 20px rgba(249, 115, 22, 0.1); }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex items-center justify-center relative">

    <div class="mesh-bg"></div>

    <div class="w-full max-w-md p-10 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[2.5rem] shadow-2xl relative z-10 mx-4">

        <div class="text-center mb-10">
            <h1 class="text-3xl font-800 text-white mb-3 tracking-tight">Forge Master Key</h1>
            <p class="text-slate-400 text-sm leading-relaxed px-4">Create your new administrative access authorization. Make it robust.</p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-500 p-4 rounded-2xl mb-8 flex items-center gap-3">
                <i class="fas fa-triangle-exclamation"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <?php if($success != ""): ?>
            <div class="bg-emerald-500/10 border border-emerald-500/50 text-emerald-400 p-4 rounded-2xl mb-8 flex items-center gap-3">
                <i class="fas fa-check-double"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest"><?php echo $success; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="space-y-6" onsubmit="return validatePassword();">
            <div class="space-y-3">
                <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 ml-1">New Core Key</label>
                <div class="relative">
                    <i class="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                    <input type="password" name="npass" id="npass" required placeholder="••••••••"
                           class="w-full input-luxury rounded-2xl py-4.5 py-4 pl-14 pr-12 text-white outline-none text-sm">
                    <button type="button" onclick="toggleVisibility('npass', 'eye1')" class="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-orange-500 focus:outline-none">
                        <i id="eye1" class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div class="space-y-3">
                <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Verify Symmetry</label>
                <div class="relative">
                    <i class="fas fa-lock-open absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                    <input type="password" name="cpass" id="cpass" required placeholder="••••••••"
                           class="w-full input-luxury rounded-2xl py-4.5 py-4 pl-14 pr-12 text-white outline-none text-sm">
                    <button type="button" onclick="toggleVisibility('cpass', 'eye2')" class="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-orange-500 focus:outline-none">
                        <i id="eye2" class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" name="reset_secure" <?php if($success != "") echo 'disabled'; ?>
                    class="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:to-blue-700 disabled:opacity-50 text-white font-900 py-5 rounded-2xl shadow-xl shadow-blue-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 hover:scale-[1.01]">
                Commit Override <i class="fas fa-upload"></i>
            </button>
        </form>

    </div>

    <script>
        function toggleVisibility(inputId, iconId) {
            const passInput = document.getElementById(inputId);
            const eyeIcon = document.getElementById(iconId);
            if (passInput.type === "password") {
                passInput.type = "text";
                eyeIcon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passInput.type = "password";
                eyeIcon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        function validatePassword() {
            const p1 = document.getElementById('npass').value;
            const p2 = document.getElementById('cpass').value;
            if(p1 !== p2){ alert("Keys do not match!"); return false; }
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
            if (!regex.test(p1)) {
                alert("Security Violation: Ensure 8-16 chars with Upper, Lower, Num & Special.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
