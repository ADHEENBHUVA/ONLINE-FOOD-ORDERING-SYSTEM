<?php
session_set_cookie_params(86400 * 30);
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "online_food");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$error = "";

if (isset($_GET['msg']) && $_GET['msg'] === 'timeout') {
    $error = "Session expired due to 30 minutes of inactivity. Please login again.";
}

if (isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Complexity Validation Logic
    $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';

    if (!preg_match($pattern, $password)) {
        $error = "Security Policy: Password requires 8-16 chars, Uppercase, Lowercase, Number & Special Char.";
    } else {
        $sql = "SELECT * FROM admin WHERE email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            // Checking plain text (Update to password_verify if you hash passwords)
            if ($password == $row['password']) {
                $_SESSION['admin_id'] = $row['admin_id'];
                $_SESSION['admin_name'] = $row['name'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Authentication failed: Invalid security key.";
            }
        } else {
            $error = "Access Denied: Admin identity not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Login | Foodie's Heaven</title>
    <?php include("admin_theme_loader.php"); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #020617;
            margin: 0;
            overflow: hidden;
        }

        .side-image {
            background: linear-gradient(to right, rgba(2, 6, 23, 0) 0%, rgba(2, 6, 23, 1) 100%),
                        url('https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=1200&q=80');
            background-size: cover;
            background-position: center;
        }

        .input-luxury {
            background: rgba(30, 41, 59, 0.5);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(8px);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .input-luxury:focus {
            border-color: #f97316;
            background: rgba(15, 23, 42, 0.8);
            box-shadow: 0 0 20px rgba(249, 115, 22, 0.1);
            transform: translateY(-1px);
        }

        .btn-glow:hover {
            box-shadow: 0 0 25px rgba(249, 115, 22, 0.4);
            transform: scale(1.01);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .animate-fade { animation: fadeIn 0.8s ease-out forwards; }

        .glass-tag {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(4px);
        }
    </style>
</head>
<body class="text-slate-200">

    <div class="flex min-h-screen">
        <div class="hidden lg:flex lg:w-[55%] side-image flex-col justify-between p-16 relative">
            <div class="z-10 flex items-center gap-4">
                <div class="h-12 w-12 bg-orange-500 rounded-2xl flex items-center justify-center shadow-2xl shadow-orange-500/40 rotate-12">
                    <i class="fas fa-utensils text-white text-xl"></i>
                </div>
                <h1 class="text-2xl font-800 tracking-tighter text-white uppercase italic">Foodie's <span class="text-orange-500">Heaven</span></h1>
            </div>

            <div class="z-10 max-w-xl">
                <span class="px-4 py-2 rounded-full glass-tag text-orange-500 text-[10px] font-black uppercase tracking-[0.3em] mb-6 inline-block">System Terminal v4.0</span>
                <h2 class="text-7xl font-900 text-white leading-tight mb-8 tracking-tighter">
                    Elevated <br><span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Operations.</span>
                </h2>
                <p class="text-lg text-slate-400 font-medium leading-relaxed max-w-md">
                    Secure gateway for Foodie's Heaven executive management. Monitor real-time logistics and kitchen performance.
                </p>
            </div>

            <div class="z-10 flex items-center gap-8 text-slate-500 text-[10px] font-bold uppercase tracking-widest">
                <span>&copy; 2026 Admin Panel</span>
                <span class="h-1 w-1 bg-slate-700 rounded-full"></span>
                <span>Encrypted Connection</span>
            </div>
        </div>

        <div class="w-full lg:w-[45%] flex items-center justify-center p-8 lg:p-20 bg-[#020617] relative">

            <div class="w-full max-w-md animate-fade">
                <div class="mb-12">
                    <h3 class="text-3xl font-800 text-white mb-2 tracking-tight">Executive Login</h3>
                    <p class="text-slate-500 text-sm">Please provide your authorized master credentials.</p>
                </div>

                <?php if ($error != ""): ?>
                    <div class="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-2xl mb-8 flex items-center gap-3 text-xs font-bold uppercase tracking-tight">
                        <i class="fas fa-shield-halved"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <form name="loginForm" method="POST" onsubmit="return validateForm();" class="space-y-7">
                    <div class="space-y-3">
                        <label class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Administration Email</label>
                        <div class="relative">
                            <i class="fas fa-at absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                            <input type="email" name="email" required placeholder="name@foodies.com"
                                   class="w-full input-luxury rounded-2xl py-4.5 py-4 pl-14 pr-6 text-white outline-none text-sm">
                        </div>
                    </div>

                    <div class="space-y-3">
                        <div class="flex justify-between items-center ml-1">
                            <label class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Security Key</label>
                        </div>
                        <div class="relative group">
                            <i class="fas fa-key absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>

                            <input type="password" name="password" id="password" required placeholder="••••••••••••"
                                   class="w-full input-luxury rounded-2xl py-4 pl-14 pr-14 text-white outline-none text-sm">

                            <button type="button" onclick="togglePassword()" class="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-orange-500 transition-colors focus:outline-none">
                                <i id="eyeIcon" class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="glass-tag p-4 rounded-2xl">
                        <div class="flex items-start gap-3">
                            <i class="fas fa-circle-info text-orange-500 mt-0.5"></i>
                            <p class="text-[10px] text-slate-400 leading-relaxed font-semibold">
                                PASSWORD POLICY: 8-16 characters including at least one uppercase, one lowercase, one number and one special symbol.
                            </p>
                        </div>
                    </div>

                    <button type="submit" name="login"
                            class="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:to-orange-700 text-white font-900 py-5 rounded-2xl shadow-2xl shadow-orange-500/20 transition-all btn-glow uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3">
                        Initialize Access <i class="fas fa-arrow-right-long"></i>
                    </button>
                </form>

                <div class="mt-16 text-center">
                    <a href="forgot_password.php" class="text-slate-500 hover:text-orange-500 text-[10px] font-bold uppercase tracking-[0.2em] transition-colors inline-block mb-4"><i class="fas fa-lock"></i> Lost Master Key?</a>
                    <p class="text-slate-600 text-[9px] font-black uppercase tracking-[0.4em]">
                        Protected by Foodie's Secure-Cloud &bull; 2026
                    </p>
                </div>
            </div>

            <div class="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 blur-[100px] rounded-full"></div>
            <div class="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/5 blur-[80px] rounded-full"></div>
        </div>
    </div>

    <script>
        // ✅ Toggle Password Visibility Logic
        function togglePassword() {
            const passField = document.getElementById("password");
            const eyeIcon = document.getElementById("eyeIcon");

            if (passField.type === "password") {
                passField.type = "text";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            } else {
                passField.type = "password";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            }
        }

        // ✅ Validation Logic
        function validateForm() {
            let email = document.forms[0]["email"].value;
            let password = document.forms[0]["password"].value;

            // Regex: 8-16 chars, Uppercase, Lowercase, Number, Special Char
            let passRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;

            if (email.trim() == "" || password.trim() == "") {
                alert("Credentials required for initialization.");
                return false;
            }

            if (!passRegex.test(password)) {
                alert("Security Protocol Refused: Password does not meet complexity requirements.");
                return false;
            }

            return true;
        }
    </script>

</body>
</html>