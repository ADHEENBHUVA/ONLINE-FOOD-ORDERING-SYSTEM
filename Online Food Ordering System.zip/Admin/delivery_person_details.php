<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

if (!isset($_GET['id'])) {
    header("Location: manage_delivery_person.php");
    exit();
}

$id = (int)$_GET['id'];
$rider_query = $conn->query("SELECT * FROM delivery_person WHERE id='$id'");
if($rider_query->num_rows == 0) {
    echo "Rider not found."; exit;
}
$rider = $rider_query->fetch_assoc();

// Aggregations
$wallet_balance = (float)($rider['wallet_balance'] ?? 0);

// Fetch All Orders
$orders_query = $conn->query("SELECT * FROM orders WHERE delivery_person_id='$id' ORDER BY order_date DESC");
$total_orders = $orders_query->num_rows;

$delivered_count = 0;
$cod_count = 0;
$upi_count = 0;

$orders_html = "";
if($total_orders == 0) {
    $orders_html = "<tr><td colspan='6' class='text-center py-8 text-slate-500 font-bold'>No orders handled yet.</td></tr>";
} else {
    while($ord = $orders_query->fetch_assoc()) {
        if($ord['delivery_status'] == 'Delivered') $delivered_count++;

        $pm = strtoupper($ord['payment_method']);
        $upi_count++;

        $statusColor = 'bg-slate-100 text-slate-600';
        if($ord['delivery_status'] == 'Delivered') $statusColor = 'bg-emerald-100 text-emerald-700';
        else if($ord['delivery_status'] == 'Picked Up') $statusColor = 'bg-blue-100 text-blue-700';

        $orders_html .= "
        <tr class='border-b border-slate-50 hover:bg-slate-50/50 transition-colors'>
            <td class='px-6 py-4 text-xs font-black text-slate-400'>ORD-{$ord['order_id']}</td>
            <td class='px-6 py-4 font-bold text-sm text-slate-700'>" . date('d/m/Y h:i A', strtotime($ord['order_date'])) . "</td>
            <td class='px-6 py-4 text-sm font-bold text-slate-800'>&#8377;" . number_format($ord['total_amount'],2) . "</td>
            <td class='px-6 py-4'>
                <span class='px-3 py-1 rounded-lg text-[10px] font-black tracking-widest uppercase bg-slate-100 text-slate-600'>{$pm}</span>
            </td>
            <td class='px-6 py-4'>
                <span class='px-3 py-1 rounded-lg text-[10px] font-black tracking-widest uppercase {$statusColor}'>{$ord['delivery_status']}</span>
            </td>
            <td class='px-6 py-4 text-xs font-semibold text-slate-500'>" . htmlspecialchars($ord['address']) . "</td>
        </tr>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Profile | <?= htmlspecialchars($rider['name']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8fafc; color: #0f172a; }
        .glass-card { background: white; border: 1px solid rgba(0,0,0,0.04); border-radius: 2rem; box-shadow: 0 20px 40px -10px rgba(0,0,0,0.05); }
    </style>
</head>
<body class="flex min-h-screen">
    <aside class="w-72 bg-[#0f172a] text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl z-50">
        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <h1 class="text-white font-900 italic text-2xl tracking-tighter uppercase">Foodie's <span class="text-orange-500">Admin</span></h1>
        </div>
        <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto">
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Back to Operations</p>
            <a href="manage_delivery_person.php" class="flex items-center gap-3 px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <i data-lucide="arrow-left" class="w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Return to Fleet</span>
            </a>
            <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <i data-lucide="home" class="w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Home Dashboard</span>
            </a>
        </nav>
    </aside>

    <main class="flex-1 h-screen overflow-y-auto p-4 md:p-8">
        <div class="max-w-6xl mx-auto">

            <div class="flex justify-between items-center mb-10">
                <div>
                    <a href="manage_delivery_person.php" class="text-slate-400 hover:text-orange-500 font-bold text-sm flex items-center gap-2 mb-3 transition">
                        <i data-lucide="arrow-left" class="w-4 h-4"></i> Back to Fleet
                    </a>
                    <h1 class="text-4xl font-900 tracking-tighter text-slate-900 flex items-center gap-3">
                        <i data-lucide="user-check" class="text-orange-500 w-8 h-8"></i> <?= htmlspecialchars($rider['name']) ?>
                    </h1>
                </div>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-600 font-bold text-xs uppercase tracking-widest flex items-center gap-2">
                    <div class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                    Active Profile
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="glass-card p-6 flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center"><i data-lucide="wallet" class="w-6 h-6"></i></div>
                    <div>
                        <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-0.5">Wallet Balance</p>
                        <h3 class="text-2xl font-900 text-slate-800">&#8377;<?= number_format($wallet_balance, 2) ?></h3>
                    </div>
                </div>
                <div class="glass-card p-6 flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-orange-50 text-orange-500 flex items-center justify-center"><i data-lucide="package" class="w-6 h-6"></i></div>
                    <div>
                        <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-0.5">Total Orders</p>
                        <h3 class="text-2xl font-900 text-slate-800"><?= $total_orders ?></h3>
                    </div>
                </div>
                <div class="glass-card p-6 flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center"><i data-lucide="check-circle" class="w-6 h-6"></i></div>
                    <div>
                        <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-0.5">Completed</p>
                        <h3 class="text-2xl font-900 text-slate-800"><?= $delivered_count ?></h3>
                    </div>
                </div>
                <div class="glass-card p-6 flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-purple-50 text-purple-500 flex items-center justify-center"><i data-lucide="credit-card" class="w-6 h-6"></i></div>
                    <div>
                        <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-0.5">Digital Paid</p>
                        <h3 class="text-xl font-900 text-slate-800"><?= $upi_count ?></h3>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                <div class="glass-card p-8 lg:col-span-1 border-t-4 border-t-slate-800">
                    <h3 class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-6">Profile Details</h3>

                    <div class="space-y-6">
                        <div>
                            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Phone Number</p>
                            <p class="font-bold text-slate-800 mt-1"><?= htmlspecialchars($rider['phone']) ?></p>
                        </div>
                        <div>
                            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Email Address</p>
                            <p class="font-bold text-slate-800 mt-1"><?= htmlspecialchars($rider['email']) ?></p>
                        </div>
                        <div>
                            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Vehicle Number</p>
                            <p class="font-black text-lg text-slate-800 mt-1 px-3 py-1 bg-slate-100 rounded-lg inline-block uppercase tracking-widest border border-slate-200"><?= htmlspecialchars($rider['vehicle_number']) ?></p>
                        </div>
                        <div class="pt-6 border-t border-slate-100">
                            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Withdrawal System</p>
                            <p class="text-xs text-slate-500 font-medium leading-relaxed">
                                Withdrawals are handled manually. The rider's wallet tracks unpaid commissions. When you pay them to their bank, you can manually reset their wallet via the <a href="rider_wallets.php" class="text-orange-500 hover:underline font-bold">Rider Wallets</a> page.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="glass-card p-0 lg:col-span-2 overflow-hidden border-t-4 border-t-orange-500 flex flex-col">
                    <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 flex-wrap gap-4">
                        <h3 class="text-[10px] font-black uppercase tracking-widest text-slate-400">Order Delivery History</h3>
                        <div class="flex gap-2">
                            <button onclick="exportToPDFStyled()" class="bg-slate-900 text-white px-4 py-2 rounded-xl font-black text-[10px] uppercase flex items-center gap-2 tracking-widest hover:bg-black transition-all">
                                <i class="fa fa-file-pdf text-orange-500"></i> PDF Report
                            </button>
                            <button onclick="exportToExcelStyled()" class="bg-emerald-600 text-white px-4 py-2 rounded-xl font-black text-[10px] uppercase flex items-center gap-2 tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100">
                                <i class="fa fa-file-excel"></i> Excel Report
                            </button>
                        </div>
                    </div>
                    <div class="overflow-x-auto flex-1 h-[400px]">
                        <table class="w-full text-left border-collapse" id="deliveryTable">
                            <thead class="sticky top-0 bg-slate-50/90 backdrop-blur-md shadow-sm">
                                <tr>
                                    <th class="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">ID</th>
                                    <th class="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Date</th>
                                    <th class="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Amt</th>
                                    <th class="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Type</th>
                                    <th class="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Status</th>
                                    <th class="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Drop</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?= $orders_html ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </main>
    <script>
        lucide.createIcons();

        // 2. PDF EXPORT WITH STYLING
        function exportToPDFStyled() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('l', 'pt', 'a4');

            // Draw Orange Header Block
            doc.setFillColor(249, 115, 22); // Orange
            doc.rect(0, 0, 900, 80, 'F');

            doc.setFont("helvetica", "bold");
            doc.setFontSize(24);
            doc.setTextColor(255, 255, 255);
            doc.text("DELIVERY PERSON REPORT - <?= strtoupper(htmlspecialchars($rider['name'] ?? '')) ?>", 40, 45);

            doc.setFontSize(10);
            doc.text("Timeline: All Time  |  GENERATED ON: " + new Date().toLocaleString(), 40, 75);

            const columns = ["ID", "Date", "Amt", "Type", "Status", "Drop"];
            const rows = [];

            document.querySelectorAll("#deliveryTable tbody tr").forEach(tr => {
                if(tr.cells.length > 1) {
                    rows.push([
                        tr.cells[0].innerText.trim(),
                        tr.cells[1].innerText.trim(),
                        tr.cells[2].innerText.trim().replace(/₹/g, 'Rs. '),
                        tr.cells[3].innerText.trim(),
                        tr.cells[4].innerText.trim(),
                        tr.cells[5].innerText.trim()
                    ]);
                }
            });

            doc.autoTable({
                rowPageBreak: 'avoid',
                head: [columns],
                body: rows,
                startY: 100,
                theme: 'striped',
                headStyles: { fillColor: [30, 41, 59], fontStyle: 'bold', font: 'helvetica' },
                styles: { font: 'helvetica', fontSize: 9, cellPadding: 6, overflow: 'linebreak' },
                columnStyles: { 5: { cellWidth: 200 } }
            });
            doc.save("Delivery_Report_<?= htmlspecialchars($rider['name'] ?? 'Rider') ?>.pdf");
        }

        // 3. EXCEL EXPORT WITH STYLING
        async function exportToExcelStyled() {
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Delivery Report');

            // Styled Header Row
            const titleRow = worksheet.addRow(["DELIVERY PERSON REPORT - <?= strtoupper(htmlspecialchars($rider['name'] ?? '')) ?>"]);
            titleRow.font = { name: 'Arial', size: 16, bold: true, color: { argb: 'FFFFFFFF' } };
            titleRow.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF97316' } }; // Orange
            worksheet.mergeCells('A1:F1');
            titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
            titleRow.height = 30;

            // Timeline Row (Left Aligned)
            const timelineRow = worksheet.addRow(["Timeline: All Time  |  GENERATED ON: " + new Date().toLocaleString()]);
            worksheet.mergeCells('A2:F2');
            timelineRow.font = { name: 'Arial', bold: true, size: 10, color: { argb: 'FF333333' } };
            timelineRow.alignment = { horizontal: 'left' };

            // Define Columns & Header
            worksheet.addRow(["ID", "Date", "Amt", "Type", "Status", "Drop"]);
            const headerRow = worksheet.getRow(3);
            headerRow.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
            headerRow.eachCell(cell => {
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } }; // Dark Header
                cell.alignment = { horizontal: 'center' };
            });

            // Add Data from Table
            document.querySelectorAll("#deliveryTable tbody tr").forEach(tr => {
                if(tr.cells.length > 1) {
                    let reqAmount = tr.cells[2].innerText.trim();
                    let amountVal = reqAmount.includes('₹') ? parseFloat(reqAmount.replace(/[^0-9.-]+/g, '')) : reqAmount;

                    let addedRow = worksheet.addRow([
                        tr.cells[0].innerText.trim(),
                        tr.cells[1].innerText.trim(),
                        amountVal,
                        tr.cells[3].innerText.trim(),
                        tr.cells[4].innerText.trim(),
                        tr.cells[5].innerText.trim()
                    ]);

                    if (typeof amountVal === 'number') {
                        let amountCell = addedRow.getCell(3);
                        amountCell.numFmt = '[$₹-en-IN]#,##0.00';
                        amountCell.alignment = { horizontal: 'right' };
                        amountCell.font = { bold: true, color: { argb: 'FF0F172A' } };
                    }
                }
            });

            // Formatting
            worksheet.getColumn(1).width = 15;
            worksheet.getColumn(2).width = 25;
            worksheet.getColumn(3).width = 15;
            worksheet.getColumn(4).width = 15;
            worksheet.getColumn(5).width = 15;
            worksheet.getColumn(6).width = 40;

            // Save File
            const buffer = await workbook.xlsx.writeBuffer();
            saveAs(new Blob([buffer]), "Delivery_Report_<?= htmlspecialchars($rider['name'] ?? 'Rider') ?>.xlsx");
        }
    </script>
</body>
</html>
