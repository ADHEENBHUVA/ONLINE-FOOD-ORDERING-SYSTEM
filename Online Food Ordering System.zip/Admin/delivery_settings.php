<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();


$message = "";

// ✅ FETCH ACTIVE ORDERS COUNT
$order_count_query = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status = 'Pending' OR order_status = 'Confirmed'");
$order_data = $order_count_query->fetch_assoc();
$active_orders_count = $order_data['total'] ?? 0;

// ✅ HANDLE UPDATE
if (isset($_POST['save_settings'])) {
    // Sanitize and ensure no negative values via PHP max(0, value)
    $gen_fee = max(0, (float) $_POST['gen_fee']);
    $gen_delivery_type = $_POST['gen_delivery_type'] ?? 'fixed';
    $gen_free_km = max(0, (int) $_POST['gen_free_km']);
    $gen_charge_km = max(0, (float) $_POST['gen_charge_km']);
    $gen_min_free = max(0, (float) $_POST['gen_min_free']);

    $vip_disc = max(0, (int) $_POST['vip_disc']);
    $vip_disc_rs = max(0, (float) $_POST['vip_disc_rs']);
    $vip_discount_type = $_POST['vip_discount_type'] ?? 'percentage';
    $vip_fixed = isset($_POST['vip_fixed']) ? max(0, (float) $_POST['vip_fixed']) : 0;
    $vip_free_km = isset($_POST['vip_free_km']) ? max(0, (int) $_POST['vip_free_km']) : 0;
    $vip_charge_km = isset($_POST['vip_charge_km']) ? max(0, (float) $_POST['vip_charge_km']) : 0;
    $vip_min_buy = max(0, (float) $_POST['vip_min_buy']);
    $vip_membership_price = max(0, (float) $_POST['vip_membership_price']);
    $vip_yearly_price = max(0, (float) $_POST['vip_yearly_price']);
    $vip_monthly_discount_percent = max(0, (float) $_POST['vip_monthly_discount_percent']);
    $vip_3months_price = max(0, (float) $_POST['vip_3months_price']);
    $vip_3months_discount_percent = max(0, (float) $_POST['vip_3months_discount_percent']);
    $vip_6months_price = max(0, (float) $_POST['vip_6months_price']);
    $vip_6months_discount_percent = max(0, (float) $_POST['vip_6months_discount_percent']);
    $vip_yearly_discount_percent = max(0, (float) $_POST['vip_yearly_discount_percent']);

    $sql = "UPDATE delivery_settings SET
            gen_delivery_fee='$gen_fee',
            gen_delivery_type='$gen_delivery_type',
            gen_free_km='$gen_free_km',
            gen_charge_per_km='$gen_charge_km',
            gen_min_order_free='$gen_min_free',
            vip_discount_percent='$vip_disc',
            vip_discount_rupees='$vip_disc_rs',
            vip_discount_type='$vip_discount_type',
            vip_fixed_charge='$vip_fixed',
            vip_free_km='$vip_free_km',
            vip_charge_per_km='$vip_charge_km',
            vip_min_order_for_discount='$vip_min_buy',
            vip_membership_price='$vip_membership_price',
            vip_yearly_price='$vip_yearly_price',
            vip_monthly_discount_percent='$vip_monthly_discount_percent',
            vip_3months_price='$vip_3months_price',
            vip_3months_discount_percent='$vip_3months_discount_percent',
            vip_6months_price='$vip_6months_price',
            vip_6months_discount_percent='$vip_6months_discount_percent',
            vip_yearly_discount_percent='$vip_yearly_discount_percent'
            WHERE id=1";

    if ($conn->query($sql)) {
        $message = "Logistics protocols synchronized successfully.";
    }
}

// ✅ FETCH DATA
$res = $conn->query("SELECT * FROM delivery_settings WHERE id=1");
$rules = $res->fetch_assoc();

// Fallbacks
$gen_fee = $rules['gen_delivery_fee'] ?? 40;
$gen_delivery_type = $rules['gen_delivery_type'] ?? 'fixed';
$gen_km = $rules['gen_free_km'] ?? 3;
$gen_charge_km = $rules['gen_charge_per_km'] ?? 15;
$gen_min = $rules['gen_min_order_free'] ?? 500;

$vip_disc = $rules['vip_discount_percent'] ?? 10;
$vip_disc_rs = $rules['vip_discount_rupees'] ?? 0;
$vip_discount_type = $rules['vip_discount_type'] ?? 'percentage';
$vip_fixed = $rules['vip_fixed_charge'] ?? 0;
$vip_km = $rules['vip_free_km'] ?? 7;
$vip_charge = $rules['vip_charge_per_km'] ?? 10;
$vip_min = $rules['vip_min_order_for_discount'] ?? 500;
$vip_membership_price = $rules['vip_membership_price'] ?? 499;
$vip_yearly_price = $rules['vip_yearly_price'] ?? 4999;
$vip_monthly_discount_percent = $rules['vip_monthly_discount_percent'] ?? 0;
$vip_3months_price = $rules['vip_3months_price'] ?? 1299;
$vip_3months_discount_percent = $rules['vip_3months_discount_percent'] ?? 0;
$vip_6months_price = $rules['vip_6months_price'] ?? 2499;
$vip_6months_discount_percent = $rules['vip_6months_discount_percent'] ?? 0;
$vip_yearly_discount_percent = $rules['vip_yearly_discount_percent'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Logistics Terminal | Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #020617;
            color: #94a3b8;
        }

        .glass-card {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 2rem;
        }

        .input-luxury {
            background: #0f172a;
            border: 1px solid #1e293b;
            color: white;
            padding: 1rem;
            border-radius: 1rem;
            transition: 0.3s;
            width: 100%;
            outline: none;
        }

        .input-luxury:focus {
            border-color: #f97316;
            box-shadow: 0 0 15px rgba(249, 115, 22, 0.1);
        }

        .premium-label {
            font-size: 10px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #64748b;
            margin-bottom: 0.5rem;
            display: block;
        }

        .tab-btn.active {
            background: #f97316;
            color: white;
            box-shadow: 0 10px 20px rgba(249, 115, 22, 0.2);
        }

        /* Custom Scrollbar for Sidebar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 10px;
        }
    </style>
</head>

<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo"
                class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

        <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

            <a href="dashboard.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Dashboard</span>
                </div>
            </a>

            <a href="manage_food.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Manage Food</span>
                </div>
                <span
                    class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
            </a>

            <a href="manage_categories.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Categories</span>
                </div>
            </a>

            <a href="manage_promo.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Coupons</span>
                </div>
                <span
                    class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
            </a>

            <a href="manage_orders.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Active Orders</span>
                </div>
                <?php if ($active_orders_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
                        <?php echo $active_orders_count; ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="manage_customers.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Customer Base</span>
                </div>
            </a>

            <a href="manage_vip.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
                <div class="flex items-center gap-3">
                    <i class="fas fa-star w-5"></i>
                    <span class="font-semibold text-sm">VIP Members</span>
                </div>
            </a>

            <div class="my-4 border-t border-slate-800/50 mx-4"></div>
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

            <a href="admin_feedback.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Feedback</span>
                </div>
            </a>

            <a href="manage_delivery_person.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Fleet Status</span>
                </div>
                <span class="relative flex h-2 w-2">
                    <span
                        class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
            </a>

            <a href="admin_withdrawals.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Rider Payouts</span>
                </div>
                <?php if (isset($withdraw_count) && $withdraw_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                        <?= $withdraw_count ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="sales_report.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Sales Analytics</span>
                </div>
            </a>

            <a href="delivery_settings.php"
                class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
                <div class="flex items-center gap-4">
                    <div
                        class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                        <i
                            class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
                    </div>
                    <div class="flex flex-col">
                        <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP
                            Customers</span>
                        <span
                            class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics
                            & Rules</span>
                    </div>
                </div>
                <i
                    class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

                <div
                    class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity">
                </div>
            </a>

            <a href="change_theme.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Change Theme</span>
                </div>
                <span
                    class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
            </a>

            <a href="change_password_auth.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
                <div
                    class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                </div>

                <div class="flex items-center gap-3 relative z-10">
                    <div
                        class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
                        <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
                    </div>

                    <div class="flex flex-col">
                        <span
                            class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access
                            Security</span>
                        <span
                            class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update
                            Master Key</span>
                    </div>
                </div>

                <div class="relative z-10 flex items-center">
                    <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]">
                    </div>
                    <i
                        class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
                </div>
            </a>
        </nav>

        <div class="p-6 border-t border-slate-800/50">
            <a href="logout.php"
                class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
                <i class="fas fa-power-off"></i>
                <span class="font-bold text-sm">Sign Out</span>
            </a>
        </div>
    </aside>

    <main class="flex-1 p-8 lg:p-12">
        <div class="max-w-5xl mx-auto">

            <header class="mb-10">
                <h1 class="text-4xl font-900 text-white italic tracking-tighter uppercase">Logistics <span
                        class="text-orange-500">Terminal.</span></h1>
                <?php if ($message): ?>
                    <div
                        class="mt-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl text-xs font-bold uppercase tracking-widest">
                        <i class="fas fa-check-double mr-2"></i> <?= $message ?>
                    </div>
                <?php endif; ?>
            </header>

            <div class="flex gap-4 mb-8">
                <button onclick="switchTier('general')" id="gen-tab"
                    class="tab-btn active px-8 py-4 rounded-2xl font-bold transition-all flex items-center gap-3">
                    <i class="fas fa-motorcycle"></i> Rider Pay (Admin Cost)
                </button>
                <button onclick="switchTier('vip')" id="vip-tab"
                    class="tab-btn px-8 py-4 rounded-2xl font-bold bg-slate-900 transition-all flex items-center gap-3">
                    <i class="fas fa-crown text-orange-500"></i> VIP Premium
                </button>
            </div>

            <form method="POST" onsubmit="return validateForm()">
                <div id="general-section" class="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade">
                    <div class="glass-card p-8 col-span-2 border-l-4 border-l-blue-500">
                        <h3 class="text-white font-bold mb-6 flex items-center gap-2 text-xl"><i
                                class="fas fa-map-location-dot text-blue-400"></i> Admin Cost (Rider Earning Rules)</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                            <div>
                                <label class="premium-label">Delivery Mode</label>
                                <select name="gen_delivery_type" class="input-luxury">
                                    <option value="fixed" <?= $gen_delivery_type == 'fixed' ? 'selected' : '' ?>>Fixed Base
                                        Fee</option>
                                    <option value="km" <?= $gen_delivery_type == 'km' ? 'selected' : '' ?>>Per KM Mode
                                    </option>
                                </select>
                            </div>
                            <div>
                                <label class="premium-label">Base Fee (&#8377;)</label>
                                <input type="number" step="0.01" min="0" name="gen_fee" value="<?= $gen_fee ?>"
                                    class="input-luxury no-neg">
                            </div>
                            <div>
                                <label class="premium-label">Free Radius (KM)</label>
                                <input type="number" min="0" name="gen_free_km" value="<?= $gen_km ?>"
                                    class="input-luxury no-neg">
                            </div>
                            <div>
                                <label class="premium-label">Fee / Extra KM (&#8377;)</label>
                                <input type="number" step="0.01" min="0" name="gen_charge_km"
                                    value="<?= $gen_charge_km ?>" class="input-luxury no-neg">
                            </div>
                            <div>
                                <label class="premium-label">Free if Order > (&#8377;)</label>
                                <input type="number" step="0.01" min="0" name="gen_min_free" value="<?= $gen_min ?>"
                                    class="input-luxury no-neg">
                            </div>
                        </div>
                    </div>
                </div>

                <div id="vip-section" class="hidden grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade">
                    <div class="glass-card p-8 col-span-2 border-l-4 border-l-orange-500">
                        <h3 class="text-white font-bold mb-6 flex items-center gap-2 text-xl"><i
                                class="fas fa-gem text-orange-500"></i> VIP Premium Logistics</h3>
                        <h4 class="text-white font-bold mb-4 text-lg border-b border-slate-700 pb-2">Membership Plans
                            (Auto-calculated)</h4>

                        <div class="flex flex-col gap-6 mb-8">
                            <!-- 1 Month -->
                            <div
                                class="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-800/30 p-4 rounded-xl border border-slate-700/50">
                                <div>
                                    <label class="premium-label">1-Month Mbr. Cost (&#8377;) *Base*</label>
                                    <input type="number" step="0.01" min="0" name="vip_membership_price"
                                        id="vip_membership_price" value="<?= $vip_membership_price ?>"
                                        class="input-luxury no-neg">
                                </div>
                                <div>
                                    <label class="premium-label">1-Month Mbr. Discount (%)</label>
                                    <input type="number" step="0.01" min="0" max="100"
                                        name="vip_monthly_discount_percent" value="<?= $vip_monthly_discount_percent ?>"
                                        class="input-luxury no-neg">
                                </div>
                            </div>

                            <!-- 3 Months -->
                            <div
                                class="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-800/30 p-4 rounded-xl border border-slate-700/50">
                                <div>
                                    <label class="premium-label">3-Month Mbr. Cost (&#8377;)</label>
                                    <input type="number" step="0.01" min="0" name="vip_3months_price"
                                        id="vip_3months_price" value="<?= $vip_3months_price ?>"
                                        class="input-luxury no-neg">
                                </div>
                                <div>
                                    <label class="premium-label">3-Month Mbr. Discount (%)</label>
                                    <input type="number" step="0.01" min="0" max="100"
                                        name="vip_3months_discount_percent" value="<?= $vip_3months_discount_percent ?>"
                                        class="input-luxury no-neg">
                                </div>
                            </div>

                            <!-- 6 Months -->
                            <div
                                class="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-800/30 p-4 rounded-xl border border-slate-700/50">
                                <div>
                                    <label class="premium-label">6-Month Mbr. Cost (&#8377;)</label>
                                    <input type="number" step="0.01" min="0" name="vip_6months_price"
                                        id="vip_6months_price" value="<?= $vip_6months_price ?>"
                                        class="input-luxury no-neg">
                                </div>
                                <div>
                                    <label class="premium-label">6-Month Mbr. Discount (%)</label>
                                    <input type="number" step="0.01" min="0" max="100"
                                        name="vip_6months_discount_percent" value="<?= $vip_6months_discount_percent ?>"
                                        class="input-luxury no-neg">
                                </div>
                            </div>

                            <!-- 1 Year -->
                            <div
                                class="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-800/30 p-4 rounded-xl border border-slate-700/50">
                                <div>
                                    <label class="premium-label">1-Year Mbr. Cost (&#8377;)</label>
                                    <input type="number" step="0.01" min="0" name="vip_yearly_price"
                                        id="vip_yearly_price" value="<?= $vip_yearly_price ?>"
                                        class="input-luxury no-neg">
                                </div>
                                <div>
                                    <label class="premium-label">1-Year Mbr. Discount (%)</label>
                                    <input type="number" step="0.01" min="0" max="100"
                                        name="vip_yearly_discount_percent" value="<?= $vip_yearly_discount_percent ?>"
                                        class="input-luxury no-neg">
                                </div>
                            </div>
                        </div>

                        <h4 class="text-white font-bold mb-4 text-lg border-b border-slate-700 pb-2">VIP Order Logistics
                        </h4>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div class="col-span-1 md:col-span-3">
                                <label class="premium-label mb-3">Active Discount Mode</label>
                                <div class="flex gap-6 mb-2">
                                    <label
                                        class="flex items-center gap-2 text-black font-black bg-white/90 px-4 py-2 rounded-xl shadow-sm cursor-pointer hover:bg-white transition-colors">
                                        <input type="radio" name="vip_discount_type" value="percentage"
                                            onchange="toggleVipDiscountInput()" <?= $vip_discount_type == 'percentage' ? 'checked' : '' ?>
                                            class="w-4 h-4 text-orange-500 bg-slate-900 border-slate-700 focus:ring-orange-500">
                                        Percentage (%)
                                    </label>
                                    <label
                                        class="flex items-center gap-2 text-black font-black bg-white/90 px-4 py-2 rounded-xl shadow-sm cursor-pointer hover:bg-white transition-colors">
                                        <input type="radio" name="vip_discount_type" value="rupees"
                                            onchange="toggleVipDiscountInput()" <?= $vip_discount_type == 'rupees' ? 'checked' : '' ?>
                                            class="w-4 h-4 text-orange-500 bg-slate-900 border-slate-700 focus:ring-orange-500">
                                        Fixed Amount (&#8377;)
                                    </label>
                                </div>
                            </div>
                            <div id="vip-percent-div"
                                style="<?= $vip_discount_type == 'percentage' ? 'display:block;' : 'display:none;' ?>">
                                <label class="premium-label">Membership Off (%)</label>
                                <input type="number" min="0" max="100" name="vip_disc" value="<?= $vip_disc ?>"
                                    id="vip_disc_input" class="input-luxury no-neg">
                            </div>
                            <div id="vip-rs-div"
                                style="<?= $vip_discount_type == 'rupees' ? 'display:block;' : 'display:none;' ?>">
                                <label class="premium-label">Membership Off (&#8377; Fixed)</label>
                                <input type="number" step="0.01" min="0" name="vip_disc_rs" value="<?= $vip_disc_rs ?>"
                                    id="vip_disc_rs_input" class="input-luxury no-neg">
                            </div>
                            <div>
                                <label class="premium-label">Discount Trigger (&#8377;)</label>
                                <input type="number" step="0.01" min="0" name="vip_min_buy" value="<?= $vip_min ?>"
                                    class="input-luxury no-neg">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-10">
                    <button type="submit" name="save_settings"
                        class="w-full bg-orange-500 hover:bg-orange-600 text-white font-900 py-5 rounded-2xl shadow-2xl shadow-orange-500/20 transition-all uppercase text-xs tracking-[0.4em] flex items-center justify-center gap-3 active:scale-95">
                        Update Global Rules <i class="fas fa-save"></i>
                    </button>
                </div>
            </form>
        </div>
    </main>

    <script>
        // Auto-calculate membership prices based on 1-month base price
        function autoCalcMbr(val, mult) {
            let res = val * mult;
            return Number.isInteger(res) ? res : res.toFixed(2);
        }

        const baseMbrInput = document.getElementById('vip_membership_price');
        if (baseMbrInput) {
            baseMbrInput.addEventListener('input', function () {
                let basePrice = parseFloat(this.value) || 0;
                document.getElementById('vip_3months_price').value = autoCalcMbr(basePrice, 3);
                document.getElementById('vip_6months_price').value = autoCalcMbr(basePrice, 6);
                document.getElementById('vip_yearly_price').value = autoCalcMbr(basePrice, 12);
            });
        }

        // Prevent negative values manually on change
        document.querySelectorAll('.no-neg').forEach(input => {
            input.addEventListener('input', function () {
                if (this.value < 0) this.value = 0;
            });
        });

        function switchTier(tier) {
            const sections = { gen: document.getElementById('general-section'), vip: document.getElementById('vip-section') };
            const tabs = { gen: document.getElementById('gen-tab'), vip: document.getElementById('vip-tab') };

            if (tier === 'general') {
                sections.gen.classList.remove('hidden'); sections.vip.classList.add('hidden');
                tabs.gen.classList.add('active'); tabs.gen.classList.remove('bg-slate-900');
                tabs.vip.classList.remove('active'); tabs.vip.classList.add('bg-slate-900');
            } else {
                sections.gen.classList.add('hidden'); sections.vip.classList.remove('hidden');
                tabs.vip.classList.add('active'); tabs.vip.classList.remove('bg-slate-900');
                tabs.gen.classList.remove('active'); tabs.gen.classList.add('bg-slate-900');
            }
        }

        function toggleVipDiscountInput() {
            let type = document.querySelector('input[name="vip_discount_type"]:checked').value;
            if (type === 'percentage') {
                document.getElementById('vip-percent-div').style.display = 'block';
                document.getElementById('vip-rs-div').style.display = 'none';
                document.getElementById('vip_disc_rs_input').value = 0; // Wipe the other to ensure mutually exclusive data
            } else {
                document.getElementById('vip-percent-div').style.display = 'none';
                document.getElementById('vip-rs-div').style.display = 'block';
                document.getElementById('vip_disc_input').value = 0; // Wipe the other
            }
        }

        function validateForm() {
            let inputs = document.querySelectorAll('input[type="number"]');
            for (let input of inputs) {
                if (input.value < 0) {
                    alert("Negative values are not permitted in logistics settings.");
                    input.focus();
                    return false;
                }
            }
            return true;
        }
    </script>
</body>

</html>