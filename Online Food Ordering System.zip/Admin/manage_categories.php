<?php
session_set_cookie_params(86400 * 30);
session_start();

// Check Login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

// Database Connection
$conn = new mysqli("localhost", "root", "", "online_food");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

// Load Theme Settings
$theme_query = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_query);

$message = "";
$msg_type = "success";

// 3. ADD THE COUNTING CODE HERE (Right after connection)
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// Add Category
if (isset($_POST['add_category'])) {
    $category_name = $conn->real_escape_string($_POST['category_name']);
    $stmt = $conn->prepare("INSERT INTO categories (category_name, status) VALUES (?, 'Active')");
    $stmt->bind_param("s", $category_name);
    if ($stmt->execute()) {
        header("Location: manage_categories.php?msg=added");
        exit();
    }
}

// Delete Category
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($conn->query("DELETE FROM categories WHERE category_id=$id")) {
        header("Location: manage_categories.php?msg=removed");
        exit();
    }
}

// Check for Messages
if(isset($_GET['msg'])){
    if($_GET['msg'] == 'added'){
        $message = "Category added successfully!";
        $msg_type = "success";
    } elseif($_GET['msg'] == 'removed'){
        $message = "Category removed successfully!";
        $msg_type = "error";
    }
}

// Fetch Categories
$result = $conn->query("SELECT * FROM categories ORDER BY category_id DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories | Executive Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary: #f97316;
            --bg-main:
                <?php echo ($theme['mode'] == "dark") ? "#0f172a" : "#fdf2f2"; ?>
            ;
        }

        body {
            font-family: '<?php echo $theme['font_family']; ?>', sans-serif;
            background-color: var(--bg-main);
            margin: 0;
            color:
                <?php echo ($theme['mode'] == "dark") ? "#f1f5f9" : "#1e293b"; ?>
            ;
        }

        .sidebar-premium {
            background: #0f172a;
            width: 288px;
            flex-shrink: 0;
        }

        .glass-nav {
            background:
                <?php echo ($theme['mode'] == 'dark') ? 'rgba(15, 23, 42, 0.8)' : 'rgba(255, 255, 255, 0.8)'; ?>
            ;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .nav-link {
            transition: all 0.2s ease;
            color: #94a3b8;
        }

        .nav-link:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }

        .nav-link.active {
            background: var(--primary);
            color: white !important;
        }

        .custom-card {
            background:
                <?php echo ($theme['mode'] == "dark") ? "#1e293b" : "#ffffff"; ?>
            ;
            border-radius: 1.5rem;
            border: 1px solid
                <?php echo ($theme['mode'] == "dark") ? "rgba(255,255,255,0.05)" : "#e2e8f0"; ?>
            ;
        }

        /* Custom Scrollbar for Sidebar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 10px;
        }
    </style>
</head>

<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo"
                class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

        <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

            <a href="dashboard.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Dashboard</span>
                </div>
            </a>

            <a href="manage_food.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Manage Food</span>
                </div>
                <span
                    class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
            </a>

            <a href="manage_categories.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Categories</span>
                </div>
            </a>

            <a href="manage_promo.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Coupons</span>
                </div>
                <span
                    class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
            </a>

            <a href="manage_orders.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Active Orders</span>
                </div>
                <?php if ($active_orders_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
                        <?php echo $active_orders_count; ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="manage_customers.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Customer Base</span>
                </div>
            </a>
            <a href="manage_vip.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
                <div class="flex items-center gap-3">
                    <i class="fas fa-star w-5"></i>
                    <span class="font-semibold text-sm">VIP Members</span>
                </div>
            </a>

            <div class="my-4 border-t border-slate-800/50 mx-4"></div>
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

            <a href="admin_feedback.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Feedback</span>
                </div>
            </a>

            <a href="manage_delivery_person.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Fleet Status</span>
                </div>
                <span class="relative flex h-2 w-2">
                    <span
                        class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
            </a>

            <a href="admin_withdrawals.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Rider Payouts</span>
                </div>
                <?php if (isset($withdraw_count) && $withdraw_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                        <?= $withdraw_count ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="sales_report.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Sales Analytics</span>
                </div>
            </a>

            <a href="delivery_settings.php"
                class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
                <div class="flex items-center gap-4">
                    <div
                        class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                        <i
                            class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
                    </div>
                    <div class="flex flex-col">
                        <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP
                            Customers</span>
                        <span
                            class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics
                            & Rules</span>
                    </div>
                </div>
                <i
                    class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

                <div
                    class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity">
                </div>
            </a>

            <a href="change_theme.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Change Theme</span>
                </div>
                <span
                    class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
            </a>

            <a href="change_password_auth.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
                <div
                    class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                </div>

                <div class="flex items-center gap-3 relative z-10">
                    <div
                        class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
                        <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
                    </div>

                    <div class="flex flex-col">
                        <span
                            class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access
                            Security</span>
                        <span
                            class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update
                            Master Key</span>
                    </div>
                </div>

                <div class="relative z-10 flex items-center">
                    <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]">
                    </div>
                    <i
                        class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
                </div>
            </a>
        </nav>

        <div class="p-6 border-t border-slate-800/50">
            <a href="logout.php"
                class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
                <i class="fas fa-power-off"></i>
                <span class="font-bold text-sm">Sign Out</span>
            </a>
        </div>
    </aside>

    <main class="flex-1 flex flex-col min-w-0">

        <header class="glass-nav sticky top-0 z-40 px-8 py-5 flex justify-between items-center">
            <div>
                <h1 class="text-xl font-800 tracking-tight italic uppercase">Menu Categories</h1>
                <p class="text-[10px] uppercase font-bold opacity-50 tracking-widest mt-1">Structure your menu items</p>
            </div>
            <div class="flex items-center gap-4">
                <div
                    class="h-10 w-10 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center font-bold text-slate-600 shadow-sm">
                    A</div>
            </div>
        </header>

        <div class="p-8 max-w-5xl mx-auto w-full">

            <?php if ($message != ""): ?>
                <div id="msg-alert"
                    class="<?php echo ($msg_type == 'success') ? 'bg-emerald-500 text-white shadow-emerald-500/30' : 'bg-rose-500 text-white shadow-rose-500/30'; ?> 
                    shadow-xl p-5 rounded-2xl mb-8 flex items-center justify-center gap-3 animate-pulse transform transition-all duration-500 z-50">
                    <i class="fa-solid <?php echo ($msg_type == 'success') ? 'fa-check-circle' : 'fa-trash-alt'; ?> text-xl"></i>
                    <span class="font-bold text-sm tracking-wide"><?php echo $message; ?></span>
                </div>
                
                <script>
                    setTimeout(() => {
                        const alertBox = document.getElementById('msg-alert');
                        if(alertBox) {
                            alertBox.style.opacity = '0';
                            alertBox.style.transform = 'scale(0.95) translateY(-10px)';
                            setTimeout(() => {
                                alertBox.style.display = 'none';
                                
                                // Clean up URL parameter to prevent reappearing on refresh
                                const url = new URL(window.location);
                                url.searchParams.delete('msg');
                                window.history.replaceState({}, document.title, url);
                            }, 500);
                        }
                    }, 10000); // 10 seconds exactly as requested
                </script>
            <?php endif; ?>

            <div class="custom-card p-8 shadow-xl mb-10">
                <h3 class="text-lg font-800 mb-6 flex items-center gap-2">
                    <i class="fa-solid fa-folder-plus text-orange-500"></i> Create New Category
                </h3>
                <form method="POST" class="flex flex-col md:flex-row gap-4">
                    <input type="text" name="category_name" placeholder="e.g. Italian Bistro, Fresh Salads, Beverages"
                        required
                        class="flex-1 bg-slate-500/5 border border-slate-400/20 rounded-2xl py-4 px-6 outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 transition-all">
                    <button type="submit" name="add_category"
                        class="bg-orange-500 hover:bg-orange-600 text-white font-800 py-4 px-8 rounded-2xl shadow-lg shadow-orange-500/20 transition-all transform active:scale-95 whitespace-nowrap">
                        <i class="fa-solid fa-plus mr-2"></i> Save Category
                    </button>
                </form>
            </div>

            <div class="custom-card overflow-hidden shadow-sm">
                <div class="p-6 border-b border-inherit bg-slate-500/5">
                    <h2 class="font-800 text-sm uppercase tracking-widest opacity-70">Existing Categories</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr
                                class="text-[11px] font-black uppercase tracking-widest opacity-40 border-b border-inherit">
                                <th class="px-8 py-4">Ref ID</th>
                                <th class="px-8 py-4">Cuisine / Category Name</th>
                                <th class="px-8 py-4 text-right">Operation</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-inherit">
                            <?php if ($result->num_rows > 0): ?>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <tr class="hover:bg-slate-500/5 transition-colors">
                                        <td class="px-8 py-5">
                                            <span
                                                class="text-xs font-bold font-mono opacity-50">#<?php echo $row['category_id']; ?></span>
                                        </td>
                                        <td class="px-8 py-5">
                                            <span
                                                class="font-bold text-base tracking-tight"><?php echo $row['category_name']; ?></span>
                                        </td>
                                        <td class="px-8 py-5 text-right">
                                            <a href="?delete=<?php echo $row['category_id']; ?>"
                                                class="inline-flex items-center gap-2 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white px-4 py-2 rounded-xl text-xs font-black transition-all uppercase tracking-tighter"
                                                onclick="return confirm('Are you sure? This will affect food items in this category.')">
                                                <i class="fa-solid fa-trash-can"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="px-8 py-20 text-center opacity-30 italic">No categories created
                                        yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </main>

</body>

</html>