<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// 1. SECURITY & ACCESS
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

// 2. SIDEBAR LOGIC
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// 3. FETCH CURRENT THEME
$q = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$t = mysqli_fetch_assoc($q);

// 4. SAVE HANDLER
if(isset($_POST['save'])){
    $font      = $_POST['font'];
    $size      = $_POST['size'];
    $f_color   = $_POST['f_color'];
    $color     = $_POST['color'];   // Highlights
    $side_bg   = $_POST['sidebar_bg']; // From Sidebar Picker
    $body_bg   = $_POST['body_bg'];    // From Body Picker
    $mode      = $_POST['mode'];
    $speed     = $_POST['speed'];
    $aesthetic = $_POST['aesthetic'];
    $current_image = $t['background_image'];

    // Image logic remains the same...
    if(isset($_POST['remove_bg_trigger']) && $_POST['remove_bg_trigger'] == '1'){
        if($current_image && file_exists("../images/".$current_image)) unlink("../images/".$current_image);
        $current_image = null;
    }
    if(!empty($_FILES['bg_image']['name'])){
        if($current_image && file_exists("../images/".$current_image)) unlink("../images/".$current_image);
        $image = time() . "_" . $_FILES['bg_image']['name'];
        move_uploaded_file($_FILES['bg_image']['tmp_name'], "../images/".$image);
        $current_image = $image;
    }

    $fixed_glass = "12px";
    // PREPARE STATEMENT with sidebar_color and background_color
    $stmt = $conn->prepare("UPDATE admin_theme SET font_family=?, font_size=?, theme_color=?, sidebar_color=?, background_color=?, background_image=?, mode=?, transition_speed=?, glass_intensity=?, bg_aesthetic=?, font_color=? WHERE id=1");
    $stmt->bind_param("sssssssssss", $font, $size, $color, $side_bg, $body_bg, $current_image, $mode, $speed, $fixed_glass, $aesthetic, $f_color);

    if($stmt->execute()){
        echo "<script>alert('Architecture Synchronized!'); window.location='change_theme.php';</script>";
    }
}

$font_styles = [
    'Plus Jakarta Sans', 'Poppins', 'Inter', 'Montserrat', 'Roboto',
    'Josefin Sans', 'Dancing Script', 'Righteous', 'Cinzel', 'Open Sans',
    'Lato', 'Oswald', 'Raleway', 'Ubuntu', 'Nunito',
    'Playfair Display', 'Merriweather', 'Rubik', 'Work Sans', 'Fira Sans',
    'Quicksand', 'Barlow', 'Inconsolata', 'Mukta', 'PT Sans',
    'Bebas Neue', 'Anton', 'Pacifico', 'Caveat', 'Satisfy'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Theme Studio | Executive Interface</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=<?= implode('&family=', array_map(fn($f) => str_replace(' ', '+', $f), $font_styles)) ?>&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
    :root {
        --primary: <?= $t['theme_color'] ?>;
        --side-bg: <?= $t['sidebar_color'] ?? '#0f172a' ?>; /* Maps to sidebar_color */
        --body-bg: <?= $t['background_color'] ?? '#f8fafc' ?>; /* Maps to background_color */
        --text-color: <?= $t['font_color'] ?? '#1e293b' ?>;
        --transition: <?= $t['transition_speed'] ?>;
    }

    body {
        background-color: var(--body-bg) !important;
        font-family: '<?= $t['font_family'] ?>', sans-serif;
        color: var(--text-color);
        transition: all var(--transition) ease;
    }

    .sidebar-premium {
        background-color: var(--side-bg) !important;
        width: 288px;
        transition: background 0.5s ease;
    }

        .aside-studio {
            background-color: var(--base-ui) !important;
            width: 280px; transition: background 0.5s ease;
            display: flex; flex-direction: column; height: 100vh;
            border-right: 1px solid rgba(255,255,255,0.05);
            box-shadow: 10px 0 30px rgba(0,0,0,0.05);
        }

        /* Glassmorphism Logic */
        .glass-card {
            background: <?= ($t['mode']=="dark") ? "rgba(30, 41, 59, 0.4)" : "rgba(255, 255, 255, 0.6)"; ?>;
            backdrop-filter: blur(16px) saturate(180%);
            -webkit-backdrop-filter: blur(16px) saturate(180%);
            border-radius: 2.5rem; border: 1px solid rgba(255,255,255,0.3);
            transition: all var(--transition) ease;
        }

        .highlight-btn { background-color: var(--primary); color: white; border-radius: 1.25rem; transition: 0.3s; }
        .highlight-btn:hover { filter: brightness(1.1); transform: scale(1.02); }

        /* Dynamic Background Layer */
        .ae-mesh {
            position: fixed; inset: 0; z-index: -1; pointer-events: none;
            display: <?= ($t['bg_aesthetic'] == 'mesh') ? 'block' : 'none' ?>;
            background-image: radial-gradient(at 0% 0%, var(--primary) 0, transparent 40%), radial-gradient(at 100% 100%, var(--primary) 0, transparent 40%);
            opacity: 0.15;
        }

        .ae-pattern {
            position: fixed; inset: 0; z-index: -1; pointer-events: none;
            display: <?= ($t['bg_aesthetic'] == 'pattern') ? 'block' : 'none' ?>;
            background-image: radial-gradient(var(--primary) 1px, transparent 0);
            background-size: 30px 30px; opacity: 0.1;
        }

        .bg-custom-img {
            position: fixed; inset: 0; z-index: -2;
            background-image: url('../images/<?= $t['background_image'] ?>');
            background-size: cover; background-position: center;
        }

        input[type="color"] { -webkit-appearance: none; border: none; width: 50px; height: 50px; border-radius: 15px; cursor: pointer; background: white; padding: 4px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        input[type="color"]::-webkit-color-swatch { border-radius: 12px; border: none; }

        /* Custom Scrollbar for Sidebar */
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>

<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo" class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

    <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

        <a href="dashboard.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Dashboard</span>
            </div>
        </a>

        <a href="manage_food.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Manage Food</span>
            </div>
            <span class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
        </a>

        <a href="manage_categories.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Categories</span>
            </div>
        </a>

        <a href="manage_promo.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Coupons</span>
            </div>
            <span class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
        </a>

        <a href="manage_orders.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
    <div class="flex items-center gap-3">
        <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
        <span class="font-semibold text-sm">Active Orders</span>
    </div>
    <?php if($active_orders_count > 0): ?>
        <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
            <?php echo $active_orders_count; ?>
        </span>
    <?php endif; ?>
</a>

        <a href="manage_customers.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Customer Base</span>
            </div>
        </a>
        <a href="manage_vip.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
            <div class="flex items-center gap-3">
                <i class="fas fa-star w-5"></i>
                <span class="font-semibold text-sm">VIP Members</span>
            </div>
        </a>

        <div class="my-4 border-t border-slate-800/50 mx-4"></div>
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

        <a href="admin_feedback.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Feedback</span>
            </div>
        </a>

        <a href="manage_delivery_person.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Fleet Status</span>
            </div>
            <span class="relative flex h-2 w-2">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
        </a>

        <a href="admin_withdrawals.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Rider Payouts</span>
            </div>
            <?php if(isset($withdraw_count) && $withdraw_count > 0): ?>
            <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                <?= $withdraw_count ?>
            </span>
            <?php endif; ?>
        </a>

        <a href="sales_report.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Sales Analytics</span>
            </div>
        </a>

        <a href="delivery_settings.php" class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
        <div class="flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                <i class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
            </div>
            <div class="flex flex-col">
                <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP Customers</span>
                <span class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics & Rules</span>
            </div>
        </div>
        <i class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

        <div class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </a>

        <a href="change_theme.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Change Theme</span>
            </div>
            <span class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
        </a>

        <a href="change_password_auth.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

    <div class="flex items-center gap-3 relative z-10">
        <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
            <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
        </div>

        <div class="flex flex-col">
            <span class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access Security</span>
            <span class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update Master Key</span>
        </div>
    </div>

    <div class="relative z-10 flex items-center">
        <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]"></div>
        <i class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
    </div>
</a>
    </nav>

    <div class="p-6 border-t border-slate-800/50">
        <a href="logout.php" class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
            <i class="fas fa-power-off"></i>
            <span class="font-bold text-sm">Sign Out</span>
        </a>
    </div>
</aside>

    <div class="flex-1 flex flex-col h-screen overflow-hidden">
        <header class="h-24 px-12 flex justify-between items-center z-40 bg-white/40 backdrop-blur-xl border-b border-slate-200">
            <div>
                <h1 class="text-2xl font-900 uppercase italic tracking-tighter">Visual <span style="color: var(--primary)">Editor</span></h1>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Theme Management Studio v4.0</p>
            </div>
            <div class="flex items-center gap-4">
                <div class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></div>
                <span class="text-[9px] font-black bg-slate-900 text-white px-4 py-2 rounded-full uppercase tracking-tighter">Sync Active</span>
            </div>
        </header>

        <div class="flex-1 overflow-y-auto p-12 custom-scrollbar relative">
            <form method="POST" enctype="multipart/form-data" id="themeForm" class="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">

                <div class="lg:col-span-8 space-y-10">
                    <div class="glass-card p-10 shadow-2xl">
                        <h2 class="text-xl font-900 uppercase italic mb-8 border-b border-slate-200 pb-4 flex items-center gap-3">
                            <i class="fas fa-font" style="color: var(--primary)"></i> Typography Control
                        </h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                            <div class="space-y-3">
                                <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Font Signature</label>
                                <select name="font" id="fontPicker" class="w-full bg-white p-4 rounded-2xl font-bold outline-none border-2 border-slate-100 focus:border-highlight transition-all shadow-sm">
                                    <?php foreach($font_styles as $f) echo "<option value='$f' style=\"font-family: '$f', sans-serif;\" ".($t['font_family']==$f?'selected':'').">$f</option>"; ?>
                                </select>
                            </div>
                            <div class="space-y-3">
                                <div class="flex justify-between items-center">
                                    <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Global Font Magnitude</label>
                                    <span id="fontSizeDisplay" class="text-xs font-black px-3 py-1 bg-slate-100 rounded-lg"><?= $t['font_size'] ?></span>
                                </div>
                                <input type="range" id="sizeSlider" min="12" max="24" value="<?= (int)$t['font_size'] ?>" class="w-full h-1.5 mt-4 cursor-pointer accent-orange-500">
                                <input type="hidden" name="size" id="fontSizeInput" value="<?= $t['font_size'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="glass-card p-10 shadow-2xl">
                        <h2 class="text-xl font-900 uppercase italic mb-8 border-b border-slate-200 pb-4 flex items-center gap-3">
                            <i class="fas fa-palette" style="color: var(--primary)"></i> Chroma Engine
                        </h2>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                            <div class="bg-white/50 p-4 rounded-2xl flex flex-col items-center">
                                <input type="color" name="sidebar_bg" id="sidebarPicker" value="<?= $t['sidebar_color'] ?>">
                                <p class="text-[9px] font-black mt-2 uppercase">Sidebar</p>
                            </div>
                            <div class="bg-white/50 p-4 rounded-2xl flex flex-col items-center">
                                <input type="color" name="body_bg" id="bodyPicker" value="<?= $t['background_color'] ?>">
                                <p class="text-[9px] font-black mt-2 uppercase">Background</p>
                            </div>
                            <div class="bg-white/50 p-4 rounded-2xl flex flex-col items-center">
                                <input type="color" name="f_color" id="fontColorPicker" value="<?= $t['font_color'] ?>">
                                <p class="text-[9px] font-black mt-2 uppercase">Font Color</p>
                            </div>
                            <div class="bg-white/50 p-4 rounded-2xl flex flex-col items-center">
                                <input type="color" name="color" id="highlightPicker" value="<?= $t['theme_color'] ?>">
                                <p class="text-[9px] font-black mt-2 uppercase">Highlights</p>
                            </div>
                        </div>
                    </div>

                    <div class="glass-card p-10 shadow-2xl">
                        <h2 class="text-xl font-900 uppercase italic mb-8 border-b border-slate-200 pb-4 flex items-center gap-3">
                            <i class="fas fa-image" style="color: var(--primary)"></i> Canvas Architecture
                        </h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                            <div class="space-y-4">
                                <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Active Wallpaper Asset</label>
                                <div class="relative h-48 rounded-[2rem] overflow-hidden border-2 border-dashed border-slate-200 bg-white/50 flex items-center justify-center">
                                    <?php if($t['background_image']): ?>
                                        <img id="previewImg" src="../images/<?= $t['background_image'] ?>" class="w-full h-full object-cover">
                                    <?php else: ?>
                                        <div class="text-center opacity-20"><i class="fas fa-plus text-3xl"></i></div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex gap-2">
                                    <input type="file" name="bg_image" id="fileInput" class="hidden" accept="image/*">
                                    <button type="button" onclick="document.getElementById('fileInput').click()" class="flex-1 py-3 bg-slate-900 text-white rounded-xl font-black text-[9px] uppercase tracking-widest">Replace</button>
                                    <?php if($t['background_image']): ?>
                                        <input type="hidden" name="remove_bg_trigger" id="removeTrigger" value="0">
                                        <button type="button" onclick="markForRemoval()" id="removeBtn" class="flex-1 py-3 bg-red-50 text-red-500 border border-red-100 rounded-xl font-black text-[9px] uppercase">Delete</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="space-y-4">
                                <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Aesthetic Layers</label>
                                <div class="grid grid-cols-1 gap-3">
                                    <label class="cursor-pointer">
                                        <input type="radio" name="aesthetic" value="solid" class="hidden peer" <?= $t['bg_aesthetic']=='solid'?'checked':'' ?> onclick="applyAesthetic('solid')">
                                        <div class="p-4 border-2 border-slate-100 rounded-2xl text-center peer-checked:border-orange-500 peer-checked:bg-orange-50 font-black text-[10px] uppercase transition-all">Solid Clean</div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="aesthetic" value="mesh" class="hidden peer" <?= $t['bg_aesthetic']=='mesh'?'checked':'' ?> onclick="applyAesthetic('mesh')">
                                        <div class="p-4 border-2 border-slate-100 rounded-2xl text-center peer-checked:border-orange-500 peer-checked:bg-orange-50 font-black text-[10px] uppercase transition-all">Mesh Glow</div>
                                    </label>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="aesthetic" value="pattern" class="hidden peer" <?= $t['bg_aesthetic']=='pattern'?'checked':'' ?> onclick="applyAesthetic('pattern')">
                                        <div class="p-4 border-2 border-slate-100 rounded-2xl text-center peer-checked:border-orange-500 peer-checked:bg-orange-50 font-black text-[10px] uppercase transition-all">Polka Pattern</div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-4">
                    <div class="glass-card p-10 sticky top-10 text-center border-t-[12px] border-t-orange-500 shadow-2xl">
                        <div class="w-20 h-20 bg-orange-500 text-white rounded-[2.5rem] flex items-center justify-center mx-auto mb-8 text-3xl shadow-xl shadow-orange-500/30">
                            <i data-lucide="refresh-cw"></i>
                        </div>
                        <h3 class="text-2xl font-900 mb-4 uppercase italic tracking-tighter">Deploy UI</h3>
                        <p class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-8">Synchronize all changes across admin and user panels.</p>

                        <div class="bg-slate-100 p-1.5 rounded-2xl mb-8 flex shadow-inner border border-slate-200">
                            <label class="flex-1 cursor-pointer"><input type="radio" name="mode" value="light" class="hidden peer" <?= $t['mode']=='light'?'checked':'' ?>><div class="py-3 rounded-xl peer-checked:bg-white peer-checked:shadow-xl font-black text-[9px] uppercase transition-all">Light</div></label>
                            <label class="flex-1 cursor-pointer"><input type="radio" name="mode" value="dark" class="hidden peer" <?= $t['mode']=='dark'?'checked':'' ?>><div class="py-3 rounded-xl peer-checked:bg-white peer-checked:shadow-xl font-black text-[9px] uppercase transition-all">Dark</div></label>
                        </div>

                        <div class="text-left space-y-2 mb-8">
                            <label class="text-[9px] font-black uppercase text-slate-400 ml-2 tracking-widest">Transition Speed</label>
                            <select name="speed" id="speedPicker" class="w-full bg-slate-100 p-4 rounded-2xl font-bold border-none text-xs">
                                <option value="0.2s" <?= $t['transition_speed']=='0.2s'?'selected':'' ?>>Instant (0.2s)</option>
                                <option value="0.4s" <?= $t['transition_speed']=='0.4s'?'selected':'' ?>>Balanced (0.4s)</option>
                                <option value="0.8s" <?= $t['transition_speed']=='0.8s'?'selected':'' ?>>Cinematic (0.8s)</option>
                            </select>
                        </div>

                        <button name="save" class="w-full highlight-btn py-6 font-black uppercase text-xs tracking-[0.3em] active:scale-95 shadow-2xl">
                            Apply Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        const root = document.documentElement.style;

        // Visual Engine: Color Preview
        document.getElementById('sidebarPicker').oninput = (e) => root.setProperty('--side-bg', e.target.value);
        document.getElementById('bodyPicker').oninput = (e) => root.setProperty('--body-bg', e.target.value);
        document.getElementById('highlightPicker').oninput = (e) => root.setProperty('--primary', e.target.value);
        document.getElementById('fontColorPicker').oninput = (e) => {
            root.setProperty('--text-color', e.target.value);
            document.body.style.color = e.target.value;
        };

        // Visual Engine: Size Preview
        const slider = document.getElementById('sizeSlider');
        const display = document.getElementById('fontSizeDisplay');
        const sizeInput = document.getElementById('fontSizeInput');
        slider.oninput = function() {
            const val = this.value + 'px';
            display.innerText = val; sizeInput.value = val;
            document.documentElement.style.fontSize = val;
            document.body.style.fontSize = val;
        };

        // Visual Engine: Backgrounds
        function applyAesthetic(type) {
            document.getElementById('meshView').style.display = (type === 'mesh') ? 'block' : 'none';
            document.getElementById('patternView').style.display = (type === 'pattern') ? 'block' : 'none';
        }

        document.getElementById('fileInput').onchange = function(evt) {
            const [file] = this.files;
            if (file) {
                const url = URL.createObjectURL(file);
                document.getElementById('previewImg').src = url;
                document.getElementById('dynamicBgImg').style.backgroundImage = `url(${url})`;
                document.getElementById('removeTrigger').value = "0";
            }
        };

        function markForRemoval() {
            document.getElementById('removeTrigger').value = "1";
            document.getElementById('previewImg').style.opacity = "0.2";
            document.getElementById('dynamicBgImg').style.display = "none";
            document.getElementById('removeBtn').innerText = "Marked";
        }

        document.getElementById('fontPicker').onchange = (e) => document.body.style.fontFamily = e.target.value;
        document.getElementById('speedPicker').onchange = (e) => root.setProperty('--transition', e.target.value);
    </script>
</body>
</html>