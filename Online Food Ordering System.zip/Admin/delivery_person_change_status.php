<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Check ID
if (isset($_GET['id']) && !empty($_GET['id'])) {

    $id = intval($_GET['id']);

    // Get current status
    $result = $conn->query("SELECT status FROM delivery_person WHERE id = $id");

    if ($result && $result->num_rows > 0) {

        $row = $result->fetch_assoc();
        $current_status = $row['status'];

        // Toggle status
        $new_status = ($current_status == "Active") ? "Offline" : "Active";

        // Update status
        $conn->query("UPDATE delivery_person SET status='$new_status' WHERE id=$id");
    }
}

// Redirect back
header("Location: delivery_person.php");
exit();
?>

<?php include("admin_theme_loader.php"); ?>