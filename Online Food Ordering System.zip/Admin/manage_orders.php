<?php
session_set_cookie_params(86400 * 30);
session_start();

// Check Admin Login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

$conn = new mysqli("localhost", "root", "", "online_food");
if ($conn->connect_error) die("Connection Failed: " . $conn->connect_error);

// Load Theme Settings
include("admin_theme_loader.php");
$theme_query = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_query);

// Sync Sidebar Count: Count Pending, Preparing, and Out for Delivery (In Transit) as Active
$active_statuses = "('Pending', 'Preparing', 'Out for Delivery', 'In Transit')";
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN $active_statuses");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// Update Order Status Logic
$message = "";
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['order_status'];
    // Step: Check current status to prevent returning to start
    $check_q = $conn->query("SELECT order_status FROM orders WHERE order_id='$order_id'");
    $current_status = $check_q->fetch_assoc()['order_status'] ?? '';

    if ($current_status != 'Delivered' && $status != "Delivered") {
        $stmt = $conn->prepare("UPDATE orders SET order_status=? WHERE order_id=?");
        $stmt->bind_param("si", $status, $order_id);
        if($stmt->execute()) {
            $message = "Order #$order_id updated to $status successfully!";

            // Get customer_id for notification
            $cust_q = $conn->query("SELECT customer_id FROM orders WHERE order_id='$order_id'");
            $cust_data = $cust_q->fetch_assoc();
            $customer_id = $cust_data['customer_id'] ?? null;

            // Notification & Email Trigger
            require_once "../email_helper.php";
            $customer_email = '';
            $customer_name = '';
            if ($customer_id) {
                $cust_email_q = $conn->query("SELECT email, name FROM customers WHERE customer_id='$customer_id'");
                if ($cust_email_q && $cust_email_q->num_rows > 0) {
                    $cust_row = $cust_email_q->fetch_assoc();
                    $customer_email = $cust_row['email'];
                    $customer_name = $cust_row['name'];
                }
            }

            if ($customer_id && $status == "Preparing") {
                addNotification($conn, $customer_id, 'customer', "Your Order is now being prepared.", $order_id);
                addNotification($conn, null, 'delivery', "A New Order is ready for pickup in the pool.", $order_id);
                
                if (!empty($customer_email)) {
                    sendOrderEmail($customer_email, "Order Being Prepared! (Order #$order_id)", "<h3>Hello $customer_name,</h3><p>Your order (<strong>#$order_id</strong>) is now being prepared by the restaurant.</p>");
                }

                // --- NEW: Send email to all active delivery persons ---
                $delivery_emails = [];
                $dp_res = $conn->query("SELECT email FROM delivery_person WHERE status='Active'");
                if ($dp_res) {
                    while($dp_row = $dp_res->fetch_assoc()){
                        if(!empty($dp_row['email'])) $delivery_emails[] = $dp_row['email'];
                    }
                }
                if(!empty($delivery_emails)){
                    sendOrderEmail($delivery_emails, "New Order Available! (#$order_id)", "<h3>Attention Rider,</h3><p>A new order (<strong>#$order_id</strong>) is now in the kitchen and will be ready for pickup soon.</p><p>Please check your rider app to accept the delivery.</p>");
                }
                // ---------------------------------------------------
            } elseif ($status == "Cancelled") {
                if ($customer_id) {
                    addNotification($conn, $customer_id, 'customer', "Your Order has been cancelled.", $order_id);
                }
                
                if (!empty($customer_email)) {
                    sendOrderEmail($customer_email, "Order Cancelled (Order #$order_id)", "<h3>Hello $customer_name,</h3><p>We are sorry to inform you that your order (<strong>#$order_id</strong>) has been cancelled.</p><p>Please contact support for any issues.</p>");
                }
            }
        }
    } else if ($current_status == 'Delivered') {
        $message = "🚫 Error: Finished orders cannot be modified.";
    }
}

// Filter Logic: THE FIX
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'active';
$status_filter = "";

$start_date = isset($_GET['start_date']) ? $conn->real_escape_string($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? $conn->real_escape_string($_GET['end_date']) : '';

$date_sql = "";
if (!empty($start_date) && !empty($end_date)) {
    $date_sql = " AND DATE(orders.order_date) >= '$start_date' AND DATE(orders.order_date) <= '$end_date'";
}

if ($tab == 'active') {
    // KITCHEN QUEUE: Strictly only things being cooked or pending
    // Removed 'Out for Delivery' from here so it moves out once assigned/picked up
    $status_filter = "WHERE orders.order_status IN ('Pending', 'Preparing')" . $date_sql;
} elseif ($tab == 'transit') {
    // IN TRANSIT: Shows both assigned riders and riders on the road
    $status_filter = "WHERE orders.order_status IN ('Out for Delivery', 'In Transit')" . $date_sql;
} elseif($tab == 'completed') {
    $status_filter = "WHERE orders.order_status = 'Delivered'" . $date_sql;
} elseif($tab == 'cancelled') {
    $status_filter = "WHERE orders.order_status = 'Cancelled'" . $date_sql;
}

// Update Dynamic Counts to match the new filters
$count_active = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')")->fetch_assoc()['total'];
$count_transit = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Out for Delivery', 'In Transit')")->fetch_assoc()['total'];

// Fetch Orders with Full Details
$orders = $conn->query("SELECT orders.*,
                        customers.customer_id, customers.email,
                        dp.name as rider_name, dp.phone as rider_phone, dp.vehicle_type, dp.vehicle_number
                        FROM orders
                        LEFT JOIN customers ON orders.customer_id = customers.customer_id
                        LEFT JOIN delivery_person dp ON orders.delivery_person_id = dp.id
                        $status_filter
                        ORDER BY order_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="15"> <!-- Auto refresh every 15 seconds for dispatch sync -->
    <title>Executive Dispatch | Report Studio</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <style>
        :root { --primary: #f97316; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; margin: 0; height: 100vh; overflow: hidden; }
        .sidebar-premium { width: 288px; height: 100vh; flex-shrink: 0; display: flex; flex-direction: column; }
        .main-content { flex: 1; display: flex; flex-direction: column; height: 100vh; }
        .scroll-section { flex: 1; overflow-y: auto; padding: 2rem; }
        .glass-nav { backdrop-filter: blur(12px); border-bottom: 1px solid rgba(0,0,0,0.05); height: 72px; flex-shrink: 0; }
        .badge { padding: 4px 10px; border-radius: 8px; font-size: 11px; font-weight: 800; text-transform: uppercase; }
        .badge-pending { background: #fff7ed; color: #c2410c; }
        .badge-delivered { background: #ecfdf5; color: #047857; }
        .badge-preparing { background: #e0f2fe; color: #0284c7; }
        .badge-cancelled { background: #fef2f2; color: #dc2626; }

        .export-btn {
            padding: 10px 24px;
            border-radius: 12px;
            font-weight: 800;
            font-size: 11px;
            text-transform: uppercase;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .btn-excel { background: #10b981; color: white; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.2); }
        .btn-pdf { background: #f97316; color: white; box-shadow: 0 4px 15px rgba(249, 115, 22, 0.2); }
        .export-btn:hover { transform: translateY(-2px); filter: brightness(1.1); }

        /* 4. MODERN SCROLLBAR */
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>
<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo" class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

    <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

        <a href="dashboard.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Dashboard</span>
            </div>
        </a>

        <a href="manage_food.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Manage Food</span>
            </div>
            <span class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
        </a>

        <a href="manage_categories.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Categories</span>
            </div>
        </a>

        <a href="manage_promo.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Coupons</span>
            </div>
            <span class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
        </a>

        <a href="manage_orders.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
    <div class="flex items-center gap-3">
        <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
        <span class="font-semibold text-sm">Active Orders</span>
    </div>
    <?php if($active_orders_count > 0): ?>
        <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
            <?php echo $active_orders_count; ?>
        </span>
    <?php endif; ?>
</a>

        <a href="manage_customers.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Customer Base</span>
            </div>
        </a>
        <a href="manage_vip.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
            <div class="flex items-center gap-3">
                <i class="fas fa-star w-5"></i>
                <span class="font-semibold text-sm">VIP Members</span>
            </div>
        </a>

        <div class="my-4 border-t border-slate-800/50 mx-4"></div>
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

        <a href="admin_feedback.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Feedback</span>
            </div>
        </a>

        <a href="manage_delivery_person.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Fleet Status</span>
            </div>
            <span class="relative flex h-2 w-2">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
        </a>

        <a href="admin_withdrawals.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Rider Payouts</span>
            </div>
            <?php if(isset($withdraw_count) && $withdraw_count > 0): ?>
            <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                <?= $withdraw_count ?>
            </span>
            <?php endif; ?>
        </a>

        <a href="sales_report.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Sales Analytics</span>
            </div>
        </a>

        <a href="delivery_settings.php" class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
        <div class="flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                <i class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
            </div>
            <div class="flex flex-col">
                <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP Customers</span>
                <span class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics & Rules</span>
            </div>
        </div>
        <i class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

        <div class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </a>

        <a href="change_theme.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Change Theme</span>
            </div>
            <span class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
        </a>

        <a href="change_password_auth.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

    <div class="flex items-center gap-3 relative z-10">
        <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
            <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
        </div>

        <div class="flex flex-col">
            <span class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access Security</span>
            <span class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update Master Key</span>
        </div>
    </div>

    <div class="relative z-10 flex items-center">
        <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]"></div>
        <i class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
    </div>
</a>
    </nav>

    <div class="p-6 border-t border-slate-800/50">
        <a href="logout.php" class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
            <i class="fas fa-power-off"></i>
            <span class="font-bold text-sm">Sign Out</span>
        </a>
    </div>
</aside>

    <div class="main-content">
        <header class="glass-nav px-8 flex items-center justify-between z-50">
            <div>
                <h1 class="text-xl font-900 uppercase italic">Order <span style="color:var(--primary)">Logistics</span></h1>
                <p class="text-[9px] font-black opacity-40 uppercase tracking-widest">Dispatch Intelligence Center</p>
            </div>

            <div class="flex items-center gap-3">
                <button onclick="exportToPDFStyled()" class="bg-rose-500 hover:bg-rose-600 text-white px-6 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-rose-500/20 transition-all"><i class="fas fa-file-pdf text-lg"></i> PDF</button>
                <button onclick="exportToExcelStyled()" class="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-emerald-500/20 transition-all"><i class="fas fa-file-excel text-lg"></i> EXCEL</button>
            </div>
        </header>

        <!-- Unread Alerts Section -->
        <?php
        $admin_notif_q = $conn->query("SELECT * FROM notifications WHERE user_type='admin' AND is_read=0 ORDER BY created_at DESC LIMIT 20");
        if ($admin_notif_q && $admin_notif_q->num_rows > 0):
        ?>
        <div class="px-8 mt-4">
            <div class="bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-4 border border-slate-700/50 flex flex-col gap-2">
                <p class="text-[9px] font-black text-orange-500 uppercase tracking-widest flex items-center gap-2 mb-2">
                    <span class="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span> Recent System Activity
                </p>
                <div class="max-h-[155px] overflow-y-auto custom-scrollbar pr-2 flex flex-col gap-1">
                    <?php while($n = $admin_notif_q->fetch_assoc()): ?>
                    <a href="manage_orders.php" class="block py-1.5 border-b border-slate-700/30 last:border-0 hover:bg-slate-800 transition-colors">
                        <div class="flex items-center justify-between">
                            <p class="text-white text-xs font-semibold"><?= htmlspecialchars($n['message']) ?></p>
                            <span class="text-slate-500 text-[9px] font-bold shrink-0 ml-2"><?= date('h:i A', strtotime($n['created_at'])) ?></span>
                        </div>
                    </a>
                    <?php endwhile; ?>
                </div>
                <a href="../clear_notifications.php?type=admin" class="text-[9px] font-black text-slate-400 hover:text-white uppercase tracking-widest mt-1">Mark All as Read</a>
            </div>
        </div>
        <?php endif; ?>

        <div class="px-8 mt-6">
            <div class="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-slate-200/50 pb-px">
                <div class="flex flex-wrap items-center gap-4">
                    <a href="?tab=active" class="pb-3 px-4 font-bold text-sm tracking-widest uppercase transition-colors <?php echo ($tab=='active') ? 'text-orange-500 border-b-2 border-orange-500' : 'text-slate-400 hover:text-slate-600 border-b-2 border-transparent'; ?>">
                        <i class="fas fa-fire-burner mr-2"></i> Kitchen Queue (<?= $count_active ?>)
                    </a>
                    <a href="?tab=transit" class="pb-3 px-4 font-bold text-sm tracking-widest uppercase transition-colors <?php echo ($tab=='transit') ? 'text-blue-500 border-b-2 border-blue-500' : 'text-slate-400 hover:text-slate-600 border-b-2 border-transparent'; ?>">
                        <i class="fas fa-motorcycle mr-2"></i> In Transit (<?= $count_transit ?>)
                    </a>
                    <a href="?tab=completed" class="pb-3 px-4 font-bold text-sm tracking-widest uppercase transition-colors <?php echo ($tab=='completed') ? 'text-emerald-500 border-b-2 border-emerald-500' : 'text-slate-400 hover:text-slate-600 border-b-2 border-transparent'; ?>">
                        <i class="fas fa-check-double mr-2"></i> Delivered
                    </a>
                    <a href="?tab=cancelled" class="pb-3 px-4 font-bold text-sm tracking-widest uppercase transition-colors <?php echo ($tab=='cancelled') ? 'text-rose-500 border-b-2 border-rose-500' : 'text-slate-400 hover:text-slate-600 border-b-2 border-transparent'; ?>">
                        <i class="fas fa-ban mr-2"></i> Cancelled
                    </a>
                </div>

                <form method="GET" class="flex flex-wrap items-center gap-3 mb-3 xl:mb-0 bg-slate-50 p-2 rounded-2xl border border-slate-200/60 shadow-sm">
                    <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">

                    <div class="flex items-center gap-3">
                        <div class="relative group">
                            <i class="fas fa-calendar-alt absolute left-4 top-1/2 -translate-y-1/2 text-orange-400 transition-colors z-10"></i>
                            <input type="text" name="start_date" value="<?= htmlspecialchars($start_date) ?>" required class="datepicker bg-white border border-slate-200 rounded-xl py-2 pl-10 pr-3 text-xs font-black text-slate-700 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 transition-all shadow-sm uppercase tracking-widest w-[140px] appearance-none" style="color-scheme: light;" placeholder="DD/MM/YYYY">
                        </div>
                        <span class="text-slate-300 font-900 text-[10px] tracking-widest">TO</span>
                        <div class="relative group">
                            <i class="fas fa-calendar-check absolute left-4 top-1/2 -translate-y-1/2 text-orange-400 transition-colors z-10"></i>
                            <input type="text" name="end_date" value="<?= htmlspecialchars($end_date) ?>" required class="datepicker bg-white border border-slate-200 rounded-xl py-2 pl-10 pr-3 text-xs font-black text-slate-700 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 transition-all shadow-sm uppercase tracking-widest w-[140px] appearance-none" style="color-scheme: light;" placeholder="DD/MM/YYYY">
                        </div>
                    </div>

                    <div class="flex items-center gap-2">
                        <button type="submit" class="bg-slate-900 hover:bg-orange-500 text-white rounded-xl px-5 py-2.5 font-black text-[10px] uppercase tracking-widest shadow-md transition-all active:scale-95 flex items-center gap-2">
                            <i class="fas fa-filter"></i> Apply
                        </button>

                        <?php if(!empty($start_date) || !empty($end_date)): ?>
                        <a href="?tab=<?= $tab ?>" class="bg-rose-50 hover:bg-rose-500 text-rose-500 hover:text-white rounded-xl px-4 py-2.5 font-black text-[10px] uppercase tracking-widest border border-rose-200 hover:border-rose-500 transition-all active:scale-95">
                            <i class="fas fa-times"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="scroll-section">
            <?php
            // Buffer records to construct hidden export table transparently
            $order_records = [];

            if ($orders->num_rows == 0): ?>
                <div class="text-center py-20 bg-slate-50 border border-slate-200/60 rounded-[2rem]">
                    <i class="fas fa-box-open text-6xl text-slate-300 mb-4"></i>
                    <h3 class="text-2xl font-900 text-slate-700 tracking-tight">No records found.</h3>
                    <p class="text-slate-400 font-bold tracking-widest uppercase text-xs mt-2">Try switching tabs.</p>
                </div>
            <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 pb-10">
                <?php
                while ($row = $orders->fetch_assoc()):
                    $order_records[] = $row;
                    $raw_status = str_replace(' ', '', strtolower($row['order_status']));
                    $statusClass = 'badge-' . $raw_status;
                ?>
                <div class="bg-white rounded-[2rem] p-6 lg:p-8 shadow-xl border border-slate-100 hover:shadow-[0_20px_40px_-5px_rgba(249,115,22,0.15)] hover:-translate-y-1.5 transition-all duration-500 flex flex-col relative overflow-hidden group">
                    <div class="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

                    <div class="flex justify-between items-start mb-6 relative z-10">
                        <div>
                            <span class="bg-orange-50 text-orange-600 text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1.5 rounded-full border border-orange-100">ORD-<?= $row['order_id']; ?></span>
                            <div class="text-[10px] text-slate-400 font-bold mt-2.5 uppercase tracking-widest"><i class="far fa-clock mr-1"></i><?= date('d/m/Y h:i A', strtotime($row['order_date'])); ?></div>
                        </div>
                        <span class="badge <?= $statusClass; ?> text-[9px] shadow-sm tracking-[0.1em] px-3 py-1.5"><?= htmlspecialchars($row['order_status']); ?></span>
                    </div>

                    <div class="flex-1 relative z-10">
                        <h3 class="font-900 text-xl text-slate-800 tracking-tight leading-tight italic pr-4"><?= htmlspecialchars($row['customer_name']); ?></h3>
                        <div class="text-[11px] text-slate-500 font-semibold mt-4 flex items-center gap-2">
                            <div class="w-6 h-6 rounded-lg bg-emerald-50 text-emerald-500 flex items-center justify-center shrink-0"><i class="fas fa-phone-alt text-[9px]"></i></div>
                            <?= htmlspecialchars($row['phone']); ?>
                        </div>
                        <div class="text-[11px] text-slate-500 font-medium mt-2 flex items-start gap-2 h-14 overflow-hidden leading-snug">
                            <div class="w-6 h-6 rounded-lg bg-rose-50 text-rose-500 flex items-center justify-center shrink-0 mt-0.5"><i class="fas fa-map-marker-alt text-[10px]"></i></div>
                            <?= htmlspecialchars($row['address']); ?>
                        </div>
                    </div>

                    <div class="border-t border-slate-100/80 my-5 relative z-10"></div>

                    <div class="flex justify-between items-end relative z-10 mb-6">
                        <div>
                            <p class="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Total Bill</p>
                            <h2 class="text-3xl font-900 text-slate-900 tracking-tighter">&#8377;<?= number_format($row['total_amount'], 2); ?></h2>
                        </div>
                        <div class="flex flex-col items-end gap-2">
                            <div class="text-[9px] font-black text-indigo-600 bg-indigo-50 border-indigo-200 uppercase tracking-[0.2em] px-3 py-2 rounded-xl border shadow-sm flex items-center gap-1.5">
                                <i class="fas fa-credit-card"></i> <?= htmlspecialchars($row['payment_method']); ?>
                            </div>
                            <?php if (!in_array($row['order_status'], ['Pending', 'Cancelled'])): ?>
                            <a href="generate_bill_pdf.php?order_id=<?= $row['order_id'] ?>" target="_blank" class="text-[9px] font-black bg-orange-500 hover:bg-orange-600 text-white uppercase tracking-[0.2em] px-3 py-2 rounded-xl shadow-md hover:shadow-orange-500/30 transition-all flex items-center gap-1.5">
                                <i class="fas fa-file-invoice pl-0.5"></i> Download Bill
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="relative z-10">
                        <?php if ($row['order_status'] == 'Delivered'): ?>
                            <div class="w-full text-center py-3.5 bg-emerald-50 text-emerald-600 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl border border-emerald-100 shadow-sm"><i class="fas fa-check-circle mr-2 opacity-60"></i> Delivered & Secured</div>
                        <?php elseif (!empty($row['delivery_person_id'])): ?>
                            <div class="w-full text-left p-4 bg-blue-50 text-blue-800 rounded-xl border border-blue-100 shadow-sm relative overflow-hidden group-hover:shadow-[0_4px_20px_-5px_rgba(59,130,246,0.3)] transition-all">
                                <div class="absolute right-0 top-0 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
                                <p class="text-[9px] font-black uppercase tracking-[0.2em] text-blue-600 mb-3 ml-1 flex items-center gap-2"><div class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse ml-1"></div> Dispatched to Logistics</p>
                                <div class="flex flex-col gap-1.5 relative z-10 px-1">
                                    <div class="flex justify-between items-center text-[11px] font-bold"><span class="text-blue-500/80 uppercase tracking-widest text-[9px]"><i class="fas fa-user-circle mr-1"></i> Rider</span> <span class="text-blue-900"><?= htmlspecialchars($row['rider_name']) ?></span></div>
                                    <div class="flex justify-between items-center text-[11px] font-bold"><span class="text-blue-500/80 uppercase tracking-widest text-[9px]"><i class="fas fa-phone mr-1"></i> Phone</span> <a href="tel:<?= htmlspecialchars($row['rider_phone']) ?>" class="text-blue-600 hover:underline"><?= htmlspecialchars($row['rider_phone']) ?></a></div>
                                    <div class="flex justify-between items-center text-[11px] font-bold"><span class="text-blue-500/80 uppercase tracking-widest text-[9px]"><i class="fas fa-car mr-1"></i> Vehicle</span> <span class="text-blue-900 uppercase"><?= htmlspecialchars($row['vehicle_number']) ?></span></div>
                                </div>
                            </div>
                        <?php else: ?>
                            <form method="POST" class="flex items-center gap-2 w-full">
                                <input type="hidden" name="order_id" value="<?= $row['order_id']; ?>">
                                <select name="order_status" class="flex-1 text-[11px] uppercase tracking-widest font-black p-3.5 border border-slate-200 rounded-xl outline-none cursor-pointer bg-slate-50 text-slate-700 text-center hover:bg-slate-100 transition-colors appearance-none">
                                    <option value="Pending" <?= ($row['order_status']=='Pending'?'selected':'') ?>>Pending</option>
                                    <option value="Preparing" <?= ($row['order_status']=='Preparing'?'selected':'') ?>>Preparing</option>
                                    <option value="Cancelled" <?= ($row['order_status']=='Cancelled'?'selected':'') ?>>Cancelled</option>
                                </select>
                                <button type="submit" name="update_status" class="w-12 h-12 bg-slate-900 hover:bg-orange-500 text-white rounded-xl shadow-lg hover:shadow-orange-500/30 transition-all flex items-center justify-center shrink-0 active:scale-95">
                                    <i class="fa fa-paper-plane text-[10px]"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>

            <!-- Hidden Table strictly for Legacy PDF/Excel JS Exporter Parsing Context -->
            <table class="hidden w-full text-left border-collapse" id="mainDataTable">
                <thead><tr><th>Order ID</th><th>Customer Name</th><th>Phone</th><th>Total Amount</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                    <?php foreach($order_records as $r): ?>
                    <tr>
                        <td class="order-id">ORD-<?= $r['order_id'] ?></td>
                        <td class="customer-name"><?= htmlspecialchars($r['customer_name']) ?></td>
                        <td class="customer-phone"><?= htmlspecialchars($r['phone']) ?></td>
                        <td class="total-val">&#8377;<?= number_format($r['total_amount'], 2) ?></td>
                        <td class="status-text"><?= htmlspecialchars($r['order_status']) ?></td>
                        <td class="order-date"><?= date('d/m/Y', strtotime($r['order_date'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // PDF EXPORT WITH STYLING
        function exportToPDFStyled() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('l', 'pt', 'a4');

            // 1. Draw Orange Header Block
            doc.setFillColor(249, 115, 22); // Orange
            doc.rect(0, 0, 900, 80, 'F');

            // 2. Add Big Bold White Title
            doc.setFont("helvetica", "bold");
            doc.setFontSize(24);
            doc.setTextColor(255, 255, 255);
            doc.text("FOODIE'S HEAVEN DISPATCH REPORT", 40, 45);

            doc.setFontSize(10);
            doc.text("Timeline: All Time  |  GENERATED ON: " + new Date().toLocaleString(), 40, 75);

            // 3. Prepare Table Data
            const columns = ["Order ID", "Customer Name", "Phone", "Total Amount", "Status", "Date"];
            const rows = [];
            document.querySelectorAll("#mainDataTable tbody tr").forEach(tr => {
                rows.push([
                    tr.querySelector('.order-id').innerText,
                    tr.querySelector('.customer-name').innerText,
                    tr.querySelector('.customer-phone').innerText,
                    tr.querySelector('.total-val').innerText.replace(/₹/g, 'Rs. '), // Fix Helvetica Garbled Render
                    tr.querySelector('.status-text').innerText,
                    tr.querySelector('.order-date').innerText
                ]);
            });

            // 4. Generate AutoTable
            doc.autoTable({
                rowPageBreak: 'avoid',
                head: [columns],
                body: rows,
                startY: 100,
                theme: 'striped',
                headStyles: { fillColor: [30, 41, 59], fontStyle: 'bold', font: 'helvetica' },
                styles: { font: 'helvetica', fontSize: 9, cellPadding: 6, overflow: 'linebreak' }
            });

            doc.save("Order_Report.pdf");
        }

        // EXCEL EXPORT WITH STYLING
        async function exportToExcelStyled() {
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Orders');

            // 1. Add Styled Header Row
            const titleRow = worksheet.addRow(["FOODIE'S HEAVEN EXECUTIVE - OFFICIAL ORDERS LOG"]);
            titleRow.font = { name: 'Arial', size: 16, bold: true, color: { argb: 'FFFFFFFF' } };
            titleRow.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF97316' } }; // Orange
            worksheet.mergeCells('A1:F1');
            titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
            titleRow.height = 30;

            // 1.5 Timeline Row (Left Aligned)
            const timelineRow = worksheet.addRow(["Timeline: All Time  |  GENERATED ON: " + new Date().toLocaleString()]);
            worksheet.mergeCells('A2:F2');
            timelineRow.font = { name: 'Arial', bold: true, size: 10, color: { argb: 'FF333333' } };
            timelineRow.alignment = { horizontal: 'left' };

            // 2. Define Columns & Header
            worksheet.addRow(["Order ID", "Customer Name", "Phone", "Final Bill", "Status", "Order Date"]);
            const headerRow = worksheet.getRow(3);
            headerRow.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
            headerRow.eachCell(cell => {
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } }; // Dark Header
                cell.alignment = { horizontal: 'center' };
            });

            // 3. Add Data from Table
            document.querySelectorAll("#mainDataTable tbody tr").forEach(tr => {
                let amountText = tr.querySelector('.total-val').innerText.trim();
                let amountNum = parseFloat(amountText.replace(/[^0-9.-]+/g, ''));
                
                let row = worksheet.addRow([
                    tr.querySelector('.order-id').innerText,
                    tr.querySelector('.customer-name').innerText,
                    tr.querySelector('.customer-phone').innerText,
                    amountNum,
                    tr.querySelector('.status-text').innerText,
                    tr.querySelector('.order-date').innerText
                ]);
                
                // Format the currency cell correctly
                let currCell = row.getCell(4);
                currCell.numFmt = '[$₹-en-IN]#,##0.00';
                currCell.font = { bold: true, color: { argb: 'FF0F172A' } };
            });

            // 4. Formatting
            worksheet.getColumn(1).width = 15;
            worksheet.getColumn(2).width = 25;
            worksheet.getColumn(3).width = 15;
            worksheet.getColumn(4).width = 15;
            worksheet.getColumn(5).width = 15;
            worksheet.getColumn(6).width = 20;

            // 5. Save File
            const buffer = await workbook.xlsx.writeBuffer();
            saveAs(new Blob([buffer]), "Foodies_Heaven_Orders.xlsx");
        }

        // Initialize Flatpickr for beautiful Date formats guaranteed to be DD/MM/YYYY visually
        flatpickr(".datepicker", {
            dateFormat: "Y-m-d", // Value sent to the system for filtering
            altInput: true,      // Uses a visually swapped input field
            altFormat: "d/m/Y",  // Forces DD/MM/YYYY output explicitly for the user
            allowInput: true,
            disableMobile: "true" // Ensures true matching across mobile devices
        });
    </script>
</body>
</html>