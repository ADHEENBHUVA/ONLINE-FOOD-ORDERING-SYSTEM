<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Check Admin Login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

if(!isset($_GET['id'])){
    header("Location: manage_food.php");
    exit();
}

$id = intval($_GET['id']);
$result = mysqli_query($conn, "SELECT * FROM food_items WHERE food_id='$id'");
$data = mysqli_fetch_assoc($result);

// Fetch categories
$cat_result = mysqli_query($conn, "SELECT * FROM categories");

$message = "";
$status_type = "";

if(isset($_POST['update'])){

    $name = mysqli_real_escape_string($conn, $_POST['food_name']);
    $price = $_POST['price'];
    $category = $_POST['category_id'];
    $status = $_POST['status'];
    $description = mysqli_real_escape_string($conn, $_POST['description'] ?? '');

    $image = $data['image']; // keep old image by default

    if($price <= 0){
        $message = "Price must be greater than 0";
        $status_type = "error";
    }
    else {

        // Check if new image uploaded
        if(!empty($_FILES['image']['name'])){

            $file_name = $_FILES['image']['name'];
            $file_tmp = $_FILES['image']['tmp_name'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            if(strpos($_FILES['image']['type'], 'image/') !== 0){
                $message = "Only authentic image formats are allowed";
                $status_type = "error";
            }
            else{

                $image = time()."_".$file_name;

                move_uploaded_file($file_tmp,"../images/".$image);

            }
        }

        // Update food item
        $update = "UPDATE food_items
                   SET food_name='$name',
                       price='$price',
                       category_id='$category',
                       description='$description',
                       status='$status',
                       image='$image'
                   WHERE food_id='$id'";

        mysqli_query($conn,$update);

        header("Location: manage_food.php?msg=updated");
        exit();
    }
}
?>

<?php include("admin_theme_loader.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Editor | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; }
        .glass-morphism {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.5);
        }
        .input-premium {
            background: #f8fafc;
            border: 2px solid transparent;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .input-premium:focus {
            background: #ffffff;
            border-color: #f97316;
            box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.1);
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="bg-[url('https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&q=80')] bg-cover bg-center bg-fixed min-h-screen relative py-12 px-4 selection:bg-orange-500 selection:text-white overflow-y-auto">

    <!-- Ambient Overlay -->
    <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-0"></div>

    <main class="relative z-10 w-full max-w-5xl mx-auto">

        <?php if($message): ?>
            <div class="mb-6 p-5 rounded-2xl flex items-center justify-center gap-3 shadow-2xl animate-bounce <?php echo $status_type == 'error' ? 'bg-rose-500 text-white' : 'bg-emerald-500 text-white'; ?>">
                <i class="fas <?php echo $status_type == 'error' ? 'fa-exclamation-circle' : 'fa-check-circle'; ?> text-xl"></i>
                <span class="font-bold tracking-wide"><?php echo $message; ?></span>
            </div>
        <?php endif; ?>

        <div class="glass-morphism rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.3)] overflow-hidden flex flex-col md:flex-row">

            <!-- Left Branding Panel -->
            <div class="bg-gradient-to-br from-slate-900 to-slate-800 p-12 text-white md:w-1/3 flex flex-col justify-between relative overflow-hidden">
                <div class="absolute -top-24 -right-24 w-64 h-64 bg-orange-500 rounded-full blur-[80px] opacity-50"></div>
                <div class="absolute -bottom-24 -left-24 w-64 h-64 bg-indigo-500 rounded-full blur-[80px] opacity-30"></div>

                <div class="relative z-10">
                    <a href="manage_food.php" class="inline-flex items-center gap-2 text-white/60 hover:text-white font-bold text-sm tracking-widest uppercase transition-colors mb-12">
                        <i class="fas fa-arrow-left"></i> Cancel Edit
                    </a>
                    <h1 class="text-4xl font-black tracking-tighter leading-tight mb-4">Dish<br><span class="text-orange-500">Mastery.</span></h1>
                    <p class="text-slate-400 font-medium leading-relaxed">You are currently in supreme editor mode. Refine your culinary creations to absolute perfection.</p>
                </div>

                <div class="relative z-10 mt-12 bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-md">
                    <p class="text-[10px] font-black uppercase tracking-[0.2em] text-orange-400 mb-2">Currently Editing</p>
                    <p class="font-bold text-lg italic text-white/90 truncate"><?php echo htmlspecialchars($data['food_name']); ?></p>
                </div>
            </div>

            <!-- Right Form Panel -->
            <div class="p-10 md:p-14 md:w-2/3 bg-white/60">
                <form method="POST" enctype="multipart/form-data" class="space-y-8">

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div class="space-y-3">
                            <label class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1">Dish Name</label>
                            <input type="text" name="food_name" value="<?php echo htmlspecialchars($data['food_name']); ?>" required
                            class="w-full px-5 py-4 input-premium rounded-2xl font-bold text-slate-700 outline-none">
                        </div>

                        <div class="space-y-3">
                            <label class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1">Price (&#8377;)</label>
                            <input type="number" name="price" value="<?php echo $data['price']; ?>" min="1" step="1" required
                            class="w-full px-5 py-4 input-premium rounded-2xl font-bold text-slate-700 outline-none">
                        </div>

                        <div class="space-y-3">
                            <label class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1">Cuisine Category</label>
                            <select name="category_id" class="w-full px-5 py-4 input-premium rounded-2xl font-bold text-slate-700 outline-none appearance-none cursor-pointer">
                                <?php while($cat=mysqli_fetch_assoc($cat_result)): ?>
                                    <option value="<?php echo $cat['category_id'];?>" <?php if($data['category_id']==$cat['category_id']) echo "selected";?>>
                                        <?php echo $cat['category_name'];?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="space-y-3">
                            <label class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1">Availability</label>
                            <select name="status" class="w-full px-5 py-4 input-premium rounded-2xl font-bold text-slate-700 outline-none appearance-none cursor-pointer">
                                <option value="Available" <?php if($data['status']=="Available") echo "selected";?>>🟢 Available to Order</option>
                                <option value="Unavailable" <?php if($data['status']=="Unavailable") echo "selected";?>>🔴 Sold Out / Hidden</option>
                            </select>
                        </div>
                    </div>

                    <div class="space-y-3">
                        <label class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1">Delicious Description</label>
                        <textarea name="description" rows="3" placeholder="Craft a mouth-watering description..." required
                        class="w-full px-5 py-4 input-premium rounded-2xl font-medium text-slate-600 outline-none resize-none leading-relaxed"><?php echo htmlspecialchars($data['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="space-y-3">
                        <label class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1">Culinary Identity (Image)</label>
                        <div class="p-2 border-2 border-dashed border-slate-300 rounded-[2rem] bg-white/50 flex flex-col sm:flex-row items-center gap-6 group hover:border-orange-400 transition-colors">
                            <div class="relative h-32 w-32 flex-shrink-0 m-4 shadow-xl rounded-3xl overflow-hidden group-hover:scale-105 transition-transform">
                                <img src="../images/<?php echo $data['image']; ?>" id="preview" class="h-full w-full object-cover">
                                <div class="absolute inset-0 ring-1 ring-inset ring-black/10 rounded-3xl"></div>
                            </div>
                            <div class="flex-1 px-4 pb-4 sm:pb-0 text-center sm:text-left">
                                <label class="cursor-pointer bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md transition-all active:scale-95 inline-block mb-3">
                                    <i class="fas fa-upload mr-2"></i> Choose New Photo
                                    <input type="file" name="image" accept="image/*" class="hidden" onchange="previewImage(this)">
                                </label>
                                <p class="text-[10px] font-black uppercase tracking-widest text-slate-400">Supported: All Image Formats</p>
                            </div>
                        </div>
                    </div>

                    <div class="pt-6 border-t border-slate-200">
                        <button type="submit" name="update" class="w-full bg-slate-900 hover:bg-slate-800 text-white font-black uppercase tracking-widest py-5 rounded-2xl shadow-[0_10px_40px_rgba(15,23,42,0.4)] transition-all transform hover:-translate-y-1 active:translate-y-0 text-sm flex justify-center items-center gap-3">
                            <i class="fas fa-save"></i> Finalize Masterpiece
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </main>

<script>
function previewImage(input){
    if(input.files && input.files[0]){
        var reader = new FileReader();
        reader.onload = function(e){
            document.getElementById('preview').src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

</body>
</html>