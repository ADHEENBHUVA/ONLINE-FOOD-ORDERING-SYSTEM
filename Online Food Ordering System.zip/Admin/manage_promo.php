<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Check Admin Login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

// Load Theme Settings
include("admin_theme_loader.php");
$theme_query = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_query);

// Orders Counter for Sidebar
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

/* ================= DELETE PROMO ================= */
if(isset($_GET['delete'])){
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    $conn->query("DELETE FROM promo_codes WHERE id='$id'");
    header("Location: manage_promo.php?msg=deleted");
    exit();
}

/* ================= ACTIVATE / DEACTIVATE ================= */
if(isset($_GET['status'])){
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $status = mysqli_real_escape_string($conn, $_GET['status']);
    $conn->query("UPDATE promo_codes SET status='$status' WHERE id='$id'");
    header("Location: manage_promo.php?msg=status_updated");
    exit();
}

/* ================= FETCH ALL PROMOS ================= */
$result = $conn->query("SELECT * FROM promo_codes ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promo Manager | Executive Admin</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root { --primary: #f97316; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f8fafc;
            margin: 0; height: 100vh; overflow: hidden;
        }
        .sidebar-premium { background: #0f172a; width: 288px; height: 100vh; flex-shrink: 0; display: flex; flex-direction: column; }
        .main-content { flex: 1; display: flex; flex-direction: column; min-width: 0; height: 100vh; }
        .scrollable-area { flex: 1; overflow-y: auto; padding: 2rem; }

        .glass-nav {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(12px); border-bottom: 1px solid rgba(0,0,0,0.05); height: 72px; display: flex; align-items: center; padding: 0 2rem; z-index: 50;
        }

        .custom-card {
            background: #ffffff;
            border-radius: 1.5rem; border: 1px solid #e2e8f0;
        }

        .update-btn {
            background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            box-shadow: 0 4px 12px rgba(168, 85, 247, 0.2);
            transition: all 0.3s ease;
        }
        .update-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(168, 85, 247, 0.3); }

        /* Custom Scrollbar for Sidebar */
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>

<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo" class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

    <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

        <a href="dashboard.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Dashboard</span>
            </div>
        </a>

        <a href="manage_food.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Manage Food</span>
            </div>
            <span class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
        </a>

        <a href="manage_categories.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Categories</span>
            </div>
        </a>

        <a href="manage_promo.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Coupons</span>
            </div>
            <span class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
        </a>

        <a href="manage_orders.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
    <div class="flex items-center gap-3">
        <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
        <span class="font-semibold text-sm">Active Orders</span>
    </div>
    <?php if($active_orders_count > 0): ?>
        <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
            <?php echo $active_orders_count; ?>
        </span>
    <?php endif; ?>
</a>

        <a href="manage_customers.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Customer Base</span>
            </div>
        </a>
        <a href="manage_vip.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
            <div class="flex items-center gap-3">
                <i class="fas fa-star w-5"></i>
                <span class="font-semibold text-sm">VIP Members</span>
            </div>
        </a>

        <div class="my-4 border-t border-slate-800/50 mx-4"></div>
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

        <a href="admin_feedback.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Feedback</span>
            </div>
        </a>

        <a href="manage_delivery_person.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Fleet Status</span>
            </div>
            <span class="relative flex h-2 w-2">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
        </a>

        <a href="admin_withdrawals.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Rider Payouts</span>
            </div>
            <?php if(isset($withdraw_count) && $withdraw_count > 0): ?>
            <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                <?= $withdraw_count ?>
            </span>
            <?php endif; ?>
        </a>

        <a href="sales_report.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Sales Analytics</span>
            </div>
        </a>

        <a href="delivery_settings.php" class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
        <div class="flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                <i class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
            </div>
            <div class="flex flex-col">
                <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP Customers</span>
                <span class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics & Rules</span>
            </div>
        </div>
        <i class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

        <div class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </a>

        <a href="change_theme.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Change Theme</span>
            </div>
            <span class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
        </a>

        <a href="change_password_auth.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

    <div class="flex items-center gap-3 relative z-10">
        <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
            <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
        </div>

        <div class="flex flex-col">
            <span class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access Security</span>
            <span class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update Master Key</span>
        </div>
    </div>

    <div class="relative z-10 flex items-center">
        <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]"></div>
        <i class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
    </div>
</a>
    </nav>

    <div class="p-6 border-t border-slate-800/50">
        <a href="logout.php" class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
            <i class="fas fa-power-off"></i>
            <span class="font-bold text-sm">Sign Out</span>
        </a>
    </div>
</aside>

    <div class="main-content">
        <header class="glass-nav justify-between">
            <div>
                <h1 class="text-xl font-800 tracking-tight italic uppercase">Promo Manager</h1>
                <p class="text-[10px] uppercase font-bold opacity-50 tracking-widest mt-1">Manage active coupons & tracking</p>
            </div>
            <div class="flex items-center gap-4">
                <a href="add_promo.php" class="bg-slate-900 hover:bg-black text-white px-5 py-2.5 rounded-xl text-xs font-bold transition shadow-lg flex items-center gap-2">
                    <i class="fas fa-plus"></i> New Coupon
                </a>
            </div>
        </header>

        <div class="scrollable-area custom-scrollbar">
            <div class="custom-card overflow-hidden shadow-sm">
                <div class="p-6 border-b bg-slate-50/50 flex justify-between items-center">
                    <h2 class="font-800 text-xs uppercase tracking-widest opacity-50 italic">Coupon Registry</h2>
                    <span class="text-[10px] font-black text-purple-500 bg-purple-50 px-2 py-1 rounded border border-purple-100 uppercase tracking-widest">Enforced Rules</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="text-[11px] font-black uppercase tracking-widest opacity-40 border-b">
                                <th class="px-8 py-5">Promo Details</th>
                                <th class="px-8 py-5">Rupees Tracker</th>
                                <th class="px-8 py-5">Date Created</th>
                                <th class="px-8 py-5 text-center">Live Status</th>
                                <th class="px-8 py-5 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php if($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()):
                                    $isActive = $row['status'] == 'Active';
                                    $created_at = isset($row['created_at']) ? date('d/m/Y', strtotime($row['created_at'])) : 'N/A';
                                ?>
                                <tr class="hover:bg-slate-50 transition-all">
                                    <td class="px-8 py-6">
                                        <div class="flex flex-col">
                                            <span class="font-900 text-lg tracking-tighter text-slate-800 uppercase"><?php echo $row['promo_code']; ?></span>
                                            <div class="flex items-center gap-2 mt-1">
                                                <span class="text-[10px] font-black px-2 py-0.5 bg-orange-100 text-orange-600 rounded uppercase">
                                                    <?php
                                                        if (isset($row['discount_type']) && $row['discount_type'] == 'Rupees') {
                                                            echo "&#8377;" . $row['discount_percent'] . " Off";
                                                        } else {
                                                            echo $row['discount_percent'] . "% Off";
                                                        }
                                                    ?>
                                                </span>
                                                <span class="text-[10px] font-bold text-slate-400 uppercase italic"><?php echo str_replace('_',' ', $row['type']); ?></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-8 py-6">
                                        <div class="flex items-center gap-3">
                                            <div class="h-10 w-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                                                <i class="fas fa-coins text-sm"></i>
                                            </div>
                                            <div>
                                                <p class="text-sm font-black text-slate-700">&#8377;<?php echo number_format($row['min_order_amt'] ?? 0, 2); ?></p>
                                                <p class="text-[9px] font-black uppercase text-slate-400 tracking-tighter">Min. Order</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-8 py-6">
                                        <div class="flex flex-col">
                                            <span class="text-sm font-bold text-slate-600"><?php echo $created_at; ?></span>
                                            <span class="text-[10px] font-medium text-slate-400 uppercase">Registered Date</span>
                                        </div>
                                    </td>
                                    <td class="px-8 py-6 text-center">
                                        <span class="px-4 py-1.5 text-[10px] font-black rounded-full border
                                            <?php echo $isActive ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-slate-100 text-slate-400 border-slate-200'; ?> uppercase tracking-widest">
                                            <?php echo $row['status']; ?>
                                        </span>
                                    </td>
                                    <td class="px-8 py-6 text-right space-x-2 whitespace-nowrap">
                                        <a href="edit_promo.php?id=<?php echo $row['id']; ?>" class="update-btn text-white px-4 py-2.5 rounded-xl text-[10px] font-black uppercase inline-flex items-center gap-2">
                                            <i class="fas fa-pen-nib"></i> Update
                                        </a>

                                        <?php if($isActive): ?>
                                            <a href="manage_promo.php?id=<?php echo $row['id']; ?>&status=Inactive" class="bg-slate-100 hover:bg-amber-500 text-slate-600 hover:text-white px-3 py-2.5 rounded-xl text-[10px] font-black transition-all uppercase border">Off</a>
                                        <?php else: ?>
                                            <a href="manage_promo.php?id=<?php echo $row['id']; ?>&status=Active" class="bg-slate-100 hover:bg-emerald-500 text-slate-600 hover:text-white px-3 py-2.5 rounded-xl text-[10px] font-black transition-all uppercase border">On</a>
                                        <?php endif; ?>

                                        <a href="manage_promo.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Delete coupon?')" class="bg-rose-50 text-rose-500 hover:bg-rose-500 hover:text-white px-3 py-2.5 rounded-xl transition-all border border-rose-100">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="px-8 py-32 text-center text-slate-300 italic font-medium">No coupons found in registry.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="mt-8 custom-card p-6 bg-indigo-900 text-white flex items-center justify-between shadow-lg shadow-indigo-100">
                <div class="flex items-center gap-4">
                    <div class="h-12 w-12 rounded-2xl bg-white/10 flex items-center justify-center">
                        <i class="fas fa-shield-check text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm font-bold">Automated Enforcement Active</p>
                        <p class="text-[10px] opacity-60 uppercase tracking-widest">Rupees Tracker validates all checkouts in real-time</p>
                    </div>
                </div>
                <i class="fas fa-bolt text-indigo-400 animate-pulse"></i>
            </div>
            <div class="h-10"></div>
        </div>
    </div>
</body>
</html>