<?php
// admin_theme_loader.php
include("../db.php");

// 1. Fetch current architecture from DB
$theme_res = $conn->query("SELECT * FROM admin_theme WHERE id=1");
$t = $theme_res->fetch_assoc();

// 2. Set defaults if DB is empty
$primary_color = $t['theme_color'] ?? '#f97316';
$sidebar_color = $t['sidebar_color'] ?? '#0f172a';
$body_bg       = $t['background_color'] ?? '#fcfdfe';
$text_color    = $t['font_color'] ?? '#1e293b';
$font_family   = $t['font_family'] ?? 'Plus Jakarta Sans';
$font_size     = $t['font_size'] ?? '16px';
$speed         = $t['transition_speed'] ?? '0.4s';
$aesthetic     = $t['bg_aesthetic'] ?? 'solid';
$bg_image      = $t['background_image'] ?? '';
$mode          = $t['mode'] ?? 'light';
?>
<?php
$multi_weight_fonts = ['Plus Jakarta Sans', 'Poppins', 'Inter', 'Montserrat', 'Roboto', 'Josefin Sans', 'Open Sans', 'Lato', 'Oswald', 'Raleway', 'Ubuntu', 'Nunito', 'Playfair Display', 'Merriweather', 'Rubik', 'Work Sans', 'Fira Sans', 'Quicksand', 'Barlow', 'Inconsolata', 'Mukta', 'PT Sans'];

$font_query = str_replace(' ', '+', $font_family);
if (in_array($font_family, $multi_weight_fonts)) {
    $font_query .= ":wght@300;400;600;700;800;900";
}
?>

<link href="https://fonts.googleapis.com/css2?family=<?php echo $font_query; ?>&display=swap" rel="stylesheet">

<style>
    :root {
        --primary: <?php echo $primary_color; ?>;
        --sidebar-bg: <?php echo $sidebar_color; ?>;
        --body-bg: <?php echo $body_bg; ?>;
        --text-color: <?php echo $text_color; ?>;
        --transition-speed: <?php echo $speed; ?>;
    }

    html, body {
        font-family: '<?php echo $font_family; ?>', sans-serif !important;
        font-size: <?php echo $font_size; ?> !important;
        background-color: var(--body-bg) !important;
        color: var(--text-color);
        margin: 0;
    }

    *, *::before, *::after {
        transition-duration: var(--transition-speed) !important;
    }

    /* SIDEBAR: This will automatically change colour on all pages */
    .sidebar-premium, aside {
        background-color: var(--sidebar-bg) !important;
        transition: background var(--transition-speed) ease;
    }

    /* Support for Background Image */
    <?php if(!empty($bg_image)): ?>
    body::before {
        content: "";
        position: fixed;
        inset: 0;
        z-index: -10;
        background-image: url('../images/<?php echo $bg_image; ?>');
        background-size: cover;
        background-position: center;
        opacity: <?php echo ($mode == 'dark') ? '0.2' : '0.4'; ?>;
    }
    <?php endif; ?>

    /* Support for Mesh Glow */
    <?php if($aesthetic == 'mesh'): ?>
    body::after {
        content: "";
        position: fixed;
        inset: 0;
        z-index: -9;
        background-image: radial-gradient(at 0% 0%, var(--primary) 0, transparent 40%),
                          radial-gradient(at 100% 100%, var(--primary) 0, transparent 40%);
        opacity: 0.1;
        pointer-events: none;
    }
    <?php endif; ?>

    /* Auto-style cards for Glassmorphism */
    .glass-card, .custom-card {
        background: <?php echo ($mode == 'dark') ? 'rgba(30, 41, 59, 0.6)' : 'rgba(255, 255, 255, 0.7)'; ?> !important;
        backdrop-filter: blur(12px) saturate(180%);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: var(--text-color);
    }
</style>

<script>
// Global Input Protections & Enhancements
document.addEventListener('DOMContentLoaded', () => {

    // Universal Number Input Protector for entire Admin Panel
    document.querySelectorAll('input[type="number"]').forEach(input => {
        // Prevent typing minus or 'e' (exponents)
        input.addEventListener('keydown', function(e) {
            if (e.key === '-' || e.key === 'e') {
                e.preventDefault();
            }
        });

        // Clear exactly "0" or "0.00" on click/focus
        input.addEventListener('focus', function() {
            if (this.value === '0' || this.value === '0.00') {
                this.value = '';
            }
        });

        // Restore 0 if left entirely blank on blur
        input.addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.value = '0';
            }
        });

        // Fallback: prevent negative values if pasted
        input.addEventListener('input', function() {
            if (this.value < 0) {
                this.value = 0;
            }
        });
    });

    // Preserve sidebar scroll position across page loads
    const sidebarNav = document.querySelector('nav.custom-scrollbar');
    if (sidebarNav) {
        const savedScroll = sessionStorage.getItem('sidebarScrollPos');
        if (savedScroll !== null) {
            sidebarNav.scrollTop = savedScroll;
        }
        sidebarNav.addEventListener('scroll', () => {
            sessionStorage.setItem('sidebarScrollPos', sidebarNav.scrollTop);
        });
    }
});
</script>