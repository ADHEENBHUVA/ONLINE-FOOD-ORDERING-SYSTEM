<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

$msg = "";
$status_type = "";

if(isset($_POST['add_promo'])){
    $promo_code = mysqli_real_escape_string($conn, strtoupper($_POST['promo_code']));
    $discount_percent = (float)$_POST['discount_percent'];
    $discount_type = mysqli_real_escape_string($conn, $_POST['discount_type']);
    $min_order_amt = (float)$_POST['min_order_amt'];
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Check if code exists
    $check = $conn->query("SELECT * FROM promo_codes WHERE promo_code='$promo_code'");

    if($check && $check->num_rows > 0){
        $msg = "This Promo Code already exists!";
        $status_type = "error";
    } else {
        // usage_limit is 1 to ensure one code per user
        $sql = "INSERT INTO promo_codes (promo_code, discount_percent, min_order_amt, type, discount_type, status)
                VALUES ('$promo_code', '$discount_percent', '$min_order_amt', '$type', '$discount_type', '$status')";

        $insert = $conn->query($sql);

        if($insert) {
            $restriction = ($type == 'FIRST_USER') ? "strictly for new users' first order." : "limited to 1 use per customer.";
            $msg = "Success! Code '$promo_code' is now active and $restriction";
            $status_type = "success";
        } else {
            $msg = "Error: " . $conn->error;
            $status_type = "error";
        }
    }
}
?>

<?php include("admin_theme_loader.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Promo Engine | Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .glass-card { background: white; border-radius: 2rem; border: 1px solid rgba(0,0,0,0.05); }
        .input-box { background: #f1f5f9; border: 2px solid transparent; transition: 0.3s; }
        .input-box:focus { border-color: #8b5cf6; background: white; outline: none; }
    </style>
</head>
<body class="p-4 md:p-8">

<div class="max-w-4xl mx-auto">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-extrabold text-slate-900 tracking-tight">🎯 Promo <span class="text-purple-600">Engine</span></h1>
            <p class="text-slate-500 text-sm">One-time use coupons and First-Order restrictions.</p>
        </div>
        <a href="manage_promo.php" class="bg-white px-5 py-3 rounded-2xl shadow-sm border border-slate-200 text-sm font-bold hover:bg-slate-50 transition">Manage All</a>
    </div>

    <div class="glass-card shadow-2xl overflow-hidden">
        <div class="p-8">
            <?php if ($msg != ""): ?>
                <div class="mb-6 p-4 rounded-2xl border flex items-center gap-3 <?php echo $status_type == 'success' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-rose-50 text-rose-700 border-rose-100'; ?>">
                    <i class="fas <?php echo $status_type == 'success' ? 'fa-circle-check' : 'fa-circle-xmark'; ?>"></i>
                    <span class="font-bold text-sm"><?php echo $msg; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="space-y-2">
                    <label class="text-[10px] font-black uppercase tracking-widest text-slate-400">Coupon Identity</label>
                    <input type="text" name="promo_code" required class="w-full p-4 input-box rounded-2xl font-mono font-bold" placeholder="E.G. NEWFOOD100">
                </div>

                <div class="space-y-2">
                    <label class="text-[10px] font-black uppercase tracking-widest text-slate-400">Discount Value</label>
                    <div class="flex gap-2">
                        <select name="discount_type" class="w-1/3 p-4 input-box rounded-2xl font-bold">
                            <option value="Percentage">% Percent</option>
                            <option value="Rupees">&#8377; Rupees</option>
                        </select>
                        <input type="number" name="discount_percent" step="0.01" min="1" required class="w-2/3 p-4 input-box rounded-2xl font-bold" placeholder="Value">
                    </div>
                </div>

                <div class="space-y-2">
                    <label class="text-[10px] font-black uppercase tracking-widest text-slate-400">Min Order (Rupees Tracker)</label>
                    <input type="number" name="min_order_amt" min="0" required class="w-full p-4 input-box rounded-2xl font-bold" placeholder="500">
                </div>

                <div class="space-y-2">
                    <label class="text-[10px] font-black uppercase tracking-widest text-slate-400">Usage Restriction</label>
                    <select name="type" required class="w-full p-4 input-box rounded-2xl font-bold">
                        <option value="FIRST_USER">First Order Only (New Users)</option>
                        <option value="ANY_USER">One-Time Use (Any User)</option>
                    </select>
                </div>

                <div class="space-y-2">
                    <label class="text-[10px] font-black uppercase tracking-widest text-slate-400">Status</label>
                    <select name="status" class="w-full p-4 input-box rounded-2xl font-bold">
                        <option value="Active">🟢 Active</option>
                        <option value="Inactive">🔴 Inactive</option>
                    </select>
                </div>

                <div class="md:col-span-2 pt-6">
                    <button type="submit" name="add_promo" class="w-full bg-slate-900 text-white font-black py-5 rounded-2xl hover:bg-purple-600 transition-all shadow-xl">
                        ACTIVATE ONE-TIME PROMO
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>