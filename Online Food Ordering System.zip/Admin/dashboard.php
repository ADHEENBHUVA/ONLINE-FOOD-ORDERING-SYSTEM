<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Security Check: Redirect if not admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

include("admin_theme_loader.php");
$theme_res = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_res);

// Count function
function getCount($conn, $table)
{
    $sql = "SELECT COUNT(*) as total FROM $table";
    $result = $conn->query($sql);
    if ($result && $row = $result->fetch_assoc()) {
        return $row['total'];
    }
    return 0;
}

$customer_count = getCount($conn, "customers");
$category_count = getCount($conn, "categories");
$food_count = getCount($conn, "food_items");
$order_count = getCount($conn, "orders");

// Counting Active Orders
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing', 'Out for Delivery', 'In Transit')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// Revenue Calculation
$revenue = 0;
$revQuery = "SELECT SUM(total_amount) AS total FROM orders WHERE order_status='Delivered'";
$revResult = $conn->query($revQuery);
if ($revResult) {
    $revRow = $revResult->fetch_assoc();
    if ($revRow && $revRow['total'] != null) {
        $revenue = $revRow['total'];
    }
}

// Get count of pending withdrawals
$withdraw_count_res = $conn->query("SELECT COUNT(*) as total FROM rider_withdrawals WHERE status='Processing'");
$withdraw_count = $withdraw_count_res->fetch_assoc()['total'];

// Recent items
$customers = $conn->query("SELECT customer_id,name,email,phone,created_at FROM customers ORDER BY customer_id DESC LIMIT 10");
$delivery_persons = $conn->query("SELECT id,name,vehicle_type,vehicle_number,status FROM delivery_person ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: '<?php echo $theme['font_family'] ?? 'Plus Jakarta Sans'; ?>';
            background:
                <?php echo ($theme['mode'] == "dark") ? "#0f172a" : "#f8fafc"; ?>
            ;
            margin: 0;
        }

        /* 1. SPLASH SCREEN STYLES */
        #splash-screen {
            position: fixed;
            inset: 0;
            background: #0f172a;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: all 1s ease-in-out;
        }

        body.splash-active {
            overflow: hidden;
        }

        .splash-hidden {
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            transform: translateY(-20px);
        }

        /* 2. DASHBOARD STYLES */
        .sidebar-premium {
            background: #0f172a;
        }

        .glass-nav {
            background:
                <?php echo ($theme['mode'] == 'dark') ? 'rgba(15, 23, 42, 0.8)' : 'rgba(255, 255, 255, 0.8)'; ?>
            ;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .card-shadow {
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
        }

        .stat-card:hover .stat-icon {
            transform: scale(1.1) rotate(5deg);
        }

        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 10px;
        }
    </style>
</head>

<body class="flex min-h-screen splash-active">

    <div id="splash-screen"
        class="fixed inset-0 bg-[#0f172a] flex flex-col items-center justify-center z-[9999] transition-all duration-500 ease-in-out">
        <div id="splash-content" class="text-center transition-all duration-500 ease-out transform scale-150 opacity-0">

            <div class="relative inline-block">

                <img src="../images/logo.png" alt="Foodie's Heaven Logo"
                    class="w-48 h-48 mx-auto mb-4 object-contain relative z-10 filter drop-shadow-[0_0_20px_rgba(249,115,22,0.3)]">

                <h1 class="text-white text-5xl font-black italic tracking-tighter mb-2 relative z-10">
                    FOODIE'S <span class="text-orange-500">Heaven.</span>
                </h1>

                <div
                    class="absolute inset-0 m-auto w-64 h-64 bg-orange-500/25 blur-[100px] rounded-full z-0 animate-pulse">
                </div>
            </div>

            <div class="w-64 h-[2px] bg-white/5 mx-auto mt-4 overflow-hidden rounded-full relative">
                <div id="splash-bar" class="absolute inset-y-0 left-0 bg-orange-500 shadow-[0_0_10px_#f97316]"
                    style="width: 0%"></div>
            </div>

            <p
                class="text-orange-500/50 text-[8px] font-black uppercase tracking-[0.8em] mt-6 flex items-center justify-center gap-2">
                <span class="inline-block w-1 h-1 bg-orange-500 rounded-full animate-ping"></span>
                Authorized
            </p>
        </div>
    </div>

    <style>
        /* Prevent interaction */
        body.splash-active {
            overflow: hidden;
            height: 100vh;
        }

        /* Reveal content with a fade and slight lift */
        .splash-hidden {
            opacity: 0;
            visibility: hidden;
            transform: scale(1.05);
            filter: blur(10px);
            pointer-events: none;
        }

        /* Cinematic Entry */
        .splash-visible {
            opacity: 1 !important;
            transform: scale(1) !important;
        }
    </style>

    <style>
        /* Prevent interaction during splash */
        body.splash-active {
            overflow: hidden;
            height: 100vh;
        }

        /* Reveal content with a zoom-out and fade */
        .splash-hidden {
            opacity: 0;
            visibility: hidden;
            transform: scale(1.1);
            /* Cinematic zoom out effect */
            pointer-events: none;
        }

        /* Initial entry animation for logo */
        .splash-visible {
            opacity: 1 !important;
            transform: scale(1) !important;
        }
    </style>

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo"
                class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

        <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

            <a href="dashboard.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Dashboard</span>
                </div>
            </a>

            <a href="manage_food.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Manage Food</span>
                </div>
                <span
                    class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
            </a>

            <a href="manage_categories.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Categories</span>
                </div>
            </a>

            <a href="manage_promo.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Coupons</span>
                </div>
                <span
                    class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
            </a>

            <a href="manage_orders.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Active Orders</span>
                </div>
                <?php if ($active_orders_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
                        <?php echo $active_orders_count; ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="manage_customers.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Customer Base</span>
                </div>
            </a>
            <a href="manage_vip.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
                <div class="flex items-center gap-3">
                    <i class="fas fa-star w-5"></i>
                    <span class="font-semibold text-sm">VIP Members</span>
                </div>
            </a>

            <div class="my-4 border-t border-slate-800/50 mx-4"></div>
            <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

            <a href="admin_feedback.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Feedback</span>
                </div>
            </a>

            <a href="manage_delivery_person.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Fleet Status</span>
                </div>
                <span class="relative flex h-2 w-2">
                    <span
                        class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
            </a>

            <a href="admin_withdrawals.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Rider Payouts</span>
                </div>
                <?php if (isset($withdraw_count) && $withdraw_count > 0): ?>
                    <span
                        class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                        <?= $withdraw_count ?>
                    </span>
                <?php endif; ?>
            </a>

            <a href="sales_report.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Sales Analytics</span>
                </div>
            </a>

            <a href="delivery_settings.php"
                class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
                <div class="flex items-center gap-4">
                    <div
                        class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                        <i
                            class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
                    </div>
                    <div class="flex flex-col">
                        <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP
                            Customers</span>
                        <span
                            class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics
                            & Rules</span>
                    </div>
                </div>
                <i
                    class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

                <div
                    class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity">
                </div>
            </a>

            <a href="change_theme.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
                <div class="flex items-center gap-3">
                    <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                    <span class="font-semibold text-sm">Change Theme</span>
                </div>
                <span
                    class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
            </a>

            <a href="change_password_auth.php"
                class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
                <div
                    class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                </div>

                <div class="flex items-center gap-3 relative z-10">
                    <div
                        class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
                        <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
                    </div>

                    <div class="flex flex-col">
                        <span
                            class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access
                            Security</span>
                        <span
                            class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update
                            Master Key</span>
                    </div>
                </div>

                <div class="relative z-10 flex items-center">
                    <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]">
                    </div>
                    <i
                        class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
                </div>
            </a>
        </nav>

        <div class="p-6 border-t border-slate-800/50">
            <a href="logout.php"
                class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
                <i class="fas fa-power-off"></i>
                <span class="font-bold text-sm">Sign Out</span>
            </a>
        </div>
    </aside>

    <main class="flex-1 overflow-x-hidden">
        <header class="glass-nav sticky top-0 z-50 px-8 py-4 flex justify-between items-center">
            <div>
                <h1 class="text-xl font-800 text-slate-800 tracking-tighter uppercase italic">Control <span
                        class="text-orange-500">Center</span></h1>
                <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Live System Analytics</p>
            </div>
            <div class="flex items-center gap-4">

                <a href="admin_withdrawals.php"
                    class="relative bg-orange-50 text-orange-600 px-4 py-2 rounded-full border border-orange-200 hover:bg-orange-600 hover:text-white transition-all flex items-center gap-2 shadow-sm group">
                    <i class="fas fa-wallet transition-transform"></i>
                    <span class="text-[9px] font-black uppercase tracking-widest">Withdrawal Status</span>
                    <?php if ($withdraw_count > 0): ?>
                        <span
                            class="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[9px] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow-lg border-2 border-white animate-bounce">
                            <?= $withdraw_count ?>
                        </span>
                    <?php endif; ?>
                </a>

                <div class="flex items-center gap-2 bg-emerald-50 px-4 py-2 rounded-full border border-emerald-100">
                    <span class="relative flex h-2 w-2">
                        <span class="animate-ping absolute h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span class="text-[9px] font-black text-emerald-700 uppercase tracking-widest">Server
                        Operational</span>
                </div>
            </div>
        </header>

        <div class="p-8">
            <!-- Notifications Card -->
            <?php
            $admin_notif_q = $conn->query("SELECT * FROM notifications WHERE user_type='admin' AND is_read=0 ORDER BY created_at DESC LIMIT 20");
            if ($admin_notif_q->num_rows > 0):
            ?>
            <div class="mb-10 bg-orange-500 rounded-[2rem] p-8 shadow-xl shadow-orange-500/20 relative overflow-hidden group">
                <div class="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div class="relative z-10 flex items-center justify-between">
                    <div class="flex items-center gap-6">
                        <div class="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center text-white border border-white/20">
                            <i class="fas fa-bell text-xl animate-bounce"></i>
                        </div>
                        <div>
                            <h2 class="text-white text-2xl font-900 tracking-tighter uppercase italic">Recent System Activity</h2>
                            <p class="text-white/70 text-[10px] font-bold uppercase tracking-widest mt-1">Pending Actions Required</p>
                        </div>
                    </div>
                    <a href="../clear_notifications.php?type=admin" class="bg-white text-orange-600 px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest hover:scale-105 transition-all shadow-lg active:scale-95">Mark All Clear</a>
                </div>
                <div class="mt-8 space-y-3 max-h-[260px] overflow-y-auto custom-scrollbar pr-2">
                    <?php while($n = $admin_notif_q->fetch_assoc()): ?>
                    <a href="manage_orders.php" class="block bg-white/10 border border-white/10 p-4 rounded-2xl backdrop-blur-sm group/item hover:bg-white/20 transition-all cursor-pointer">
                        <div class="flex items-center justify-between w-full">
                            <div class="flex items-center gap-4">
                                <span class="w-2 h-2 bg-white rounded-full"></span>
                                <p class="text-white font-bold text-sm"><?= htmlspecialchars($n['message']) ?></p>
                            </div>
                            <span class="text-white/50 text-[10px] font-black uppercase tracking-widest"><?= date('h:i A', strtotime($n['created_at'])) ?></span>
                        </div>
                    </a>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                <div class="stat-card bg-white p-6 rounded-[2rem] card-shadow border border-white">
                    <div
                        class="stat-icon w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-xl mb-4 transition-transform">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Patrons</p>
                    <h3 class="text-3xl font-900 text-slate-800 tracking-tighter"><?= number_format($customer_count) ?>
                    </h3>
                </div>

                <div class="stat-card bg-white p-6 rounded-[2rem] card-shadow border border-white">
                    <div
                        class="stat-icon w-12 h-12 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center text-xl mb-4 transition-transform">
                        <i class="fas fa-bowl-hot"></i>
                    </div>
                    <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Total Orders</p>
                    <h3 class="text-3xl font-900 text-slate-800 tracking-tighter"><?= number_format($order_count) ?>
                    </h3>
                </div>

                <div class="stat-card bg-white p-6 rounded-[2rem] card-shadow border border-white">
                    <div
                        class="stat-icon w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-xl mb-4 transition-transform">
                        <i class="fas fa-utensils"></i>
                    </div>
                    <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Active Dishes</p>
                    <h3 class="text-3xl font-900 text-slate-800 tracking-tighter"><?= number_format($food_count) ?></h3>
                </div>

                <div class="stat-card bg-white p-6 rounded-[2rem] card-shadow border border-white">
                    <div
                        class="stat-icon w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center text-xl mb-4 transition-transform">
                        <i class="fas fa-tags"></i>
                    </div>
                    <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Categories</p>
                    <h3 class="text-3xl font-900 text-slate-800 tracking-tighter"><?= number_format($category_count) ?>
                    </h3>
                </div>
            </div>

            <div class="bg-slate-900 rounded-[2.5rem] p-10 mb-10 relative overflow-hidden text-white shadow-2xl">
                <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div>
                        <p class="text-orange-400 font-black text-[10px] uppercase tracking-[0.3em] mb-4">Total Revenue
                            Generated</p>
                        <h2 class="text-5xl font-900 tracking-tighter mb-2">&#8377;<?= number_format($revenue, 2) ?></h2>
                        <p class="text-slate-500 text-xs font-medium uppercase tracking-widest">Verified Delivered
                            Orders</p>
                    </div>
                    <a href="sales_report.php"
                        class="bg-white text-slate-900 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all shadow-xl">
                        View Analytics
                    </a>
                </div>
                <div class="absolute -right-20 -bottom-20 w-80 h-80 bg-orange-500/10 rounded-full blur-3xl"></div>
            </div>

            <div class="grid grid-cols-1 xl:grid-cols-2 gap-10">
                <div class="bg-white rounded-[2.5rem] card-shadow border border-white overflow-hidden">
                    <div class="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
                        <h2 class="font-900 text-slate-800 text-sm uppercase tracking-tighter">Recent Patron Registry
                        </h2>
                        <a href="manage_customers.php"
                            class="text-orange-600 text-[10px] font-black uppercase tracking-widest">View Database</a>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <tbody class="divide-y divide-slate-50">
                                <?php while ($row = $customers->fetch_assoc()): ?>
                                    <tr class="hover:bg-slate-50/80 transition group">
                                        <td class="px-8 py-5">
                                            <div class="flex items-center gap-4">
                                                <div
                                                    class="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 text-[10px] font-black group-hover:bg-orange-500 group-hover:text-white transition-all">
                                                    <?= strtoupper(substr($row['name'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <p class="font-bold text-slate-800 text-sm">
                                                        <?= htmlspecialchars($row['name']) ?></p>
                                                    <p
                                                        class="text-[10px] text-slate-400 font-bold uppercase tracking-tighter italic">
                                                        <?= htmlspecialchars($row['email']) ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <td
                                            class="px-8 py-5 text-right font-black text-[10px] text-slate-300 uppercase tracking-widest">
                                            <?= date('d/m/Y', strtotime($row['created_at'])) ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bg-white rounded-[2.5rem] card-shadow border border-white overflow-hidden">
                    <div class="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
                        <h2 class="font-900 text-slate-800 text-sm uppercase tracking-tighter">Logistics Monitor</h2>
                        <a href="manage_delivery_person.php"
                            class="bg-slate-900 text-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg"><i
                                class="fas fa-plus text-[10px]"></i></a>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <tbody class="divide-y divide-slate-50">
                                <?php while ($row = $delivery_persons->fetch_assoc()): ?>
                                    <tr class="hover:bg-slate-50/80 transition">
                                        <td class="px-8 py-5">
                                            <div class="font-bold text-slate-800 text-sm">
                                                <?= htmlspecialchars($row['name']) ?></div>
                                            <div
                                                class="text-[9px] text-slate-400 font-black uppercase tracking-widest italic">
                                                <?= htmlspecialchars($row['vehicle_type']) ?> •
                                                <?= htmlspecialchars($row['vehicle_number']) ?></div>
                                        </td>
                                        <td class="px-8 py-5 text-right">
                                            <span
                                                class="px-3 py-1 <?= ($row['status'] == "Active") ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-100 text-slate-400 border-slate-200'; ?> rounded-full text-[9px] font-black uppercase border">
                                                <?= $row['status'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const splash = document.getElementById('splash-screen');
            const content = document.getElementById('splash-content');
            const bar = document.getElementById('splash-bar');

            // 1. Instantly show logo with scale-down effect
            requestAnimationFrame(() => {
                content.classList.add('splash-visible');
            });

            // 2. Rapid Progress Bar (Fills in 500ms)
            setTimeout(() => {
                bar.style.transition = "all 500ms cubic-bezier(0.65, 0, 0.35, 1)";
                bar.style.width = '100%';
            }, 50);

            // 3. Initiate Exit after 700ms (Very Fast)
            setTimeout(function () {
                splash.classList.add('splash-hidden');
                document.body.classList.remove('splash-active');

                // Cleanup DOM
                setTimeout(() => {
                    splash.remove();
                }, 600);

            }, 700);
        });
    </script>
</body>

</html>