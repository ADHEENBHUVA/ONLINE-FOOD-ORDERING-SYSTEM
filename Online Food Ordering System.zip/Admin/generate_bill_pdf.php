<?php
session_set_cookie_params(86400 * 30);
session_start();

if (!isset($_SESSION['admin_id'])) {
    exit("Access Denied. Admin only.");
}
// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    exit("Session Timeout. Please login again.");
}
$_SESSION['admin_last_activity'] = time();

$conn = new mysqli("localhost", "root", "", "online_food");
if ($conn->connect_error) die("Connection Failed: " . $conn->connect_error);

if (!isset($_GET['order_id'])) {
    exit("Invalid Request: Order ID missing.");
}

$order_id = $conn->real_escape_string($_GET['order_id']);

// Get Order Details
$order_q = $conn->query("SELECT o.*, c.name as customer_name, c.email, c.phone as customer_phone
                         FROM orders o
                         LEFT JOIN customers c ON o.customer_id = c.customer_id
                         WHERE o.order_id = '$order_id'");
if ($order_q->num_rows == 0) {
    exit("Order not found.");
}
$order = $order_q->fetch_assoc();

// Must not be Cancelled or Pending for an official receipt (if strict rules from requirement)
// But we'll just allow generation if the button is there. Actually, the button logic handles the visibility.

// Get Order Items
$items_q = $conn->query("SELECT i.quantity, i.price, f.food_name, c.category_name as category
                         FROM order_items i
                         JOIN food_items f ON i.food_id = f.food_id
                         LEFT JOIN categories c ON f.category_id = c.category_id
                         WHERE i.order_id = '$order_id'");
$items = [];
while ($row = $items_q->fetch_assoc()) {
    $items[] = $row;
}

$subtotal = $order['total_amount'];
$tax = $subtotal * 0.05; // Dummy 5% tax reverse calculation for display, or just display raw subtotal = total - tax
$base_total = $subtotal - $tax;

$invoice_no = "INV-" . $order_id . "-" . date('Ymd');
$readable_date = date("d M Y, h:i A", strtotime($order['order_date']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer_Bill_<?= $invoice_no ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- html2pdf.js for Document Engine -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&family=Space+Mono:wght@400;700&display=swap');

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #323639;
            margin: 0;
            padding: 40px 0;
        }

        .a4-page {
            width: 210mm;
            height: 297mm;
            overflow: hidden;
            background: #ffffff;
            margin: 0 auto;
            position: relative;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
        }

        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-30deg);
            font-size: 140px;
            font-weight: 900;
            color: rgba(249, 115, 22, 0.02); /* Orange faint watermark */
            white-space: nowrap;
            z-index: 0;
            pointer-events: none;
            text-transform: uppercase;
        }

        .receipt-content { position: relative; z-index: 10; padding: 25mm 20mm; display: flex; flex-direction: column; flex-grow: 1; box-sizing: border-box; }

        /* Premium Table */
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { background: #f8fafc; color: #64748b; font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.1em; padding: 12px 10px; border-bottom: 2px solid #e2e8f0; text-align: left;}
        td { padding: 15px 10px; font-size: 12px; color: #1e293b; font-weight: 600; border-bottom: 1px dashed #cbd5e1; }
        .mono { font-family: 'Space Mono', monospace; }

        .loading-screen {
            position: fixed; inset: 0; background: #0f172a; z-index: 9999;
            display: flex; flex-direction: column; align-items: center; justify-content: center; color: white;
        }
    </style>
</head>
<body>

    <div id="loading" class="loading-screen">
        <i class="fas fa-spinner fa-pulse text-6xl text-orange-500 mb-6"></i>
        <h2 class="text-3xl font-black uppercase tracking-[0.2em] mb-2">Generating Bill</h2>
        <p class="text-sm font-bold text-slate-400 tracking-widest text-center max-w-sm">Please wait while we render the secure customer receipt in high resolution...</p>
    </div>

    <!-- The A4 Receipt -->
    <div class="a4-page">
        <!-- Top Colored Edge -->
        <div class="h-3 w-full bg-gradient-to-r from-orange-400 via-orange-500 to-rose-500 shrink-0"></div>
        <div class="watermark">PAID RECEIPT</div>

        <div class="receipt-content">

            <!-- Restaurant Header Info -->
            <div class="flex justify-between items-start border-b-2 border-slate-900 pb-8 mb-8 shrink-0">
                <div class="flex gap-5 items-center">
                    <div class="w-20 h-20 rounded-2xl bg-slate-900 text-orange-500 flex items-center justify-center font-black text-3xl shadow-lg border border-slate-800 shrink-0">
                        <i class="fas fa-utensils"></i>
                    </div>
                    <div>
                        <h1 class="text-3xl font-900 tracking-tighter text-slate-900 uppercase italic">Foodie's <span class="text-orange-500">Heaven</span></h1>
                        <p class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mt-1">Premium Dining & Delivery Log</p>
                        <div class="flex gap-3 text-[10px] text-slate-500 font-bold mt-2">
                            <span><i class="fas fa-map-marker-alt text-orange-500 mr-1"></i> 123 Gourmet Avenue, CityCenter</span>
                            <span><i class="fas fa-phone text-orange-500 mr-1"></i> +1 800 555 FOOD</span>
                        </div>
                    </div>
                </div>
                <div class="text-right">
                    <h2 class="text-3xl font-900 tracking-tighter text-orange-500 uppercase">INVOICE</h2>
                    <p class="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">Tax Document / Receipt</p>
                </div>
            </div>

            <!-- Customer & Order Meta -->
            <div class="grid grid-cols-2 gap-10 mb-8 border border-slate-200 rounded-2xl p-6 bg-slate-50/50 shadow-sm relative overflow-hidden shrink-0">
                <div class="absolute right-0 top-0 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl -mr-16 -mt-16"></div>

                <div>
                    <h3 class="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2 border-b border-slate-200 pb-2">Billed To Customer</h3>
                    <p class="text-sm font-900 text-slate-800 uppercase"><?= htmlspecialchars($order['customer_name']) ?></p>
                    <p class="text-[10px] font-bold text-slate-500 mt-1"><i class="fas fa-phone-alt opacity-50 mr-1"></i> <?= htmlspecialchars($order['customer_phone']) ?></p>
                    <p class="text-[10px] font-bold text-slate-500 mt-0.5"><i class="fas fa-envelope-open-text opacity-50 mr-1"></i> <?= htmlspecialchars($order['email']) ?></p>
                    <div class="mt-2 text-[10px] font-bold text-slate-500 leading-snug"><i class="fas fa-map-pin opacity-50 mr-1"></i> <?= htmlspecialchars($order['address']) ?></div>
                </div>

                <div>
                    <h3 class="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2 border-b border-slate-200 pb-2">Order Information</h3>
                    <div class="grid grid-cols-2 gap-y-3 font-bold text-[10px]">
                        <div class="text-slate-500 tracking-widest uppercase">Invoice Number</div>
                        <div class="text-slate-900 text-right"><?= htmlspecialchars($invoice_no) ?></div>

                        <div class="text-slate-500 tracking-widest uppercase">Order Date & Time</div>
                        <div class="text-slate-900 text-right"><?= $readable_date ?></div>

                        <div class="text-slate-500 tracking-widest uppercase">Payment Method</div>
                        <div class="text-right text-emerald-600 uppercase tracking-widest px-2 py-0.5 bg-emerald-50 rounded-lg inline-block ml-auto"><i class="fas px-1 fa-check-circle"></i> <?= htmlspecialchars($order['payment_method']) ?></div>
                    </div>
                </div>
            </div>

            <!-- Items Table -->
            <div class="flex-1">
                <table>
                    <thead>
                        <tr>
                            <th class="w-10 text-center">Qty</th>
                            <th>Description</th>
                            <th class="text-right w-24">Unit Price</th>
                            <th class="text-right w-28">Line Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($items as $i): ?>
                        <tr>
                            <td class="text-center">
                                <div class="bg-slate-100 text-slate-800 rounded font-900 text-[10px] py-1 px-2 inline-block"><?= $i['quantity'] ?>x</div>
                            </td>
                            <td>
                                <div class="font-800 text-slate-800 tracking-tight text-sm uppercase"><?= htmlspecialchars($i['food_name']) ?></div>
                                <div class="text-[9px] font-bold tracking-widest text-orange-500 uppercase mt-0.5"><?= htmlspecialchars($i['category']) ?></div>
                            </td>
                            <td class="text-right mono text-slate-500 text-[11px]">&#8377;<?= number_format($i['price'], 2) ?></td>
                            <td class="text-right mono text-[13px] text-slate-900 font-900">&#8377;<?= number_format($i['price'] * $i['quantity'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Summary Totals -->
            <div class="flex justify-end mt-4 mb-10">
                <div class="w-1/2 rounded-2xl bg-slate-900 text-white p-6 shadow-2xl relative overflow-hidden">
                    <div class="absolute -right-10 -bottom-10 w-32 h-32 bg-orange-500/20 rounded-full blur-3xl"></div>

                    <div class="flex justify-between text-[11px] font-bold text-slate-400 mb-2">
                        <span class="uppercase tracking-widest">Base Amount</span>
                        <span class="mono">&#8377;<?= number_format($base_total, 2) ?></span>
                    </div>
                    <div class="flex justify-between text-[11px] font-bold text-slate-400 mb-4 pb-4 border-b border-slate-700/50">
                        <span class="uppercase tracking-widest">Estimated Taxes (5%)</span>
                        <span class="mono">&#8377;<?= number_format($tax, 2) ?></span>
                    </div>
                    <div class="flex justify-between items-center text-orange-400">
                        <span class="text-[10px] uppercase tracking-[0.2em] font-black">Net Total Billed</span>
                        <span class="text-3xl font-900 tracking-tighter mono text-white">&#8377;<?= number_format($subtotal, 2) ?></span>
                    </div>
                </div>
            </div>

            <!-- Footer Signatures -->
            <div class="mt-auto grid grid-cols-2 gap-10 pt-6 border-t-2 border-dashed border-slate-200 shrink-0">
                <div>
                    <h4 class="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-2">Thank you for dining with us!</h4>
                    <p class="text-[8px] font-bold text-slate-400 leading-relaxed uppercase">This is a highly-secure electronically generated invoice. It acts as legal proof of transaction with Foodie's Heaven. VAT / TIN: 000-123-ABC-789. For support, contact admin@foodiesheaven.com.</p>
                </div>
                <div class="text-right flex flex-col items-end">
                    <div class="h-12 w-48 border-b border-slate-400 mb-1 relative flex items-end justify-center pb-2">
                        <!-- Space left blank intentionally for physical signature -->
                    </div>
                    <p class="text-[8px] font-black uppercase tracking-[0.2em] text-slate-500">Authorized Signatory</p>
                </div>
            </div>

        </div>
    </div>

    <script>
        window.onload = function() {
            var element = document.querySelector('.a4-page');
            var opt = {
                margin:       [0, 0, 0, 0],
                filename:     '<?= $invoice_no ?>.pdf',
                image:        { type: 'jpeg', quality: 1 },
                html2canvas:  { scale: 2, useCORS: true, backgroundColor: '#ffffff' },
                jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
            };

            setTimeout(() => {
                html2pdf().set(opt).from(element).save().then(function() {
                    document.getElementById('loading').style.display = 'none';
                    // Auto close the tab after downloading
                    setTimeout(() => { window.close(); }, 1000);
                });
            }, 500);
        };
    </script>
</body>
</html>
