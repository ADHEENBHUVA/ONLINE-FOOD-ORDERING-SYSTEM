<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Security Check
if (!isset($_SESSION['admin_id'])) exit("Denied");
// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    exit("Session Timeout. Please login again.");
}
$_SESSION['admin_last_activity'] = time();

// Set headers to force download the Excel file
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Detailed_Feedback_Report_".date('Y-m-d').".xls");
header("Pragma: no-cache");
header("Expires: 0");

// Fetch Feedback with Customers, Orders, and Product Details
// We use GROUP_CONCAT to list all food names bought in that specific order
$query = "SELECT
            f.feedback_id,
            f.rating,
            f.message,
            f.feedback_date,
            c.customer_id,
            c.name AS customer_name,
            o.order_id,
            GROUP_CONCAT(fi.food_name SEPARATOR '\n') AS products_bought
          FROM feedback f
          JOIN customers c ON f.customer_id = c.customer_id
          JOIN orders o ON f.order_id = o.order_id
          JOIN order_items oi ON o.order_id = oi.order_id
          JOIN food_items fi ON oi.food_id = fi.food_id
          GROUP BY f.feedback_id
          ORDER BY f.feedback_id DESC";

$result = $conn->query($query);

echo '<table border="1">';
echo '<thead>
        <tr>
            <th style="background-color: #f97316; color: white;">Feedback ID</th>
            <th style="background-color: #f97316; color: white;">Order ID</th>
            <th style="background-color: #f97316; color: white;">Customer ID</th>
            <th style="background-color: #f97316; color: white;">Customer Name</th>
            <th style="background-color: #f97316; color: white;">Items Purchased</th>
            <th style="background-color: #f97316; color: white;">Rating</th>
            <th style="background-color: #f97316; color: white;">Customer Message</th>
            <th style="background-color: #f97316; color: white;">Submitted On</th>
        </tr>
      </thead>';

echo '<tbody>';
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['feedback_id'] . '</td>';
        echo '<td>ORD-' . $row['order_id'] . '</td>';
        echo '<td>CUST-' . $row['customer_id'] . '</td>';
        echo '<td>' . htmlspecialchars($row['customer_name']) . '</td>';
        echo '<td>' . nl2br(htmlspecialchars($row['products_bought'] ?? '')) . '</td>';
        echo '<td>' . $row['rating'] . ' / 5</td>';
        echo '<td>' . htmlspecialchars($row['message']) . '</td>';
        echo '<td>' . date("d/m/Y h:i A", strtotime($row['feedback_date'])) . '</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="8" style="text-align:center;">No feedback records found.</td></tr>';
}
echo '</tbody>';
echo '</table>';
?>