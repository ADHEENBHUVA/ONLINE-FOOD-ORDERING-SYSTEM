<?php
session_set_cookie_params(86400 * 30);
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

$conn = new mysqli("localhost","root","","online_food");
if ($conn->connect_error) die("Connection Failed: " . $conn->connect_error);

include("admin_theme_loader.php");
$theme_query = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_query);

// 1. DYNAMIC DATE FILTER LOGIC
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$filter_type = $_GET['filter_preset'] ?? 'custom';
$grouping = $_GET['grouping'] ?? 'daily';

if ($filter_type == 'today') {
    $start_date = $end_date = date('Y-m-d');
} elseif ($filter_type == 'week') {
    $start_date = date('Y-m-d', strtotime('-7 days'));
    $end_date = date('Y-m-d');
} elseif ($filter_type == 'month') {
    $start_date = date('Y-m-01');
    $end_date = date('Y-m-t');
} elseif ($filter_type == 'year') {
    $start_date = date('Y-01-01');
    $end_date = date('Y-12-31');
}

// 2. FETCH SUMMARY STATS
$total_revenue = $conn->query("SELECT SUM(total_amount) AS revenue FROM orders WHERE order_status='Delivered' AND order_date BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'")->fetch_assoc()['revenue'] ?? 0;
$total_orders = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_date BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'")->fetch_assoc()['total'];
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// 3. DAILY SALES FOR CHART (Corrected logic for trend)
if ($grouping == 'monthly') {
    $group_sql = "DATE_FORMAT(order_date, '%Y-%m')";
    $label_format = "M Y";
} elseif ($grouping == 'yearly') {
    $group_sql = "YEAR(order_date)";
    $label_format = "Y";
} else {
    $group_sql = "DATE(order_date)";
    $label_format = "d/m";
}

$daily_sales = $conn->query("
    SELECT $group_sql as date, SUM(total_amount) as total
    FROM orders
    WHERE order_status='Delivered' AND order_date BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'
    GROUP BY $group_sql
    ORDER BY $group_sql ASC
");

$daily_sales_labels = [];
$daily_sales_data = [];
while($row = $daily_sales->fetch_assoc()){
    if ($grouping == 'monthly') {
        $formatted_date = date($label_format, strtotime($row['date'] . "-01"));
    } elseif ($grouping == 'yearly') {
        $formatted_date = $row['date'];
    } else {
        $formatted_date = date($label_format, strtotime($row['date']));
    }
    $daily_sales_labels[] = $formatted_date;
    $daily_sales_data[] = (float)$row['total'];
}

// ADD THE COUNTING CODE HERE (Right after connection)
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

// 4. DETAILED ORDER LIST (Includes Customer Info and Product List)
if ($grouping == 'daily') {
    $orders_query = "
        SELECT
            o.order_id, o.customer_id, o.total_amount, o.payment_method, o.order_status, o.order_date,
            c.name AS customer_name,
            GROUP_CONCAT(CONCAT(fi.food_name, ' (x', oi.quantity, ')') SEPARATOR '||') AS items_list
        FROM orders o
        LEFT JOIN customers c ON o.customer_id = c.customer_id
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        LEFT JOIN food_items fi ON oi.food_id = fi.food_id
        WHERE o.order_date BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'
        GROUP BY o.order_id
        ORDER BY o.order_date ASC
    ";
} else {
    $orders_query = "
        SELECT
            $group_sql as period,
            COUNT(DISTINCT o.order_id) as total_orders,
            COUNT(oi.food_id) as items_sold,
            SUM(o.total_amount) as total_amount
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.order_status='Delivered' AND o.order_date BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'
        GROUP BY $group_sql
        ORDER BY $group_sql ASC
    ";
}
$orders = $conn->query($orders_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Analytics | Foodie's Heaven Executive</title>
    <?php include("admin_theme_loader.php"); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <style>
        :root { --primary: #f97316; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: <?= ($theme['mode']=="dark") ? "#0f172a" : "#f8fafc"; ?>; color: <?= ($theme['mode']=="dark") ? "#f1f5f9" : "#1e293b"; ?>; margin: 0; height: 100vh; overflow: hidden; }
        .sidebar-premium { background: #0f172a; width: 288px; height: 100vh; flex-shrink: 0; }
        .nav-link { transition: all 0.2s ease; color: #94a3b8; padding: 12px 16px; border-radius: 12px; display: flex; align-items: center; gap: 12px; }
        .nav-link:hover { color: #fff; background: rgba(255,255,255,0.05); }
        .nav-link.active { background: var(--primary); color: white !important; }
        .main-content { flex: 1; display: flex; flex-direction: column; height: 100vh; }
        .glass-nav { background: <?= ($theme['mode'] == 'dark') ? 'rgba(15, 23, 42, 0.8)' : 'rgba(255, 255, 255, 0.8)'; ?>; backdrop-filter: blur(12px); border-bottom: 1px solid rgba(0,0,0,0.05); height: 72px; flex-shrink: 0; display: flex; align-items: center; padding: 0 2rem; }
        .scrollable-area { flex: 1; overflow-y: auto; padding: 2rem; }
        .custom-card { background: <?= ($theme['mode']=="dark") ? "#1e293b" : "#ffffff"; ?>; border-radius: 1.5rem; border: 1px solid <?= ($theme['mode']=="dark") ? "rgba(255,255,255,0.05)" : "#e2e8f0"; ?>; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>
<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo" class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

    <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

        <a href="dashboard.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Dashboard</span>
            </div>
        </a>

        <a href="manage_food.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Manage Food</span>
            </div>
            <span class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
        </a>

        <a href="manage_categories.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Categories</span>
            </div>
        </a>

        <a href="manage_promo.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Coupons</span>
            </div>
            <span class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
        </a>

        <a href="manage_orders.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
    <div class="flex items-center gap-3">
        <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
        <span class="font-semibold text-sm">Active Orders</span>
    </div>
    <?php if($active_orders_count > 0): ?>
        <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
            <?php echo $active_orders_count; ?>
        </span>
    <?php endif; ?>
</a>

        <a href="manage_customers.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Customer Base</span>
            </div>
        </a>
        <a href="manage_vip.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
            <div class="flex items-center gap-3">
                <i class="fas fa-star w-5"></i>
                <span class="font-semibold text-sm">VIP Members</span>
            </div>
        </a>

        <div class="my-4 border-t border-slate-800/50 mx-4"></div>
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

        <a href="admin_feedback.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Feedback</span>
            </div>
        </a>

        <a href="manage_delivery_person.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Fleet Status</span>
            </div>
            <span class="relative flex h-2 w-2">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
        </a>

        <a href="admin_withdrawals.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Rider Payouts</span>
            </div>
            <?php if(isset($withdraw_count) && $withdraw_count > 0): ?>
            <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                <?= $withdraw_count ?>
            </span>
            <?php endif; ?>
        </a>

        <a href="sales_report.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Sales Analytics</span>
            </div>
        </a>

        <a href="delivery_settings.php" class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
        <div class="flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                <i class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
            </div>
            <div class="flex flex-col">
                <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP Customers</span>
                <span class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics & Rules</span>
            </div>
        </div>
        <i class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

        <div class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </a>

        <a href="change_theme.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Change Theme</span>
            </div>
            <span class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
        </a>

        <a href="change_password_auth.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

    <div class="flex items-center gap-3 relative z-10">
        <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
            <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
        </div>

        <div class="flex flex-col">
            <span class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access Security</span>
            <span class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update Master Key</span>
        </div>
    </div>

    <div class="relative z-10 flex items-center">
        <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]"></div>
        <i class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
    </div>
</a>
    </nav>

    <div class="p-6 border-t border-slate-800/50">
        <a href="logout.php" class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
            <i class="fas fa-power-off"></i>
            <span class="font-bold text-sm">Sign Out</span>
        </a>
    </div>
</aside>

    <div class="main-content">
        <header class="glass-nav justify-between z-50">
            <h1 class="text-xl font-800 uppercase italic tracking-tighter">Business Intelligence</h1>
            <div class="h-10 w-10 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center font-bold text-slate-600 shadow-sm text-sm">AD</div>
        </header>

        <div class="scrollable-area custom-scrollbar">

            <form method="GET" class="custom-card p-6 mb-8 flex flex-wrap items-end gap-4 shadow-xl shadow-slate-200/50">
                <div class="space-y-1">
                    <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Predefined Range</label>
                    <select name="filter_preset" onchange="this.form.submit()" class="block w-48 p-3 rounded-xl border bg-slate-50 text-sm font-bold outline-none focus:ring-2 focus:ring-orange-500">
                        <option value="custom" <?= $filter_type == 'custom' ? 'selected' : '' ?>>Custom Dates</option>
                        <option value="today" <?= $filter_type == 'today' ? 'selected' : '' ?>>Today</option>
                        <option value="week" <?= $filter_type == 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                        <option value="month" <?= $filter_type == 'month' ? 'selected' : '' ?>>This Month</option>
                        <option value="year" <?= $filter_type == 'year' ? 'selected' : '' ?>>This Year</option>
                    </select>
                </div>
                <div class="space-y-1">
                    <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Start Date</label>
                    <input type="text" name="start_date" value="<?= $start_date ?>" class="flatpickr block p-3 rounded-xl border bg-slate-50 text-sm font-bold min-w-[140px]">
                </div>
                <div class="space-y-1">
                    <label class="text-[10px] font-black uppercase text-slate-400 tracking-widest">End Date</label>
                    <input type="text" name="end_date" value="<?= $end_date ?>" class="flatpickr block p-3 rounded-xl border bg-slate-50 text-sm font-bold min-w-[140px]">
                </div>
                <button type="submit" class="bg-orange-500 text-white px-8 py-3.5 rounded-xl font-black uppercase text-xs tracking-widest hover:bg-orange-600 transition shadow-lg shadow-orange-200">
                    Apply Filter
                </button>
            </form>

            <div class="flex flex-col md:flex-row gap-4 mb-8">
                <a href="?start_date=<?= $start_date ?>&end_date=<?= $end_date ?>&filter_preset=<?= $filter_type ?>&grouping=daily" class="flex-1 text-center py-3 rounded-xl font-black uppercase tracking-widest text-xs transition <?= $grouping == 'daily' ? 'bg-orange-500 text-white shadow-lg' : 'bg-slate-200 text-slate-500 hover:bg-slate-300' ?>">Daily Ledger</a>
                <a href="?start_date=<?= $start_date ?>&end_date=<?= $end_date ?>&filter_preset=<?= $filter_type ?>&grouping=monthly" class="flex-1 text-center py-3 rounded-xl font-black uppercase tracking-widest text-xs transition <?= $grouping == 'monthly' ? 'bg-orange-500 text-white shadow-lg' : 'bg-slate-200 text-slate-500 hover:bg-slate-300' ?>">Month-Wise Report</a>
                <a href="?start_date=<?= $start_date ?>&end_date=<?= $end_date ?>&filter_preset=<?= $filter_type ?>&grouping=yearly" class="flex-1 text-center py-3 rounded-xl font-black uppercase tracking-widest text-xs transition <?= $grouping == 'yearly' ? 'bg-orange-500 text-white shadow-lg' : 'bg-slate-200 text-slate-500 hover:bg-slate-300' ?>">Year-Wise Report</a>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div class="custom-card p-8 bg-indigo-600 border-none shadow-2xl text-Black relative overflow-hidden">
                    <div class="relative z-10">
                        <p class="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Filtered Revenue</p>
                        <h3 class="text-3xl font-900 tracking-tighter">&#8377;<?= number_format($total_revenue,2); ?></h3>
                    </div>
                </div>
                <div class="custom-card p-8 shadow-sm">
                    <p class="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Volume</p>
                    <h3 class="text-3xl font-900 tracking-tighter"><?= number_format($total_orders); ?> <span class="text-xs font-bold text-slate-300">Orders</span></h3>
                </div>
                <div class="custom-card p-8 shadow-sm">
                    <p class="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Avg Ticket</p>
                    <h3 class="text-3xl font-900 tracking-tighter">&#8377;<?= ($total_orders > 0) ? number_format($total_revenue/$total_orders, 2) : 0; ?></h3>
                </div>
            </div>

            <div class="custom-card p-8 mb-8 shadow-xl shadow-slate-200/50">
                <div class="flex justify-between items-center mb-10">
                    <div>
                        <h2 class="text-lg font-900 uppercase italic tracking-tighter">Revenue Trajectory</h2>
                        <p class="text-[10px] text-slate-400 font-bold uppercase">Performance visualization for the selected period</p>
                    </div>
                    <div class="flex items-center gap-2">
                         <span class="w-3 h-3 rounded-full bg-indigo-500"></span>
                         <span class="text-[10px] font-black uppercase text-slate-500">Net Sales</span>
                    </div>
                </div>
                <div class="h-[350px] w-full">
                    <canvas id="salesChart"></canvas>
                </div>
            </div>

            <div class="custom-card overflow-hidden shadow-xl shadow-slate-200/50 mb-10">
                <div class="p-8 border-b border-inherit bg-slate-500/5 flex justify-between items-center">
                    <h2 class="text-lg font-900 uppercase italic tracking-tighter">Detailed Sales Ledger</h2>
                    <div class="flex gap-2">
                        <button onclick="exportToPDFStyled()" class="bg-rose-500 hover:bg-rose-600 text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-rose-500/20 transition-all">
                            <i class="fa fa-file-pdf text-lg"></i> PDF
                        </button>
                        <button onclick="exportToExcelStyled()" class="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-emerald-500/20 transition-all">
                            <i class="fa fa-file-excel text-lg"></i> EXCEL
                        </button>
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse" id="salesTable">
                        <thead>
                            <tr class="text-[11px] font-black uppercase tracking-widest opacity-40 border-b bg-slate-50/50" id="tableHeaderRow">
                                <?php if($grouping == 'daily'): ?>
                                <th class="px-8 py-4">Ref ID</th>
                                <th class="px-8 py-4">Customer (UID)</th>
                                <th class="px-8 py-4">Items Bought</th>
                                <th class="px-8 py-4">Gross Amt</th>
                                <th class="px-8 py-4">Status</th>
                                <th class="px-8 py-4">Date</th>
                                <?php else: ?>
                                <th class="px-8 py-4">Period</th>
                                <th class="px-8 py-4">Total Orders</th>
                                <th class="px-8 py-4">Items Sold</th>
                                <th class="px-8 py-4">Gross Amt</th>
                                <th class="px-8 py-4">Avg Ticket</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-inherit">
                            <?php if($orders->num_rows > 0): while($row = $orders->fetch_assoc()): ?>
                            <tr class="hover:bg-slate-500/5 transition-colors">
                            <?php if($grouping == 'daily'): ?>
                                <td class="px-8 py-6 font-mono text-xs text-orange-500 font-bold">ORD-<?= $row['order_id']; ?></td>
                                <td class="px-8 py-6">
                                    <div class="text-sm font-extrabold text-slate-700"><?= htmlspecialchars($row['customer_name'] ?? 'Guest'); ?></div>
                                    <div class="text-[10px] opacity-50 font-bold">ID: CUST-<?= $row['customer_id']; ?></div>
                                </td>
                                <td class="px-8 py-6">
                                    <div class="text-xs font-medium text-slate-500 max-w-[220px]">
                                        <?php 
                                            if (!empty($row['items_list'])) {
                                                $items = explode('||', $row['items_list']);
                                                foreach($items as $i) {
                                                    echo '<div class="mb-0.5 truncate" title="'.htmlspecialchars($i).'">• ' . htmlspecialchars($i) . '</div>';
                                                }
                                            } else {
                                                echo '<span class="italic opacity-50">No Items</span>';
                                            }
                                        ?>
                                    </div>
                                </td>
                                <td class="px-8 py-6 font-900 text-slate-800">&#8377;<?= number_format($row['total_amount'],2); ?></td>
                                <td class="px-8 py-6">
                                    <span class="px-3 py-1 rounded-lg text-[9px] font-black uppercase border <?= ($row['order_status']=='Delivered') ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100' ?>"><?= $row['order_status'] ?></span>
                                </td>
                                <td class="px-8 py-6 text-xs font-bold opacity-40"><?= date("d/m/Y h:i A",strtotime($row['order_date'])); ?></td>
                            <?php else:
                                if ($grouping == 'monthly') {
                                    $period_label = date('M Y', strtotime($row['period'] . "-01"));
                                } else {
                                    $period_label = $row['period'];
                                }
                                $avg_ticket = ($row['total_orders'] > 0) ? ($row['total_amount'] / $row['total_orders']) : 0;
                            ?>
                                <td class="px-8 py-6 font-900 text-slate-800"><?= $period_label ?></td>
                                <td class="px-8 py-6 font-bold text-slate-600"><?= $row['total_orders'] ?> Orders</td>
                                <td class="px-8 py-6 font-bold text-slate-600"><?= $row['items_sold'] ?? 0 ?> Items</td>
                                <td class="px-8 py-6 font-900 text-emerald-600">&#8377;<?= number_format($row['total_amount'],2) ?></td>
                                <td class="px-8 py-6 font-bold text-slate-500">&#8377;<?= number_format($avg_ticket, 2) ?></td>
                            <?php endif; ?>
                            </tr>
                            <?php endwhile; else: ?>
                                <tr><td colspan="6" class="p-20 text-center opacity-30 italic font-bold">No transactions recorded for this range.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // 1. ATTRACTIVE CHART LOGIC
        const ctx = document.getElementById('salesChart').getContext('2d');
        const chartGradient = ctx.createLinearGradient(0, 0, 0, 400);
        chartGradient.addColorStop(0, 'rgba(79, 70, 229, 0.4)');
        chartGradient.addColorStop(1, 'rgba(79, 70, 229, 0)');

        const chartType = '<?= ($grouping == "daily") ? "line" : "bar" ?>';

        new Chart(ctx, {
            type: chartType,
            data: {
                labels: <?= json_encode($daily_sales_labels); ?>,
                datasets: [{
                    label: 'Revenue Trend',
                    data: <?= json_encode($daily_sales_data); ?>,
                    borderColor: '#4f46e5',
                    borderWidth: chartType === 'bar' ? 0 : 4,
                    backgroundColor: chartType === 'bar' ? 'rgba(79, 70, 229, 0.8)' : chartGradient,
                    borderRadius: chartType === 'bar' ? 6 : 0,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#4f46e5',
                    pointBorderWidth: 3,
                    pointRadius: 6,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10, weight: 'bold' } } },
                    y: {
                        beginAtZero: true,
                        grid: { borderDash: [5, 5], color: 'rgba(0,0,0,0.05)' },
                        ticks: { callback: value => value.toLocaleString() }
                    }
                }
            }
        });

        // 2. PDF EXPORT WITH STYLING
        function exportToPDFStyled() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('l', 'pt', 'a4');

            // Draw Orange Header Block
            doc.setFillColor(249, 115, 22); // Orange
            doc.rect(0, 0, 900, 80, 'F');

            doc.setFont("helvetica", "bold");
            doc.setFontSize(24);
            doc.setTextColor(255, 255, 255);
            doc.text("FOODIE'S HEAVEN EXECUTIVE - SALES INTELLIGENCE", 40, 45);

            doc.setFontSize(10);
            doc.setFontSize(10);
            const formattedStart = "<?= date('d/m/Y', strtotime($start_date)) ?>";
            const formattedEnd = "<?= date('d/m/Y', strtotime($end_date)) ?>";
            doc.text("Timeline: " + formattedStart + " to " + formattedEnd + "  |  GENERATED ON: " + new Date().toLocaleString(), 40, 75);

            const columns = Array.from(document.querySelectorAll('#tableHeaderRow th')).map(th => th.innerText);
            const rows = [];

            document.querySelectorAll("#salesTable tbody tr").forEach(tr => {
                if(tr.cells.length > 1) {
                    const rowData = Array.from(tr.cells).map(cell => {
                        let txt = cell.innerText.trim();
                        // jsPDF Helvetica does not support the Rupee symbol, it renders as '
                        // Therefore we replace it instantly with Rs. for the PDF display safely
                        return txt.replace(/₹/g, 'Rs. ');
                    });
                    rows.push(rowData);
                }
            });

            doc.autoTable({
                rowPageBreak: 'avoid',
                head: [columns],
                body: rows,
                startY: 100,
                theme: 'striped',
                headStyles: { fillColor: [30, 41, 59], fontStyle: 'bold', font: 'helvetica' },
                styles: { font: 'helvetica', fontSize: 9, cellPadding: 6, overflow: 'linebreak' },
                columnStyles: { 2: { cellWidth: 200 } }
            });
            doc.save("Sales_Intelligence_Report.pdf");
        }

        // 3. EXCEL EXPORT WITH STYLING
        async function exportToExcelStyled() {
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Sales Analytics');

            // Styled Header Row
            const titleRow = worksheet.addRow(["FOODIE'S HEAVEN EXECUTIVE - SALES INTELLIGENCE"]);
            titleRow.font = { name: 'Arial', size: 16, bold: true, color: { argb: 'FFFFFFFF' } };
            titleRow.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF97316' } }; // Orange
            worksheet.mergeCells('A1:F1');
            titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
            titleRow.height = 30;

            // Timeline Row (Left Aligned)
            const timelineRow = worksheet.addRow(["Timeline: <?= date('d/m/Y', strtotime($start_date)) ?> to <?= date('d/m/Y', strtotime($end_date)) ?>  |  GENERATED ON: " + new Date().toLocaleString()]);
            worksheet.mergeCells('A2:F2');
            timelineRow.font = { name: 'Arial', bold: true, size: 10, color: { argb: 'FF333333' } };
            timelineRow.alignment = { horizontal: 'left' };

            // Define Columns & Header
            const columns = Array.from(document.querySelectorAll('#tableHeaderRow th')).map(th => th.innerText);
            worksheet.addRow(columns);
            const headerRow = worksheet.getRow(3);
            headerRow.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
            headerRow.eachCell(cell => {
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } }; // Dark Header
                cell.alignment = { horizontal: 'center' };
            });

            // Add Data from Table with Native Excel Currency Formatting
            document.querySelectorAll("#salesTable tbody tr").forEach(tr => {
                if(tr.cells.length > 1) {
                    const rowData = Array.from(tr.cells).map(cell => {
                        let text = cell.innerText.trim();
                        if (text.includes('₹')) {
                            return parseFloat(text.replace(/[^0-9.-]+/g, ''));
                        }
                        return text;
                    });
                    let addedRow = worksheet.addRow(rowData);
                    
                    addedRow.eachCell((cell, colNumber) => {
                        if (typeof cell.value === 'number' && tr.cells[colNumber-1].innerText.includes('₹')) {
                            cell.numFmt = '[$₹-en-IN]#,##0.00';
                            cell.alignment = { horizontal: 'right' };
                            cell.font = { bold: true, color: { argb: 'FF0F172A' } };
                        }
                    });
                }
            });

            // Formatting
            worksheet.columns.forEach(column => {
                column.width = 20; // Auto width for flexibility
                column.alignment = { wrapText: true };
            });

            // Save File
            const buffer = await workbook.xlsx.writeBuffer();
            saveAs(new Blob([buffer]), "Sales_Intelligence_Report.xlsx");
        }
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            flatpickr('.flatpickr', {
                altInput: true,
                altFormat: 'd/m/Y',
                dateFormat: 'Y-m-d',
                allowInput: true
            });
        });
    </script>
</body>
</html>