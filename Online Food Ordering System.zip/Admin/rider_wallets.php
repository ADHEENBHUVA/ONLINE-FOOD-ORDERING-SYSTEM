<?php
session_set_cookie_params(86400 * 30);
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

$conn = new mysqli("localhost", "root", "", "online_food");

// Load Theme Settings
include("admin_theme_loader.php");

$message = "";

if (isset($_POST['zero_wallet'])) {
    $r_id = intval($_POST['rider_id']);
    $conn->query("UPDATE delivery_person SET wallet_balance = 0.00 WHERE id='$r_id'");
    $message = "Wallet successfully zeroed out! Operations settled.";
}

$riders = $conn->query("SELECT * FROM delivery_person ORDER BY wallet_balance DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Wallets | Executive Dash</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; height: 100vh; overflow: hidden; }
        .sidebar { height: 100vh; }
        .main-content { height: 100vh; overflow-y: auto; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    </style>
</head>
<body class="flex">

    <div class="w-20 lg:w-48 bg-slate-900 min-h-screen text-white flex flex-col items-center py-8 relative z-50 shadow-2xl sidebar flex-shrink-0">
        <a href="dashboard.php" class="text-slate-400 hover:text-white transition-all bg-slate-800 hover:bg-orange-500 w-12 h-12 flex items-center justify-center rounded-xl mb-8"><i class="fas fa-home"></i></a>
        <h2 class="hidden lg:block text-sm font-900 tracking-widest text-slate-500 uppercase italic px-4 text-center mt-auto">Return to Main Dash</h2>
    </div>

    <div class="main-content flex-1 bg-slate-50 p-10">

        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-3xl font-900 text-slate-800 tracking-tight uppercase">Fleet Finance <span class="text-orange-500 italic">Ledger</span></h1>
                <p class="text-slate-400 font-bold uppercase tracking-widest text-xs mt-1">Settle physical cash and withdrawal requests</p>
            </div>
            <i class="fas fa-wallet fa-3x text-orange-200"></i>
        </div>

        <?php if($message): ?>
            <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 font-black tracking-widest uppercase text-[10px] rounded-xl flex items-center gap-2 shadow-sm">
                <i class="fas fa-check-circle text-lg"></i>
                <?= $message ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 pb-10">
            <?php while($row = $riders->fetch_assoc()): ?>
            <div class="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-100 hover:shadow-[0_20px_40px_-5px_rgba(249,115,22,0.15)] hover:-translate-y-1.5 transition-all duration-500 relative flex flex-col group overflow-hidden">
                <div class="absolute -right-10 -top-10 w-40 h-40 bg-gradient-to-br from-orange-500/10 to-transparent rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                <div class="flex justify-between items-start mb-6 relative z-10">
                    <div class="flex gap-4 items-center">
                        <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white flex items-center justify-center font-black text-xl shadow-lg border border-slate-700">
                            <?= strtoupper(substr($row['name'], 0, 1)) ?>
                        </div>
                        <div>
                            <h3 class="font-900 text-xl text-slate-800 tracking-tight leading-none mb-2"><?= htmlspecialchars($row['name']) ?></h3>
                            <span class="bg-slate-100 text-slate-500 text-[9px] font-black uppercase tracking-[0.2em] px-2.5 py-1 rounded inline-block border border-slate-200">RID-<?= str_pad($row['id'], 4, '0', STR_PAD_LEFT) ?></span>
                        </div>
                    </div>
                    <?php if($row['status'] == 'Active'): ?>
                        <div class="w-3 h-3 bg-emerald-500 rounded-full shadow-[0_0_10px_#10b981] animate-pulse"></div>
                    <?php else: ?>
                        <div class="w-3 h-3 bg-slate-300 rounded-full"></div>
                    <?php endif; ?>
                </div>

                <div class="flex-1 space-y-3 relative z-10">
                    <div class="flex items-center gap-3 text-xs font-semibold text-slate-500">
                        <div class="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 flex items-center justify-center shrink-0 border border-blue-100"><i class="fas fa-envelope text-[10px]"></i></div>
                        <span class="truncate"><?= htmlspecialchars($row['email']) ?></span>
                    </div>
                    <div class="flex items-center gap-3 text-xs font-semibold text-slate-500">
                        <div class="w-8 h-8 rounded-lg bg-orange-50 text-orange-500 flex items-center justify-center shrink-0 border border-orange-100"><i class="fas fa-motorcycle text-[10px]"></i></div>
                        <span class="uppercase tracking-widest text-[10px] font-black"><?= htmlspecialchars($row['vehicle_number']) ?></span>
                    </div>
                </div>

                <div class="my-6 border-t border-slate-100/80 relative z-10"></div>

                <div class="flex items-end justify-between relative z-10 mb-6">
                    <div>
                        <p class="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Unpaid Balance</p>
                        <div class="font-900 text-4xl tracking-tighter <?= $row['wallet_balance'] > 0 ? 'text-emerald-500' : 'text-slate-300' ?>">
                            &#8377;<?= number_format($row['wallet_balance'], 2) ?>
                        </div>
                    </div>
                    <div class="w-12 h-12 rounded-2xl <?= $row['wallet_balance'] > 0 ? 'bg-emerald-50 text-emerald-500 border border-emerald-100' : 'bg-slate-50 text-slate-300 border border-slate-100' ?> flex items-center justify-center text-xl shadow-sm">
                        <i class="fas <?= $row['wallet_balance'] > 0 ? 'fa-coins' : 'fa-wallet' ?>"></i>
                    </div>
                </div>

                <div class="mt-auto relative z-10">
                    <?php if($row['wallet_balance'] > 0): ?>
                    <form method="POST" class="w-full">
                        <input type="hidden" name="rider_id" value="<?= $row['id'] ?>">
                        <button type="submit" name="zero_wallet" onclick="return confirm('Confirm transfer of physical cash? Zero out <?= htmlspecialchars($row['name']) ?> balance?')" class="w-full bg-slate-900 hover:bg-orange-500 text-white transition-all duration-300 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg flex items-center justify-center gap-2 group/btn">
                            <i class="fas fa-check-double group-hover/btn:scale-125 transition-transform"></i> Settle Account Now
                        </button>
                    </form>
                    <?php else: ?>
                    <div class="w-full bg-slate-50 text-slate-400 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] border border-slate-200 flex items-center justify-center gap-2">
                        <i class="fas fa-check"></i> Account Cleared
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>