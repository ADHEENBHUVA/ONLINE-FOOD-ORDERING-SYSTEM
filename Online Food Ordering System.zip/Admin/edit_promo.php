<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Check Admin Login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

// Check if ID is provided
if (!isset($_GET['id'])) {
    header("Location: manage_promo.php");
    exit();
}

$id = $_GET['id'];

// 1. Fetch existing promo using prepared statement
$stmt = $conn->prepare("SELECT * FROM promo_codes WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("<div style='text-align:center; margin-top:50px; font-family:sans-serif;'>
            <h3>Error: Promo code not found!</h3>
            <a href='manage_promo.php'>Return to List</a>
         </div>");
}

$promo = $result->fetch_assoc();
$stmt->close();

$message = "";

// 2. Update Promo Logic
if (isset($_POST['update_promo'])) {
    $code = strtoupper(trim($_POST['promo_code']));
    $percent = $_POST['discount_percent'];
    $min_value = $_POST['min_order_amt']; // New Minimum Order Value
    $status = $_POST['status'];

    // Updated Update Query with min_order_amt
    $update = $conn->prepare("UPDATE promo_codes SET promo_code=?, discount_percent=?, min_order_amt=?, status=? WHERE id=?");
    $update->bind_param("sddsi", $code, $percent, $min_value, $status, $id);

    if ($update->execute()) {
        header("Location: manage_promo.php?updated=1");
        exit();
    } else {
        $message = "Error: This promo code might already exist or database error.";
    }
    $update->close();
}
?>

<?php include("admin_theme_loader.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Promo Code | Admin Dashboard</title>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --accent: #f59e0b; /* Amber for editing */
            --primary: #6366f1;
            --bg: #f8fafc;
            --card: #ffffff;
            --text-dark: #0f172a;
            --text-light: #64748b;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .edit-card {
            background: var(--card);
            width: 100%;
            max-width: 450px;
            padding: 2.5rem;
            border-radius: 30px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }

        .badge {
            display: inline-block;
            background: #fef3c7;
            color: #92400e;
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 1.2rem;
            letter-spacing: 0.5px;
        }

        h2 {
            margin: 0 0 0.5rem 0;
            font-size: 1.8rem;
            color: var(--text-dark);
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .sub-text {
            color: var(--text-light);
            font-size: 0.9rem;
            margin-bottom: 2rem;
        }

        .alert {
            background: #fff1f2;
            color: #be123c;
            padding: 1rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            border: 1px solid #ffe4e6;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            font-size: 0.8rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 0.6rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.7;
        }

        input, select {
            width: 100%;
            padding: 1rem;
            border: 2px solid #f1f5f9;
            border-radius: 16px;
            font-size: 1rem;
            font-weight: 600;
            box-sizing: border-box;
            transition: all 0.3s ease;
            background: #f8fafc;
            color: var(--text-dark);
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--accent);
            background: #fff;
            box-shadow: 0 0 0 5px rgba(245, 158, 11, 0.1);
        }

        .promo-input {
            font-family: 'Monaco', 'Consolas', monospace;
            text-transform: uppercase;
            color: var(--primary);
            letter-spacing: 2px;
        }

        .btn-update {
            width: 100%;
            background: #0f172a;
            color: white;
            padding: 1.1rem;
            border: none;
            border-radius: 18px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-top: 1rem;
        }

        .btn-update:hover {
            background: #000;
            transform: translateY(-3px);
            box-shadow: 0 15px 30px -10px rgba(0, 0, 0, 0.2);
        }

        .cancel-link {
            display: block;
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-light);
            text-decoration: none;
            transition: 0.2s;
        }

        .cancel-link:hover {
            color: #ef4444;
        }

        /* Styling for the tracker field */
        .tracker-input {
            border-color: #ede9fe;
            color: #7c3aed;
        }
    </style>
</head>
<body>

<div class="edit-card">
    <span class="badge">Promotion Editor</span>
    <h2>Update Coupon</h2>
    <p class="sub-text">Currently editing ID: #<?php echo htmlspecialchars($id); ?></p>

    <?php if($message != ""): ?>
        <div class="alert"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Coupon Code</label>
            <input type="text" name="promo_code" class="promo-input"
                   value="<?php echo htmlspecialchars($promo['promo_code']); ?>" required>
        </div>

        <div class="form-group">
            <label>Discount Percentage (%)</label>
            <input type="number" name="discount_percent" step="0.01" min="0" max="100"
                   value="<?php echo htmlspecialchars($promo['discount_percent']); ?>" required>
        </div>

        <div class="form-group">
            <label>Rupees Tracker (Min. Order Value &#8377;)</label>
            <input type="number" name="min_order_amt" step="0.01" min="0" class="tracker-input"
                   value="<?php echo htmlspecialchars($promo['min_order_amt'] ?? 0); ?>" required>
        </div>

        <div class="form-group">
            <label>Availability Status</label>
            <select name="status">
                <option value="Active" <?php if($promo['status']=="Active") echo "selected"; ?>>🟢 Active</option>
                <option value="Inactive" <?php if($promo['status']=="Inactive") echo "selected"; ?>>🔴 Inactive</option>
            </select>
        </div>

        <button type="submit" name="update_promo" class="btn-update">Apply Changes</button>
    </form>

    <a href="manage_promo.php" class="cancel-link">Discard Changes</a>
</div>

</body>
</html>