<?php
session_set_cookie_params(86400 * 30);
session_start();

// 1. Clear all session data
unset($_SESSION['admin_id']);

// 2. Destroy the session
// session_destroy();

// We will use HTML/CSS for the "Attractive Design"
// and a meta-refresh or JS to redirect after 3 seconds.
?>

<?php include("admin_theme_loader.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logging Out | Foodie's Heaven</title>
    <?php include("admin_theme_loader.php"); ?>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #ff6b6b;
            --bg-gradient: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-gradient);
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .logout-container {
            background: white;
            padding: 50px;
            border-radius: 24px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 400px;
            width: 90%;
        }

        .loader {
            width: 60px;
            height: 60px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--primary-color);
            border-radius: 50%;
            margin: 0 auto 25px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        h2 {
            color: #2d3436;
            margin-bottom: 10px;
            font-size: 22px;
        }

        p {
            color: #636e72;
            font-size: 15px;
            margin-bottom: 25px;
        }

        .redirect-link {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
        }

        .redirect-link:hover {
            text-decoration: underline;
        }
    </style>

    <meta http-equiv="refresh" content="3;url=login.php">
</head>
<body>

<div class="logout-container">
    <div class="loader"></div>
    <h2>Logging You Out</h2>
    <p>Please wait a moment while we securely end your session.</p>

    <div style="font-size: 13px; color: #b2bec3;">
        Redirecting to login in <span id="timer">3</span> seconds...
    </div>
</div>

<script>
    // Simple countdown timer logic
    let seconds = 3;
    const timerDisplay = document.getElementById('timer');

    const countdown = setInterval(() => {
        seconds--;
        timerDisplay.textContent = seconds;
        if (seconds <= 0) clearInterval(countdown);
    }, 1000);
</script>

</body>
</html>