<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Security Check
if (!isset($_SESSION['admin_id'])) exit("Denied");
// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    exit("Session Timeout. Please login again.");
}
$_SESSION['admin_last_activity'] = time();

// Set headers for Excel download
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Full_Order_Report_".date('Y-m-d').".xls");
header("Pragma: no-cache");
header("Expires: 0");

// Fetch Orders with Customer Details, Customer ID, and Discount
// Note: Ensure 'discount_amount' exists in your orders table
$query = "SELECT orders.order_id, orders.customer_id, orders.total_amount, orders.discount_amount,
          orders.payment_method, orders.order_status, orders.order_date,
          customers.name, customers.phone, customers.address
          FROM orders
          LEFT JOIN customers ON orders.customer_id = customers.customer_id
          ORDER BY orders.order_id DESC";
$result = $conn->query($query);

echo '<table border="1">';
echo '<thead>
        <tr>
            <th style="background-color: #f97316; color: white;">Order ID</th>
            <th style="background-color: #f97316; color: white;">Customer ID</th>
            <th style="background-color: #f97316; color: white;">Order Date</th>
            <th style="background-color: #f97316; color: white;">Customer Name</th>
            <th style="background-color: #f97316; color: white;">Phone</th>
            <th style="background-color: #f97316; color: white;">Delivery Address</th>
            <th style="background-color: #f97316; color: white;">Discount (&#8377;)</th>
            <th style="background-color: #f97316; color: white;">Final Amount (&#8377;)</th>
            <th style="background-color: #f97316; color: white;">Payment Method</th>
            <th style="background-color: #f97316; color: white;">Status</th>
        </tr>
      </thead>';

echo '<tbody>';
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Fallback for discount if NULL
        $discount = $row['discount_amount'] ?? 0;

        echo '<tr>';
        echo '<td>ORD-' . $row['order_id'] . '</td>';
        echo '<td>CUST-' . $row['customer_id'] . '</td>';
        echo '<td>' . date("d/m/Y H:i", strtotime($row['order_date'])) . '</td>';
        echo '<td>' . htmlspecialchars($row['name']) . '</td>';
        echo '<td>' . $row['phone'] . '</td>';
        echo '<td>' . htmlspecialchars($row['address']) . '</td>';
        echo '<td style="color: red;">-&#8377;' . number_format($discount, 2) . '</td>';
        echo '<td style="font-weight: bold;">&#8377;' . number_format($row['total_amount'], 2) . '</td>';
        echo '<td>' . strtoupper($row['payment_method']) . '</td>';
        echo '<td>' . $row['order_status'] . '</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="10" style="text-align:center;">No records found</td></tr>';
}
echo '</tbody>';
echo '</table>';
?>