<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Inactivity Auto-Logout (30 Minutes)
if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=timeout');
    exit();
}
$_SESSION['admin_last_activity'] = time();

include("admin_theme_loader.php");
$theme_query = mysqli_query($conn, "SELECT * FROM admin_theme WHERE id=1");
$theme = mysqli_fetch_assoc($theme_query);

$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$active_orders_count = ($active_orders_res) ? $active_orders_res->fetch_assoc()['total'] : 0;

$sql = "SELECT
            feedback.*,
            customers.customer_id,
            customers.name,
            orders.order_id,
            orders.order_status,
            GROUP_CONCAT(food_items.food_name SEPARATOR '\n') AS items_purchased
        FROM feedback
        JOIN customers ON feedback.customer_id = customers.customer_id
        JOIN orders ON feedback.order_id = orders.order_id
        JOIN order_items ON orders.order_id = order_items.order_id
        JOIN food_items ON order_items.food_id = food_items.food_id
        WHERE orders.order_status = 'Delivered'
        GROUP BY feedback.feedback_id
        ORDER BY feedback.feedback_id DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Intelligence | Foodie's Heaven</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <?php include("admin_theme_loader.php"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

    <style>
        :root { --primary: #4f46e5; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: <?php echo ($theme['mode']=="dark") ? "#0f172a" : "#f8fafc"; ?>; color: <?php echo ($theme['mode']=="dark") ? "#f1f5f9" : "#1e293b"; ?>; overflow: hidden; }
        .sidebar-premium { background: #0f172a; width: 288px; height: 100vh; flex-shrink: 0; }
        .glass-nav {
            background: <?php echo ($theme['mode'] == 'dark') ? 'rgba(15, 23, 42, 0.8)' : 'rgba(255, 255, 255, 0.8)'; ?>;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        .custom-card { border-radius: 2rem; }
        .glass-card {
            background: <?php echo ($theme['mode'] == 'dark') ? 'rgba(30, 41, 59, 0.7)' : 'rgba(255, 255, 255, 0.9)'; ?>;
            backdrop-filter: blur(10px);
        }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>
<body class="flex min-h-screen">

    <aside class="w-72 sidebar-premium text-slate-400 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">

        <div class="p-6 flex items-center justify-center border-b border-slate-800/50">
            <img src="../images/logo.png" alt="Admin Logo" class="w-55 h-55 rounded-xl shadow-lg object-cover block mx-auto">
        </div>

    <nav class="flex-1 px-4 space-y-2 mt-8 overflow-y-auto custom-scrollbar">
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Main Management</p>

        <a href="dashboard.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-chart-pie w-5 text-orange-500text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Dashboard</span>
            </div>
        </a>

        <a href="manage_food.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-hamburger w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Manage Food</span>
            </div>
            <span class="bg-emerald-500/10 text-emerald-500 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-500/20">LIVE</span>
        </a>

        <a href="manage_categories.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-list-ul w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Categories</span>
            </div>
        </a>

        <a href="manage_promo.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-ticket-alt w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Coupons</span>
            </div>
            <span class="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse">SALE</span>
        </a>

        <a href="manage_orders.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
    <div class="flex items-center gap-3">
        <i class="fas fa-shopping-basket w-5 text-slate-600 group-hover:text-orange-400"></i>
        <span class="font-semibold text-sm">Active Orders</span>
    </div>
    <?php if($active_orders_count > 0): ?>
        <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
            <?php echo $active_orders_count; ?>
        </span>
    <?php endif; ?>
</a>

        <a href="manage_customers.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-users-cog w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Customer Base</span>
            </div>
        </a>
        <a href="manage_vip.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group text-amber-500 hover:text-amber-400">
            <div class="flex items-center gap-3">
                <i class="fas fa-star w-5"></i>
                <span class="font-semibold text-sm">VIP Members</span>
            </div>
        </a>

        <div class="my-4 border-t border-slate-800/50 mx-4"></div>
        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-600 px-4 mb-2">Operations & System</p>

        <a href="admin_feedback.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-comment-alt-dots w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Feedback</span>
            </div>
        </a>

        <a href="manage_delivery_person.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-shipping-fast w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Fleet Status</span>
            </div>
            <span class="relative flex h-2 w-2">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
        </a>

        <a href="admin_withdrawals.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-wallet w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Rider Payouts</span>
            </div>
            <?php if(isset($withdraw_count) && $withdraw_count > 0): ?>
            <span class="bg-red-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full shadow-sm animate-pulse">
                <?= $withdraw_count ?>
            </span>
            <?php endif; ?>
        </a>

        <a href="sales_report.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-file-invoice-dollar w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Sales Analytics</span>
            </div>
        </a>

        <a href="delivery_settings.php" class="flex items-center justify-between px-4 py-3.5 bg-transparent hover:bg-slate-800/50 rounded-2xl transition-all duration-300 group relative border border-transparent hover:border-slate-700/50">
        <div class="flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-orange-500/10 transition-colors">
                <i class="fas fa-crown text-slate-500 group-hover:text-orange-500 text-sm transition-colors"></i>
            </div>
            <div class="flex flex-col">
                <span class="font-bold text-sm text-slate-300 group-hover:text-white transition-colors">VIP Customers</span>
                <span class="text-[10px] text-slate-600 font-medium group-hover:text-slate-400 transition-colors">Logistics & Rules</span>
            </div>
        </div>
        <i class="fas fa-chevron-right text-[10px] text-slate-700 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>

        <div class="absolute left-0 w-1 h-5 bg-orange-500 rounded-r-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </a>

        <a href="change_theme.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800 hover:text-white rounded-xl transition group">
            <div class="flex items-center gap-3">
                <i class="fas fa-palette w-5 text-slate-600 group-hover:text-orange-400"></i>
                <span class="font-semibold text-sm">Change Theme</span>
            </div>
            <span class="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-500/20">NEW</span>
        </a>

        <a href="change_password_auth.php" class="flex items-center justify-between px-4 py-3.5 hover:bg-slate-800/50 hover:text-white rounded-2xl transition-all duration-300 group relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

    <div class="flex items-center gap-3 relative z-10">
        <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700 group-hover:border-orange-500/50 group-hover:bg-orange-500 transition-all duration-300 shadow-lg">
            <i class="fas fa-key text-slate-400 group-hover:text-white text-sm"></i>
        </div>

        <div class="flex flex-col">
            <span class="font-bold text-sm tracking-tight text-slate-300 group-hover:text-white transition-colors">Access Security</span>
            <span class="text-[9px] font-medium text-slate-500 group-hover:text-orange-200 uppercase tracking-widest">Update Master Key</span>
        </div>
    </div>

    <div class="relative z-10 flex items-center">
        <div class="h-1.5 w-1.5 rounded-full bg-orange-500 animate-pulse mr-2 shadow-[0_0_8px_#f97316]"></div>
        <i class="fas fa-chevron-right text-[10px] text-slate-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
    </div>
</a>
    </nav>

    <div class="p-6 border-t border-slate-800/50">
        <a href="logout.php" class="flex items-center gap-3 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition group">
            <i class="fas fa-power-off"></i>
            <span class="font-bold text-sm">Sign Out</span>
        </a>
    </div>
</aside>
    <div class="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <header class="glass-nav px-8 h-[72px] flex items-center justify-between flex-shrink-0 z-50">
            <div class="flex items-center gap-4">
                <div class="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
                    <i class="fas fa-brain"></i>
                </div>
                <div>
                    <h1 class="text-xl font-900 tracking-tighter italic uppercase">Feedback <span class="text-indigo-600">Intelligence</span></h1>
                    <p class="text-[10px] uppercase font-bold opacity-40 tracking-widest -mt-1">Experience Analytics & Insights</p>
                </div>
            </div>

            <div class="flex items-center gap-4">
                <div class="flex items-center gap-2">
                    <button onclick="exportToPDF()" class="bg-rose-500 hover:bg-rose-600 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-rose-500/20 transition-all">
                        <i class="fas fa-file-pdf text-base"></i> PDF
                    </button>
                    <button onclick="exportToExcelStyled()" class="bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-emerald-500/20 transition-all">
                        <i class="fas fa-file-excel text-base"></i> EXCEL
                    </button>
                </div>
            </div>
        </header>

        <div class="flex-1 overflow-y-auto p-8 custom-scrollbar">
            <div class="custom-card overflow-hidden shadow-2xl glass-card rounded-[2rem] border-slate-100 p-1">
                <table class="w-full text-left border-collapse" id="feedbackTable">
                    <thead>
                        <tr class="text-[10px] font-black uppercase tracking-widest text-slate-400 border-b bg-slate-50/50">
                            <th class="px-8 py-5">Order Context</th>
                            <th class="px-8 py-5">Patron Identity</th>
                            <th class="px-8 py-5">Satisfaction</th>
                            <th class="px-8 py-5">Intelligence Note</th>
                            <th class="px-8 py-5">Timestamp</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50">
                        <?php if(mysqli_num_rows($result) > 0):
                            $colors = ['bg-indigo-500', 'bg-blue-600', 'bg-sky-500', 'bg-violet-500'];
                            while($row = mysqli_fetch_assoc($result)):
                                $r = (int)$row['rating'];
                                $badgeClr = ($r >= 4) ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : (($r >= 3) ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20');

                                $initials = "";
                                $parts = explode(" ", $row['name']);
                                foreach($parts as $p) { if(!empty($p)) $initials .= mb_substr($p, 0, 1); }
                                $display_initials = mb_strtoupper(mb_substr($initials, 0, 2));
                                $rand_color = $colors[array_rand($colors)];
                        ?>
                        <tr class="group hover:bg-indigo-50/30 transition-all cursor-default">
                            <td class="px-8 py-6">
                                <div class="font-mono text-[11px] font-bold text-indigo-600 f-order-id">#ORD-<?php echo $row['order_id']; ?></div>
                                <div class="text-[9px] font-bold opacity-40 mt-1 max-w-[150px] line-clamp-2 f-items italic"><?php echo nl2br(htmlspecialchars($row['items_purchased'] ?? '')); ?></div>
                            </td>
                            <td class="px-8 py-6">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 <?php echo $rand_color; ?> rounded-lg flex items-center justify-center text-white font-black text-[10px] shadow-lg shadow-indigo-500/10 group-hover:rotate-6 transition-transform">
                                        <?php echo $display_initials; ?>
                                    </div>
                                    <div>
                                        <p class="font-900 text-sm text-slate-800 tracking-tight f-cust-name"><?php echo htmlspecialchars($row['name']); ?></p>
                                        <span class="text-[9px] font-bold opacity-30">#CUST-<?php echo $row['customer_id']; ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="px-8 py-6">
                                <span class="<?php echo $badgeClr; ?> px-3 py-1.5 rounded-full text-[9px] font-black uppercase border f-rating flex items-center gap-1.5 w-fit">
                                    <i class="fas fa-star text-[8px]"></i> <?php echo $r; ?> STARS
                                </span>
                            </td>
                            <td class="px-8 py-6 max-w-xs">
                                <div class="relative p-3 bg-slate-50 rounded-xl group-hover:bg-white transition-colors border border-transparent group-hover:border-slate-100">
                                    <i class="fas fa-quote-left absolute -top-1 -left-1 text-slate-200 text-[10px]"></i>
                                    <p class="text-xs font-medium text-slate-600 italic line-clamp-3 f-msg leading-relaxed">"<?php echo htmlspecialchars($row['message']); ?>"</p>
                                </div>
                            </td>
                            <td class="px-8 py-6 f-timestamp">
                                <div class="flex flex-col">
                                    <span class="text-[10px] font-black text-slate-800"><?php echo date("d M, Y", strtotime($row['feedback_date'])); ?></span>
                                    <span class="text-[9px] font-bold text-slate-400 uppercase"><?php echo date("h:i A", strtotime($row['feedback_date'])); ?></span>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr><td colspan="5" class="py-32 text-center opacity-20 font-black italic uppercase tracking-[0.5em] text-sm">No Intelligence Data Captured</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function exportToPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('l', 'pt', 'a4');
            doc.setFillColor(79, 70, 229); // Indigo Header
            doc.rect(0, 0, 900, 80, 'F');
            doc.setFont("helvetica", "bold");
            doc.setFontSize(22);
            doc.setTextColor(255, 255, 255);
            doc.text("FEEDBACK INTELLIGENCE LOG", 40, 45);
            doc.setFontSize(10);
            doc.text("GENERATED ON: " + new Date().toLocaleString(), 40, 65);
            const columns = ["Order ID", "Customer", "Items", "Rating", "Message", "Time & Date"];
            const rows = [];
            document.querySelectorAll("#feedbackTable tbody tr").forEach(row => {
                if(row.cells.length > 1) {
                    rows.push([
                        row.querySelector('.f-order-id').innerText.trim(),
                        row.querySelector('.f-cust-name').innerText.trim(),
                        row.querySelector('.f-items').innerText.trim(),
                        row.querySelector('.f-rating').innerText.trim(),
                        row.querySelector('.f-msg').innerText.trim(),
                        row.querySelector('.f-timestamp').innerText.replace(/\s+/g, ' ').trim()
                    ]);
                }
            });
            doc.autoTable({ rowPageBreak: 'avoid', head: [columns], body: rows, startY: 100, theme: 'striped', headStyles: { fillColor: [30, 41, 59], fontStyle: 'bold' }, styles: { fontSize: 8, overflow: 'linebreak' } });
            doc.save("Feedback_Report.pdf");
        }

        async function exportToExcelStyled() {
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Feedback Log');
            const titleRow = worksheet.addRow(["FOODIE'S HEAVEN EXECUTIVE - OFFICIAL FEEDBACK REPORT"]);
            titleRow.font = { name: 'Arial Black', size: 16, bold: true, color: { argb: 'FFFFFFFF' } };
            titleRow.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4F46E5' } };
            worksheet.mergeCells('A1:F1');
            titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
            titleRow.height = 35;
            worksheet.getRow(2).values = ["Order ID", "Customer Name", "Items Purchased", "Satisfaction", "Message", "Timestamp"];
            const headerRow = worksheet.getRow(2);
            headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
            headerRow.eachCell(cell => { cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } }; });
            document.querySelectorAll("#feedbackTable tbody tr").forEach(row => {
                if (row.cells.length > 1) {
                    worksheet.addRow([
                        row.querySelector('.f-order-id').innerText.trim(),
                        row.querySelector('.f-cust-name').innerText.trim(),
                        row.querySelector('.f-items').innerText.trim(),
                        row.querySelector('.f-rating').innerText.trim(),
                        row.querySelector('.f-msg').innerText.trim(),
                        row.querySelector('.f-timestamp').innerText.replace(/\s+/g, ' ').trim()
                    ]);
                }
            });
            worksheet.columns.forEach(col => col.width = 25);
            const buffer = await workbook.xlsx.writeBuffer();
            saveAs(new Blob([buffer]), "Feedback_Report.xlsx");
        }
    </script>
</body>
</html>