<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php"); // Ensure db.php handles the connection and $conn variable

// Check Login
if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];
$message = "";
$msg_type = ""; // To distinguish between success and error

// Fetch current customer details
$user_query = $conn->prepare("SELECT * FROM customers WHERE customer_id=?");
$user_query->bind_param("i", $customer_id);
$user_query->execute();
$result = $user_query->get_result();
$user = $result->fetch_assoc();

// Handle form submission
if (isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    if (empty($name) || empty($email) || empty($phone)) {
        $message = "All fields are required!";
        $msg_type = "error";
    }
    elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        $message = "Invalid name! Only alphabets and spaces are allowed.";
        $msg_type = "error";
    }
    elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $message = "Invalid phone number! Please enter 10 digits.";
        $msg_type = "error";
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format!";
        $msg_type = "error";
    }
    else {
        $stmt = $conn->prepare("SELECT customer_id FROM customers WHERE email=? AND customer_id != ?");
        $stmt->bind_param("si", $email, $customer_id);
        $stmt->execute();
        $check_email = $stmt->get_result();

        if ($check_email->num_rows > 0) {
            $message = "Email already in use!";
            $msg_type = "error";
        }
        else {
            $stmt_update = $conn->prepare("UPDATE customers SET name=?, email=?, phone=? WHERE customer_id=?");
            $stmt_update->bind_param("sssi", $name, $email, $phone, $customer_id);

            if ($stmt_update->execute()) {
                $_SESSION['customer_name'] = $name;
                $message = "Profile updated successfully!";
                $msg_type = "success";
                // Refresh data
                $user['name'] = $name;
                $user['email'] = $email;
                $user['phone'] = $phone;
            }
            else {
                $message = "Update failed!";
                $msg_type = "error";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; }
        .executive-form { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); }
        .input-group:focus-within label { color: #f97316; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6">

<div class="max-w-md w-full relative">
    <!-- Ambient Glows -->
    <div class="absolute -top-10 -left-10 w-40 h-40 bg-orange-500/20 blur-3xl rounded-full pointer-events-none"></div>
    <div class="absolute -bottom-10 -right-10 w-40 h-40 bg-slate-500/10 blur-3xl rounded-full pointer-events-none"></div>

    <div class="mb-8 flex justify-between items-center px-4 relative z-10">
        <a href="profile.php" class="text-slate-500 hover:text-orange-500 transition-colors flex items-center gap-2 text-sm font-bold uppercase tracking-widest">
            <i class="fas fa-arrow-left"></i> Dashboard
        </a>
    </div>

    <div class="executive-form rounded-[2.5rem] shadow-2xl border border-white p-8 sm:p-10 relative z-10 bg-white">

        <div class="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-slate-900 text-white rounded-[2rem] flex items-center justify-center text-4xl shadow-xl shadow-slate-900/20 border-4 border-slate-50">
            <i class="fas fa-user-pen"></i>
        </div>

        <div class="text-center mt-12 mb-8">
            <h2 class="text-3xl font-900 text-slate-800 tracking-tight">Identity Settings</h2>
            <p class="text-slate-400 font-medium text-sm mt-1">Keep your executive credentials updated.</p>
        </div>

        <?php if ($message != ""): ?>
            <div class="mb-6 p-4 rounded-2xl text-sm font-bold flex items-center gap-3 animate-pulse <?= ($msg_type=='success')?'bg-emerald-50 text-emerald-700 border border-emerald-100':'bg-rose-50 text-rose-700 border border-rose-100' ?>">
                <i class="fas <?= ($msg_type=='success')?'fa-check-circle':'fa-circle-exclamation' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">

            <div class="input-group">
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-1 transition-colors">Full Name</label>
                <div class="relative">
                    <i class="fas fa-id-badge absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');"
                           class="w-full bg-slate-50 border border-slate-200 py-3.5 pl-11 pr-4 rounded-xl outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-bold text-slate-800 transition-all">
                </div>
            </div>

            <div class="input-group">
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-1 transition-colors">Email Network</label>
                <div class="relative">
                    <i class="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required
                           class="w-full bg-slate-50 border border-slate-200 py-3.5 pl-11 pr-4 rounded-xl outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-bold text-slate-800 transition-all">
                </div>
            </div>

            <div class="input-group">
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-1 transition-colors">Direct Line</label>
                <div class="relative">
                    <i class="fas fa-phone absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');"
                           class="w-full bg-slate-50 border border-slate-200 py-3.5 pl-11 pr-4 rounded-xl outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-bold text-slate-800 transition-all">
                </div>
            </div>

            <button type="submit" name="update_profile"
                    class="w-full bg-slate-900 hover:bg-orange-500 text-white font-900 py-4 mt-2 rounded-xl text-xs uppercase tracking-[0.2em] shadow-xl hover:shadow-orange-500/20 transition-all active:scale-[0.98]">
                Save Identity
            </button>
        </form>

    </div>
</div>

</body>
</html>
