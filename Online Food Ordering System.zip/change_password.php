<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// Security Check: Redirect if not logged in
if(!isset($_SESSION['customer_id'])){
    header("Location: login.php");
    exit();
}

$message = "";
$msg_type = "error";

if(isset($_POST['change_password'])){

    $customer_id = $_SESSION['customer_id'];

    // Sanitize inputs
    $current_password = mysqli_real_escape_string($conn, $_POST['current_password']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Fetch current password from database
    $sql = "SELECT password FROM customers WHERE customer_id='$customer_id'";
    $result = $conn->query($sql);

    if($result && $row = $result->fetch_assoc()){

        if($row['password'] != $current_password){
            $message = "The current password you entered is incorrect.";
        }
        else if($new_password != $confirm_password){
            $message = "New password confirmation does not match.";
        }
        else if(strlen($new_password) < 6){
            $message = "Security Tip: Password should be at least 6 characters.";
        }
        else {
            // Update logic
            $update = "UPDATE customers SET password='$new_password' WHERE customer_id='$customer_id'";

            if($conn->query($update)){
                $message = "Success! Your password has been updated.";
                $msg_type = "success";
                // Optional: redirect after 2 seconds via JS or meta
            } else {
                $message = "System error. Please try again later.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Settings | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; }
        .executive-form { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); }
        .input-group:focus-within label { color: #f97316; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6">

<div class="max-w-md w-full relative">
    <!-- Ambient Glows -->
    <div class="absolute -top-10 -left-10 w-40 h-40 bg-orange-500/20 blur-3xl rounded-full pointer-events-none"></div>
    <div class="absolute -bottom-10 -right-10 w-40 h-40 bg-slate-500/10 blur-3xl rounded-full pointer-events-none"></div>

    <div class="mb-8 flex justify-between items-center px-4 relative z-10">
        <a href="profile.php" class="text-slate-500 hover:text-orange-500 transition-colors flex items-center gap-2 text-sm font-bold uppercase tracking-widest">
            <i class="fas fa-arrow-left"></i> Dashboard
        </a>
    </div>

    <div class="executive-form rounded-[2.5rem] shadow-2xl border border-white p-8 sm:p-10 relative z-10 bg-white">

        <div class="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-slate-900 text-white rounded-[2rem] flex items-center justify-center text-4xl shadow-xl shadow-slate-900/20 border-4 border-slate-50">
            <i class="fas fa-shield-halved"></i>
        </div>

        <div class="text-center mt-12 mb-8">
            <h2 class="text-3xl font-900 text-slate-800 tracking-tight">Access Control</h2>
            <p class="text-slate-400 font-medium text-sm mt-1">Update your cryptographic credentials.</p>
        </div>

        <?php if ($message != ""): ?>
            <div class="mb-6 p-4 rounded-2xl text-sm font-bold flex items-center gap-3 animate-pulse <?= ($msg_type=='success')?'bg-emerald-50 text-emerald-700 border border-emerald-100':'bg-rose-50 text-rose-700 border border-rose-100' ?>">
                <i class="fas <?= ($msg_type=='success')?'fa-check-circle':'fa-circle-exclamation' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">

            <div class="input-group">
                <div class="flex justify-between items-center mb-2 ml-1">
                    <label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 transition-colors">Current Key</label>
                    <a href="forgot_password.php" class="text-[10px] font-bold text-orange-500 hover:text-orange-600 underline underline-offset-2">Forgot Key?</a>
                </div>
                <div class="relative">
                    <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="password" name="current_password" id="p1" required
                           class="w-full bg-slate-50 border border-slate-200 py-3.5 pl-11 pr-11 rounded-xl outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-bold text-slate-800 transition-all">
                    <button type="button" onclick="t('p1',this)" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-orange-500">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <hr class="border-slate-100">

            <div class="input-group">
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-1 transition-colors">New Key Master</label>
                <div class="relative">
                    <i class="fas fa-key absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="password" name="new_password" id="p2" required
                           class="w-full bg-slate-50 border border-slate-200 py-3.5 pl-11 pr-11 rounded-xl outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-bold text-slate-800 transition-all">
                    <button type="button" onclick="t('p2',this)" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-orange-500">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div class="input-group">
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 ml-1 transition-colors">Verify New Key</label>
                <div class="relative">
                    <i class="fas fa-check-double absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="password" name="confirm_password" id="p3" required
                           class="w-full bg-slate-50 border border-slate-200 py-3.5 pl-11 pr-11 rounded-xl outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-bold text-slate-800 transition-all">
                    <button type="button" onclick="t('p3',this)" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-orange-500">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" name="change_password"
                    class="w-full bg-slate-900 hover:bg-orange-500 text-white font-900 py-4 mt-2 rounded-xl text-xs uppercase tracking-[0.2em] shadow-xl hover:shadow-orange-500/20 transition-all active:scale-[0.98]">
                Encrypt & Save
            </button>
        </form>

    </div>
</div>
<script>
    function t(id,btn){
        let i=document.getElementById(id), c=btn.children[0];
        if(i.type==="password"){ i.type="text"; c.className="fas fa-eye-slash"; }
        else{ i.type="password"; c.className="fas fa-eye"; }
    }
</script>
</body>
</html>
