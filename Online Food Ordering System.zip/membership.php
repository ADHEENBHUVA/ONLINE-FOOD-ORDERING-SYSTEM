<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// If not logged in, redirect to login
if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];
$user_query = $conn->query("SELECT is_vip, membership_expiry FROM customers WHERE customer_id='$customer_id'");
$user = $user_query->fetch_assoc();

$settings_query = $conn->query("SELECT vip_membership_price, vip_monthly_discount_percent, vip_3months_price, vip_3months_discount_percent, vip_6months_price, vip_6months_discount_percent, vip_yearly_price, vip_yearly_discount_percent FROM delivery_settings WHERE id=1");
$settings = $settings_query->fetch_assoc();

$vip_monthly_price = $settings['vip_membership_price'] ?? 499.00;
$vip_monthly_discount_percent = $settings['vip_monthly_discount_percent'] ?? 0;
$final_monthly_price = $vip_monthly_price - ($vip_monthly_price * ($vip_monthly_discount_percent / 100));

$vip_3months_price = $settings['vip_3months_price'] ?? 1299.00;
$vip_3months_discount_percent = $settings['vip_3months_discount_percent'] ?? 0;
$final_3months_price = $vip_3months_price - ($vip_3months_price * ($vip_3months_discount_percent / 100));

$vip_6months_price = $settings['vip_6months_price'] ?? 2499.00;
$vip_6months_discount_percent = $settings['vip_6months_discount_percent'] ?? 0;
$final_6months_price = $vip_6months_price - ($vip_6months_price * ($vip_6months_discount_percent / 100));

$vip_yearly_price = $settings['vip_yearly_price'] ?? 4999.00;
$vip_yearly_discount_percent = $settings['vip_yearly_discount_percent'] ?? 0;
$final_yearly_price = $vip_yearly_price - ($vip_yearly_price * ($vip_yearly_discount_percent / 100));

$is_active_vip = ($user && $user['is_vip'] == 1 && ($user['membership_expiry'] ?? '') >= date('Y-m-d'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VIP Premium Membership | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; color: #f8fafc; overflow-x: hidden; }
        .glass-panel { background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,0.05); }
        .golden-text { background: linear-gradient(to right, #fbbf24, #f59e0b, #d97706); -webkit-background-clip: text; color: transparent; }
        .btn-gold { background: linear-gradient(135deg, #f59e0b, #d97706); transition: all 0.3s ease; box-shadow: 0 10px 25px -5px rgba(245, 158, 11, 0.4); }
        .btn-gold:hover { transform: translateY(-3px); box-shadow: 0 20px 35px -5px rgba(245, 158, 11, 0.5); }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.15) 0, transparent 50%), radial-gradient(at 100% 100%, rgba(249, 115, 22, 0.1) 0, transparent 50%); }
    </style>
</head>
<body class="min-h-screen flex flex-col">

    <div class="mesh-bg"></div>

    <!-- Header Navigation -->
    <header class="glass-panel sticky top-0 z-50 px-8 py-5 flex justify-between items-center shadow-2xl">
        <div class="flex items-center gap-3">
            <a href="index.php" class="text-slate-400 hover:text-white transition w-10 h-10 flex items-center justify-center rounded-full bg-slate-800"><i class="fas fa-arrow-left"></i></a>
            <h1 class="text-2xl font-900 italic tracking-tighter uppercase">FOODIE'S <span class="text-amber-500">HEAVEN</span></h1>
        </div>
        <div>
            <a href="profile.php" class="w-10 h-10 rounded-full bg-slate-800 border-2 border-slate-700 flex items-center justify-center hover:border-amber-500 transition-colors">
                <i class="fas fa-user text-slate-400"></i>
            </a>
        </div>
    </header>

    <main class="flex-1 flex items-center justify-center p-6 lg:p-12 relative">
        <div class="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">

            <!-- Left Side Pitch -->
            <div>
                <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500 text-xs font-black uppercase tracking-widest mb-6 border-l-4 border-l-amber-500">
                    <i class="fas fa-crown"></i> Exclusive Access
                </div>
                <h2 class="text-5xl lg:text-7xl font-900 tracking-tighter mb-6 leading-tight">
                    Elevate Your <br><span class="golden-text">Dining Experience.</span>
                </h2>
                <p class="text-slate-400 text-lg font-medium mb-10 leading-relaxed max-w-xl">
                    Join our VIP Elite tier to unlock free priority deliveries, exclusive secret menus, and flat discounts on every single order. Because you deserve the absolute best.
                </p>

                <div class="space-y-6 mb-12">
                    <div class="flex items-start gap-4">
                        <div class="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-500 text-xl flex-shrink-0">
                            <i class="fas fa-shipping-fast"></i>
                        </div>
                        <div>
                            <h4 class="text-white font-bold text-lg">Zero Delivery Fees</h4>
                            <p class="text-slate-400 text-sm">Enjoy absolute free delivery within your prioritized radius.</p>
                        </div>
                    </div>
                    <div class="flex items-start gap-4">
                        <div class="w-12 h-12 rounded-2xl bg-orange-500/10 flex items-center justify-center text-orange-500 text-xl flex-shrink-0">
                            <i class="fas fa-tags"></i>
                        </div>
                        <div>
                            <h4 class="text-white font-bold text-lg">VIP Exclusive Discounts</h4>
                            <p class="text-slate-400 text-sm">Automated percentage-offs and zero surge pricing during rush hours.</p>
                        </div>
                    </div>
                    <div class="flex items-start gap-4">
                        <div class="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 text-xl flex-shrink-0">
                            <i class="fas fa-headset"></i>
                        </div>
                        <div>
                            <h4 class="text-white font-bold text-lg">Priority Dispatch</h4>
                            <p class="text-slate-400 text-sm">Your orders jump to the front of the kitchen queue automatically.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side Pricing Card -->
            <div class="flex justify-center">
                <div class="w-full max-w-md relative group">
                    <!-- Glow effect -->
                    <div class="absolute inset-0 bg-gradient-to-r from-amber-500 to-orange-600 rounded-[2.5rem] blur-2xl opacity-20 group-hover:opacity-40 transition-opacity duration-500"></div>

                    <div class="glass-panel p-10 rounded-[2.5rem] relative overflow-hidden border border-amber-500/30">
                        <div class="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>

                        <?php if($is_active_vip): ?>
                            <!-- ALREADY VIP -->
                            <div class="text-center py-8">
                                <div class="w-24 h-24 bg-amber-500/20 text-amber-500 rounded-full flex items-center justify-center text-5xl mx-auto mb-6 shadow-[0_0_30px_rgba(245,158,11,0.3)]">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <h3 class="text-3xl font-900 text-white mb-2">You are VIP.</h3>
                                <p class="text-amber-500 font-bold text-sm tracking-widest uppercase mb-8">Valid until: <?php echo date('d/m/Y', strtotime($user['membership_expiry'])); ?></p>

                                <a href="index.php#menu-section" class="block w-full text-center btn-gold text-white font-black text-sm uppercase tracking-widest py-5 rounded-2xl">
                                    Order Now
                                </a>
                            </div>
                        <?php else: ?>
                            <!-- BUY MEMBERSHIP -->
                            <div class="flex flex-col gap-3 mb-8">
                                <div id="plan-monthly" onclick="selectPlan('monthly', <?= $final_monthly_price ?>)" class="cursor-pointer border border-amber-500 rounded-2xl p-4 text-center transition-all bg-amber-500/10 hover:shadow-[0_0_15px_rgba(245,158,11,0.2)]">
                                    <h4 class="text-slate-300 font-bold uppercase tracking-widest text-[9px] mb-2">1 Month</h4>
                                    <?php if ($vip_monthly_discount_percent > 0): ?>
                                        <p class="text-slate-500 line-through text-[9px] mb-0.5">&#8377;<?= number_format($vip_monthly_price, 0) ?></p>
                                    <?php endif; ?>
                                    <div class="flex justify-center items-center gap-1">
                                        <span class="text-amber-500 font-bold text-xs">&#8377;</span>
                                        <span class="text-xl font-900 text-white"><?= number_format($final_monthly_price, 0) ?></span>
                                    </div>
                                    <?php if ($vip_monthly_discount_percent > 0): ?>
                                        <span class="bg-red-500/20 text-red-400 text-[8px] font-black px-1.5 py-0.5 rounded mt-2 inline-block uppercase"><?= number_format($vip_monthly_discount_percent, 0) ?>% OFF</span>
                                    <?php endif; ?>
                                </div>

                                <div id="plan-3months" onclick="selectPlan('3months', <?= $final_3months_price ?>)" class="cursor-pointer border border-slate-700 hover:border-amber-500/50 rounded-2xl p-4 text-center transition-all bg-slate-800/50 hover:bg-slate-800">
                                    <h4 class="text-slate-300 font-bold uppercase tracking-widest text-[9px] mb-2">3 Months</h4>
                                    <?php if ($vip_3months_discount_percent > 0): ?>
                                        <p class="text-slate-500 line-through text-[9px] mb-0.5">&#8377;<?= number_format($vip_3months_price, 0) ?></p>
                                    <?php endif; ?>
                                    <div class="flex justify-center items-center gap-1">
                                        <span class="text-amber-500 font-bold text-xs">&#8377;</span>
                                        <span class="text-xl font-900 text-white"><?= number_format($final_3months_price, 0) ?></span>
                                    </div>
                                    <?php if ($vip_3months_discount_percent > 0): ?>
                                        <span class="bg-orange-500/20 text-orange-400 text-[8px] font-black px-1.5 py-0.5 rounded mt-2 inline-block uppercase"><?= number_format($vip_3months_discount_percent, 0) ?>% OFF</span>
                                    <?php endif; ?>
                                </div>

                                <div id="plan-6months" onclick="selectPlan('6months', <?= $final_6months_price ?>)" class="cursor-pointer border border-slate-700 hover:border-amber-500/50 rounded-2xl p-4 text-center transition-all bg-slate-800/50 hover:bg-slate-800">
                                    <h4 class="text-slate-300 font-bold uppercase tracking-widest text-[9px] mb-2">6 Months</h4>
                                    <?php if ($vip_6months_discount_percent > 0): ?>
                                        <p class="text-slate-500 line-through text-[9px] mb-0.5">&#8377;<?= number_format($vip_6months_price, 0) ?></p>
                                    <?php endif; ?>
                                    <div class="flex justify-center items-center gap-1">
                                        <span class="text-amber-500 font-bold text-xs">&#8377;</span>
                                        <span class="text-xl font-900 text-white"><?= number_format($final_6months_price, 0) ?></span>
                                    </div>
                                    <?php if ($vip_6months_discount_percent > 0): ?>
                                        <span class="bg-orange-500/20 text-orange-400 text-[8px] font-black px-1.5 py-0.5 rounded mt-2 inline-block uppercase"><?= number_format($vip_6months_discount_percent, 0) ?>% OFF</span>
                                    <?php endif; ?>
                                </div>

                                <div id="plan-yearly" onclick="selectPlan('yearly', <?= $final_yearly_price ?>)" class="cursor-pointer border border-slate-700 hover:border-amber-500/50 rounded-2xl p-4 text-center transition-all bg-slate-800/50 hover:bg-slate-800">
                                    <h4 class="text-slate-300 font-bold uppercase tracking-widest text-[9px] mb-2">1 Year</h4>
                                    <?php if ($vip_yearly_discount_percent > 0): ?>
                                        <p class="text-slate-500 line-through text-[9px] mb-0.5">&#8377;<?= number_format($vip_yearly_price, 0) ?></p>
                                    <?php endif; ?>
                                    <div class="flex justify-center items-center gap-1">
                                        <span class="text-amber-500 font-bold text-xs">&#8377;</span>
                                        <span class="text-xl font-900 text-white"><?= number_format($final_yearly_price, 0) ?></span>
                                    </div>
                                    <?php if ($vip_yearly_discount_percent > 0): ?>
                                        <span class="bg-orange-500/20 text-orange-400 text-[8px] font-black px-1.5 py-0.5 rounded mt-2 inline-block uppercase"><?= number_format($vip_yearly_discount_percent, 0) ?>% OFF</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <ul class="space-y-4 mb-10 text-sm text-slate-300 font-medium">
                                <li class="flex items-center gap-3"><i class="fas fa-check text-amber-500"></i> Free Delivery</li>
                                <li class="flex items-center gap-3"><i class="fas fa-check text-amber-500"></i> 10% Flat VIP Discount</li>
                                <li class="flex items-center gap-3"><i class="fas fa-check text-amber-500"></i> Front-line Dispatch</li>
                                <li class="flex items-center gap-3"><i class="fas fa-check text-amber-500"></i> Dedicated Support Line</li>
                            </ul>

                            <button onclick="initiateRazorpayPayment()" class="w-full btn-gold text-white font-black text-sm uppercase tracking-widest py-5 rounded-2xl flex items-center justify-center gap-3 group relative overflow-hidden">
                                <i class="fas fa-crown group-hover:scale-125 transition-transform duration-300"></i>
                                Actívate Membership
                                <div class="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-in-out"></div>
                            </button>

                            <p class="text-center text-[10px] text-slate-500 mt-6 font-medium uppercase tracking-widest">
                                Billed securely via Razorpay. Cancel anytime.
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <!-- Hidden Form for Processing Backend Activation -->
    <form id="vipForm" action="process_membership.php" method="POST" class="hidden">
        <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
        <input type="hidden" name="activate_vip" value="1">
        <input type="hidden" name="duration" id="plan_duration" value="monthly">
    </form>

    <script>
        let selectedPlan = 'monthly';
        let planPrice = <?= round($final_monthly_price * 100) ?>;

        const planDescriptions = {
            'monthly': "30-Day Elite Membership",
            '3months': "90-Day Elite Membership",
            '6months': "180-Day Elite Membership",
            'yearly': "365-Day Elite Membership"
        };

        function selectPlan(plan, price) {
            selectedPlan = plan;
            planPrice = price * 100;
            document.getElementById('plan_duration').value = plan;

            const plans = ['monthly', '3months', '6months', 'yearly'];
            plans.forEach(p => {
                const el = document.getElementById('plan-' + p);
                if (p === plan) {
                    el.classList.add('border-amber-500', 'bg-amber-500/10');
                    el.classList.remove('border-slate-700', 'bg-slate-800/50');
                } else {
                    el.classList.add('border-slate-700', 'bg-slate-800/50');
                    el.classList.remove('border-amber-500', 'bg-amber-500/10');
                }
            });
        }

        function initiateRazorpayPayment() {
            var options = {
                "key": "rzp_test_STse7euyhW8svg", // Using the provided test key
                "amount": planPrice, // Configurable INR in paise
                "currency": "INR",
                "name": "FOODIE'S HEAVEN VIP",
                "description": planDescriptions[selectedPlan],
                "image": "images/logo.png",
                "handler": function (response){
                    // Pass the payment ID to backend to finalize
                    document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
                    document.getElementById('vipForm').submit();
                },
                "prefill": {
                    "contact": "<?php echo $_SESSION['phone'] ?? ''; ?>"
                },
                "theme": {
                    "color": "#f59e0b"
                }
            };
            var rzp = new Razorpay(options);
            rzp.on('payment.failed', function (response){
                alert("Payment Failed. Reason: " + response.error.description);
            });
            rzp.open();
        }
    </script>
</body>
</html>
