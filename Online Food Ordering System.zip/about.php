<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

// Cart Count
$cart_count = 0;
if(isset($_SESSION['cart'])){
    $cart_count = count($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | FOODIE'S HEAVEN Restaurant</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #ff6b6b;
            --dark-color: #2d3436;
            --light-bg: #f9f9f9;
            --white: #ffffff;
            --transition: all 0.3s ease;
        }

        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: var(--light-bg);
            color: #444;
        }

        /* Navbar Modernization */
        .nav {
            background: var(--dark-color);
            padding: 15px 0;
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .nav a {
            color: #eee;
            margin: 0 20px;
            text-decoration: none;
            font-weight: 400;
            transition: var(--transition);
        }

        .nav a:hover {
            color: var(--primary-color);
        }

        .cart-count {
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            padding: 2px 7px;
            font-size: 11px;
            vertical-align: top;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80');
            background-size: cover;
            background-position: center;
            height: 350px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin: 0;
            text-shadow: 2px 2px 10px rgba(0,0,0,0.5);
        }

        /* Content Container */
        .container {
            max-width: 1100px;
            margin: -60px auto 40px auto;
            padding: 0 20px;
        }

        .about-card {
            background: var(--white);
            padding: 50px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            line-height: 1.8;
        }

        .section-title {
            color: var(--primary-color);
            font-size: 2rem;
            margin-bottom: 20px;
            position: relative;
            display: inline-block;
        }

        .section-title::after {
            content: '';
            width: 50px;
            height: 3px;
            background: var(--primary-color);
            position: absolute;
            bottom: -5px;
            left: 0;
        }

        /* Features Grid */
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-top: 40px;
        }

        .feature-item {
            padding: 30px;
            background: #fff;
            border-radius: 15px;
            text-align: center;
            border: 1px solid #eee;
            transition: var(--transition);
        }

        .feature-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(255,107,107,0.2);
            border-color: var(--primary-color);
        }

        .feature-item i {
            font-size: 40px;
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .feature-item h3 {
            margin: 10px 0;
            color: var(--dark-color);
        }

        /* Footer */
        .footer {
            background: var(--dark-color);
            color: #bbb;
            text-align: center;
            padding: 30px;
            font-size: 14px;
        }

        @media (max-width: 768px) {
            .hero h1 { font-size: 2rem; }
            .about-card { padding: 30px; }
        }
    </style>
</head>
<body>

<div class="nav">
    <a href="index.php"><i class="fas fa-home"></i> Home</a>
    <a href="cart.php">
        <i class="fas fa-shopping-cart"></i> Cart
        <?php if($cart_count > 0){ ?>
            <span class="cart-count"><?php echo $cart_count; ?></span>
        <?php } ?>
    </a>
    <a href="my_orders.php"><i class="fas fa-utensils"></i> My Orders</a>
    <a href="about.php" style="color: #ff6b6b;"><i class="fas fa-info-circle"></i> About Us</a>

    <?php if(isset($_SESSION['customer_id'])){ ?>
        <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    <?php } else { ?>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
    <?php } ?>
</div>

<div class="hero">
    <div>
        <h1>Taste the Tradition</h1>
        <p style="font-size: 1.2rem; opacity: 0.9;">Crafting memories through every plate since 2010.</p>
    </div>
</div>

<div class="container">
    <div class="about-card">
        <h2 class="section-title">Our Story</h2>
        <p>
            Welcome to <strong>FOODIE'S HEAVEN Restaurant</strong>, where culinary excellence meets the comfort of your home.
            Named after the Goddess of Food, we believe that every meal is a blessing. Our journey began with a simple
            vision: to serve authentic flavors made with the freshest local ingredients.
        </p>

        <p>
            Whether you are craving the spicy zest of <strong>Indian Curries</strong>, the wok-fired perfection of
            <strong>Chinese cuisine</strong>, or a quick <strong>Fast Food</strong> treat, our master chefs pour
            their heart into every dish. We don't just deliver food; we deliver an experience.
        </p>

        <div class="features">
            <div class="feature-item">
                <i class="fas fa-leaf"></i>
                <h3>Fresh Ingredients</h3>
                <p>We source daily from local farms to ensure 100% hygiene and health.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-shipping-fast"></i>
                <h3>Express Delivery</h3>
                <p>Hot food delivered to your doorstep within 30-45 minutes.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-smile-beam"></i>
                <h3>Customer First</h3>
                <p>Your satisfaction is our priority. We love making our guests happy!</p>
            </div>
        </div>

        <div style="margin-top: 40px; text-align: center;">
            <p style="font-style: italic; color: #777;">
                "Food is the ingredient that binds us together. Thank you for making us a part of your celebrations."
            </p>
        </div>
    </div>
</div>

<div class="footer">
    <div style="margin-bottom: 10px;">
        <i class="fab fa-facebook fa-lg" style="margin: 0 10px; cursor: pointer;"></i>
        <i class="fab fa-instagram fa-lg" style="margin: 0 10px; cursor: pointer;"></i>
        <i class="fab fa-twitter fa-lg" style="margin: 0 10px; cursor: pointer;"></i>
    </div>
    &copy; <?php echo date("Y"); ?> FOODIE'S HEAVEN Restaurant | Designed with ❤️ for Food Lovers
</div>

</body>
</html>