<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "information_schema");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$db_name = "online_food";
$query = "SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY, EXTRA, COLUMN_COMMENT 
          FROM COLUMNS 
          WHERE TABLE_SCHEMA = '$db_name' 
          ORDER BY TABLE_NAME, ORDINAL_POSITION";

$result = $conn->query($query);
if (!$result) {
    die("Query failed: " . $conn->error);
}

$current_table = "";
echo "# Data Dictionary: ". $db_name ."\n\n";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row['TABLE_NAME'] !== $current_table) {
            if ($current_table !== "") {
                echo "\n";
            }
            $current_table = $row['TABLE_NAME'];
            echo "## Table: `" . $current_table . "`\n\n";
            echo "| Field | Type | Null | Key | Default | Extra | Parameters |\n";
            echo "|-------|------|------|-----|---------|-------|------------|\n";
        }
        
        $type = $row['DATA_TYPE'];
        if (!empty($row['CHARACTER_MAXIMUM_LENGTH'])) {
            $type .= "(" . $row['CHARACTER_MAXIMUM_LENGTH'] . ")";
        }
        
        $default = $row['COLUMN_DEFAULT'] ?? "NULL";
        if ($default === "") $default = "''";
        
        echo "| `" . $row['COLUMN_NAME'] . "` | " . $type . " | " . $row['IS_NULLABLE'] . " | " . $row['COLUMN_KEY'] . " | " . $default . " | " . $row['EXTRA'] . " | " . $row['COLUMN_COMMENT'] . " |\n";
    }
} else {
    echo "No tables found in database " . $db_name;
}
$conn->close();
?>
