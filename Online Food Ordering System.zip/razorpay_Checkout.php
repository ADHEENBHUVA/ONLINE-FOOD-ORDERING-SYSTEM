<?php
session_start();
require_once "db.php";

// Check if checkout data exists
if (!isset($_SESSION['checkout_data'])) {
    echo "<script>alert('Invalid request'); window.location='checkout.php';</script>";
    exit();
}

$data = $_SESSION['checkout_data'];
$total = $data['total'];
$name = $data['customer_name'];
$phone = $data['customer_phone'];

// ----- CREATE RAZORPAY ORDER (Server-side) -----
$razorpay_key_id = "rzp_test_STse7euyhW8svg";   // <-- Replace with your Razorpay Key ID
$razorpay_key_secret = "KtWCW1A52jeG5eED2HCzkdxx";    // <-- Replace with your Razorpay Key Secret

// Create order using Razorpay Orders API
$orderData = [
    'receipt' => 'order_' . time(),
    'amount' => $total * 100,   // amount in paise
    'currency' => 'INR'
];

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_USERPWD, $razorpay_key_id . ':' . $razorpay_key_secret);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($orderData));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$razorpayOrder = json_decode($response, true);
$razorpay_order_id = $razorpayOrder['id'] ?? '';
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Payment - FOODIE'S HEAVEN</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background: #f4f9ff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .payment-box {
            background: #fff;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 420px;
            width: 90%;
        }

        .payment-box h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .payment-box .amount {
            font-size: 32px;
            font-weight: 700;
            color: #ff1493;
            margin: 15px 0;
        }

        .payment-box p {
            color: #666;
            margin-bottom: 20px;
        }

        .pay-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(to right, #87CEEB, #FF69B4);
            color: #fff;
            border: none;
            border-radius: 25px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.2s;
        }

        .pay-btn:hover {
            opacity: 0.85;
        }

        .cancel-link {
            display: inline-block;
            margin-top: 15px;
            color: #999;
            text-decoration: none;
            font-size: 14px;
        }

        .cancel-link:hover {
            color: #ff4d4d;
        }

        .secure-badge {
            margin-top: 20px;
            font-size: 12px;
            color: #aaa;
        }
    </style>
</head>

<body>

    <div class="payment-box">
        <h2>🔒 Secure Payment</h2>
        <p>FOODIE'S HEAVEN</p>
        <div class="amount">₹<?php echo number_format($total, 2); ?></div>
        <p>Pay securely via Razorpay</p>

        <div style="margin: 15px 0;">
            <input type="text" id="test_upi_id" placeholder="Test UPI ID (e.g. success@razorpay)" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; text-align: center;">
            <div class="secure-badge" style="margin-top: 5px;">Use <b>success@razorpay</b> for testing</div>
        </div>

        <button id="payBtn" class="pay-btn">Pay Now ₹<?php echo number_format($total, 2); ?></button>

        <br>
        <a href="checkout.php" class="cancel-link">← Cancel & Go Back</a>

        <div class="secure-badge">🔐 Secured by Razorpay | 100% Safe</div>
    </div>

    <!-- Razorpay JS SDK -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>

    <script>
        document.getElementById('payBtn').addEventListener('click', function () {
            
            var testUpi = document.getElementById('test_upi_id').value;

            var options = {
                "key": "<?php echo $razorpay_key_id; ?>",
                "amount": "<?php echo $total * 100; ?>",
                "currency": "INR",
                "name": "FOODIE'S HEAVEN",
                "description": "Order Payment",
                "order_id": "<?php echo $razorpay_order_id; ?>",
                "prefill": {
                    "name": "<?php echo addslashes($name); ?>",
                    "contact": "<?php echo addslashes($phone); ?>"
                },
                "theme": {
                    "color": "#FF69B4"
                },
                "handler": function (response) {
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'payment_success.php';

                    var fields = {
                        'razorpay_payment_id': response.razorpay_payment_id,
                        'razorpay_order_id': response.razorpay_order_id,
                        'razorpay_signature': response.razorpay_signature
                    };

                    for (var key in fields) {
                        var input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = key;
                        input.value = fields[key];
                        form.appendChild(input);
                    }

                    document.body.appendChild(form);
                    form.submit();
                },
                "modal": {
                    "ondismiss": function () {}
                }
            };
            
            // Apply UPI prefill if user entered a test ID
            if (testUpi.trim() !== '') {
                options.prefill.method = 'upi';
                options.prefill.vpa = testUpi;
            }

            var rzp = new Razorpay(options);
            rzp.open();
        });
    </script>

</body>

</html>