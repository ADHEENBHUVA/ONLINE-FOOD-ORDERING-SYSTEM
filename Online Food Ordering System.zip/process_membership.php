<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['activate_vip'])) {
    $customer_id = $_SESSION['customer_id'];
    $payment_id = $_POST['razorpay_payment_id'] ?? 'SIMULATED_'.rand(1000,9999);
    $duration = $_POST['duration'] ?? 'monthly';

    // Set expiry
    if ($duration === 'yearly') {
        $expiry_date = date('Y-m-d', strtotime('+365 days'));
    } else if ($duration === '6months') {
        $expiry_date = date('Y-m-d', strtotime('+180 days'));
    } else if ($duration === '3months') {
        $expiry_date = date('Y-m-d', strtotime('+90 days'));
    } else {
        $expiry_date = date('Y-m-d', strtotime('+30 days'));
    }

    // Update Customer Profile
    $stmt = $conn->prepare("UPDATE customers SET is_vip = 1, membership_expiry = ?, membership_date = NOW() WHERE customer_id = ?");
    $stmt->bind_param("si", $expiry_date, $customer_id);

    if ($stmt->execute()) {
        $_SESSION['success_msg'] = "Welcome to the VIP Elite Tier! Your membership is active.";
        header("Location: profile.php");
        exit();
    } else {
        echo "Database Error: " . $conn->error;
    }
} else {
    // If accessed directly without POST
    header("Location: membership.php");
    exit();
}
?>
