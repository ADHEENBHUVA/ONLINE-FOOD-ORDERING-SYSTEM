<?php
session_set_cookie_params(86400 * 30);
session_start();
include("db.php");

/* ================= 1. SECURITY & CART CHECK ================= */
if (!isset($_SESSION['customer_id']) || empty($_SESSION['cart'])) {
    header("Location: login.php");
    exit();
}
$customer_id = $_SESSION['customer_id'];

/* ================= 2. DATA FETCH ================= */
$user_query = $conn->query("SELECT is_vip, membership_expiry, address_km, email FROM customers WHERE customer_id='$customer_id'");
$user = $user_query->fetch_assoc();

$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += ($item['price'] * $item['quantity']);
}

/* ================= 3. PROMO VALIDATION LOGIC ================= */
$promo_discount = 0;
$promo_error = "";

if (isset($_SESSION['applied_promo'])) {
    $applied_code = $_SESSION['applied_promo']['promo_code'];

    // CHECK 1: Has user EVER used this specific code?
    $usage_history = $conn->query("SELECT order_id FROM orders WHERE customer_id='$customer_id' AND promo_used='$applied_code'");

    // CHECK 2: If code is FIRST_USER, does the user have ANY previous orders?
    $promo_details = $conn->query("SELECT type FROM promo_codes WHERE promo_code='$applied_code'")->fetch_assoc();
    $total_orders_count = $conn->query("SELECT COUNT(*) as total FROM orders WHERE customer_id='$customer_id'")->fetch_assoc()['total'];

    if ($usage_history->num_rows > 0) {
        $promo_error = "You have already used this promo code once!";
        unset($_SESSION['applied_promo']);
    } else if (isset($promo_details['type']) && $promo_details['type'] == 'FIRST_USER' && $total_orders_count > 0) {
        $promo_error = "The code '$applied_code' is only valid for your first order!";
        unset($_SESSION['applied_promo']);
    } else {
        $promo_discount = ($subtotal * $_SESSION['applied_promo']['discount_percent']) / 100;
    }
}

/* ================= 4. LOGISTICS & TOTALS ================= */
$settings_res = $conn->query("SELECT * FROM delivery_settings WHERE id=1");
$rules = $settings_res->fetch_assoc();

$is_vip = ($user && $user['is_vip'] == 1 && ($user['membership_expiry'] ?? '') >= date('Y-m-d')) ? 1 : 0;

/* ================= VIP DISCOUNT LOGIC ================= */
$vip_discount = 0;
$vip_discount_type_applied = '';
if ($is_vip && $subtotal >= ($rules['vip_min_order_for_discount'] ?? 0)) {
    $discount_type = $rules['vip_discount_type'] ?? 'percentage';

    if ($discount_type == 'percentage') {
        $percent_val = ($subtotal * ($rules['vip_discount_percent'] ?? 0)) / 100;
        if ($percent_val > 0) {
            $vip_discount = $percent_val;
            $vip_discount_type_applied = '(Percentage)';
        }
    } else if ($discount_type == 'rupees') {
        $flat_val = $rules['vip_discount_rupees'] ?? 0;
        if ($flat_val > 0) {
            $vip_discount = min($subtotal, $flat_val);
            $vip_discount_type_applied = '(Flat)';
        }
    }
}

// General Customer Delivery Fee Logic
$delivery_fee = 0;
if (!$is_vip) {
    if ($subtotal < ($rules['gen_min_order_free'] ?? 500)) {
        $gen_type = $rules['gen_delivery_type'] ?? 'fixed';
        if ($gen_type == 'km') {
            $user_km = (float) ($user['address_km'] ?? 0);
            $free_km = (float) ($rules['gen_free_km'] ?? 0);
            $charge_km = (float) ($rules['gen_charge_per_km'] ?? 0);

            if ($user_km > $free_km) {
                $delivery_fee = ($user_km - $free_km) * $charge_km;
            } else {
                $delivery_fee = 0;
            }
        } else {
            // Fixed mode
            $delivery_fee = $rules['gen_delivery_fee'] ?? 40;
        }
    }
}
// VIP Delivery is always Free.

$total_discount = $promo_discount + $vip_discount;
$grand_total = ($subtotal - $total_discount) + $delivery_fee;

/* ================= 5. RAZORPAY ORDER CREATION ================= */
$razorpay_key_id = "rzp_test_STse7euyhW8svg";
$razorpay_secret = "KtWCW1A52jeG5eED2HCzkdxx";
$razorpay_order_id = "";

if ($grand_total > 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.razorpay.com/v1/orders");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'amount' => round($grand_total * 100),
        'currency' => 'INR',
        'receipt' => 'rcpt_' . time()
    ]));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_USERPWD, $razorpay_key_id . ':' . $razorpay_secret);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $result = curl_exec($ch);
    $order_data = json_decode($result);
    if (isset($order_data->id)) {
        $razorpay_order_id = $order_data->id;
    }
    curl_close($ch);
}

/* ================= 6. PLACE ORDER HANDLER ================= */
if (isset($_POST['final_place_order'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    if (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        echo "<script>alert('Invalid name! Only alphabets and spaces are allowed.'); window.history.back();</script>";
        exit();
    }
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    if (!preg_match('/^[0-9]{10}$/', $phone)) {
        echo "<script>alert('Invalid phone number! Please enter exactly 10 digits.'); window.history.back();</script>";
        exit();
    }
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    if (isset($_POST['city']) && !empty($_POST['city'])) {
        $city = mysqli_real_escape_string($conn, $_POST['city']);
        $address = $address . ', ' . $city;
    }
    if (isset($_POST['pincode']) && !empty($_POST['pincode'])) {
        $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
        $address = $address . ' - ' . $pincode;
    }
    $payment_method = $_POST['payment'];
    $rzp_payment_id = $_POST['razorpay_payment_id'] ?? '';
    $final_promo_code = isset($_SESSION['applied_promo']) ? $_SESSION['applied_promo']['promo_code'] : null;

    if (!empty($rzp_payment_id)) {
        $payment_method .= " (Paid - TXN: $rzp_payment_id)";
    }

    $sql = "INSERT INTO orders (customer_id, customer_name, phone, address, total_amount, discount_amount, delivery_fee, payment_method, order_status, order_date, promo_used)
            VALUES ('$customer_id','$name','$phone','$address','$grand_total','$total_discount','$delivery_fee','$payment_method','Pending',NOW(), " . ($final_promo_code ? "'$final_promo_code'" : "NULL") . ")";

    if ($conn->query($sql)) {
        $order_id = $conn->insert_id;
        foreach ($_SESSION['cart'] as $item) {
            $fid = $item['food_id'];
            $pr = $item['price'];
            $qty = $item['quantity'];
            $conn->query("INSERT INTO order_items (order_id, food_id, quantity, price) VALUES('$order_id','$fid','$qty','$pr')");
        }
        unset($_SESSION['cart'], $_SESSION['applied_promo']);

        // Notification Trigger: Admin only upon confirmation
        addNotification($conn, null, 'admin', "New Order #$order_id placed and is pending approval.", $order_id);

        // --- EMAIL NOTIFICATIONS ---
        require_once "email_helper.php";
        $customer_email = $user['email'] ?? '';
        
        // 1. Email to Customer
        if (!empty($customer_email)) {
            $cust_subject = "Order Placed Successfully! (Order #$order_id)";
            $cust_body = "<h3>Hello $name,</h3>
                          <p>Your order (<strong>#$order_id</strong>) has been successfully placed.</p>
                          <p><strong>Total Amount:</strong> ₹" . number_format($grand_total, 2) . "</p>
                          <p><strong>Delivery Address:</strong> $address</p>
                          <p>We will notify you once your order is picked up for delivery.</p>";
            sendOrderEmail($customer_email, $cust_subject, $cust_body);
        }

        // 2. Email to Admin
        $admin_subject = "New Order Received! (Order #$order_id)";
        $admin_body = "<h3>Admin Alert: New Order</h3>
                       <p>A new order (<strong>#$order_id</strong>) has been placed by <strong>$name</strong>.</p>
                       <p><strong>Amount:</strong> ₹" . number_format($grand_total, 2) . "</p>
                       <p><strong>Status:</strong> Pending Approval</p>
                       <p>Please check the admin dashboard to process this order.</p>";
        sendOrderEmail(ADMIN_EMAIL, $admin_subject, $admin_body);
        // ---------------------------

        echo "<script>alert('Executive Order Placed Successfully!'); window.location='index.php';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VIP Checkout | Foodie's Heaven</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            overflow-x: hidden;
        }

        .bg-royal-mesh {
            background-image: radial-gradient(at 0% 0%, hsla(28, 100%, 74%, 0.1) 0px, transparent 50%), radial-gradient(at 100% 100%, hsla(210, 100%, 80%, 0.1) 0px, transparent 50%);
            background-color: #f8fafc;
        }

        .glass-nav {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .exec-card {
            background: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 2rem;
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
        }

        .input-luxe {
            background: #f8fafc;
            border: 2px solid #f1f5f9;
            border-radius: 1.5rem;
            padding: 1.25rem 1.25rem 1.25rem 3.5rem;
            transition: 0.3s;
            width: 100%;
            outline: none;
            font-weight: 700;
            color: #1e293b;
        }

        .input-luxe:focus {
            border-color: #f97316;
            background: #ffffff;
            box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.1);
        }

        /* Modern Selectors */
        .pay-radio:checked+.pay-box {
            border-color: #0f172a;
            background: #0f172a;
            color: white;
            transform: scale(1.02);
            box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.2);
        }

        .pay-radio:checked+.pay-box .icon {
            color: #f97316;
        }

        .pay-box {
            border: 2px solid #f1f5f9;
            background: #ffffff;
            transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
            border-radius: 1.5rem;
            color: #64748b;
        }

        .pay-box:hover {
            border-color: #cbd5e1;
            background: #f8fafc;
            transform: translateY(-3px);
        }

        .step-pill {
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f97316;
            color: white;
            border-radius: 1rem;
            font-size: 1.25rem;
            font-weight: 900;
            box-shadow: 0 10px 15px -3px rgba(249, 115, 22, 0.3);
        }

        .receipt-bg {
            background: linear-gradient(145deg, #0f172a, #1e293b);
            color: white;
            border-radius: 2rem;
        }
    </style>
</head>

<body class="bg-royal-mesh pt-28 pb-20 min-h-screen">

    <nav class="glass-nav fixed w-full top-0 z-50 py-4 px-6 md:px-12 relative shadow-sm">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <a href="cart.php"
                class="text-slate-500 hover:text-orange-500 text-sm font-bold flex items-center gap-3 bg-slate-100 hover:bg-orange-50 px-5 py-2.5 rounded-full transition-colors">
                <i class="fas fa-arrow-left"></i> Return to Cart
            </a>
            <div class="flex items-center gap-3">
                <i class="fas fa-shield-halved text-orange-500 text-xl"></i>
                <span class="font-900 tracking-tighter text-slate-800 uppercase italic">Encrypted Connection</span>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">

        <?php if (!empty($promo_error)): ?>
            <div
                class="mb-10 max-w-4xl mx-auto p-5 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl flex items-center justify-center gap-4 animate-pulse shadow-sm">
                <div class="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center"><i
                        class="fas fa-exclamation-circle text-rose-500 text-xl"></i></div>
                <span class="font-bold text-sm"><?php echo $promo_error; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" id="orderForm" class="flex flex-col lg:flex-row gap-10 lg:gap-14">

            <!-- Main Form Area -->
            <div class="flex-1 space-y-10">
                <div class="mb-6">
                    <h1 class="text-4xl md:text-5xl font-900 tracking-tighter text-slate-900 italic">VIP <span
                            class="text-orange-500">Checkout.</span></h1>
                    <p class="text-slate-500 font-medium">Finalize your delivery details to complete the order.</p>
                </div>

                <!-- STEP 1: Delivery Details -->
                <div class="exec-card p-6 sm:p-10 relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl"></div>

                    <div class="flex items-center gap-4 mb-8 relative z-10">
                        <span class="step-pill">1</span>
                        <h3 class="text-3xl font-900 tracking-tight text-slate-800">Logistics</h3>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                        <div class="relative group">
                            <label
                                class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-2 transition-colors group-focus-within:text-orange-500">Full
                                Name</label>
                            <i
                                class="fas fa-user absolute left-5 top-[2.6rem] text-slate-400 group-focus-within:text-orange-500 transition-colors"></i>
                            <input type="text" name="name" id="cust_name" required oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');" class="input-luxe"
                                placeholder="e.g. Gordon Ramsay" value="<?= htmlspecialchars($user['name'] ?? '') ?>">
                            <div
                                class="absolute right-4 top-[2.6rem] w-6 h-6 bg-emerald-100 text-emerald-500 rounded-full flex items-center justify-center opacity-0 transition-opacity">
                                <i class="fas fa-check text-[10px]"></i>
                            </div>
                        </div>

                        <div class="relative group">
                            <label
                                class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-2 transition-colors group-focus-within:text-orange-500">Contact
                                Number</label>
                            <i
                                class="fas fa-phone absolute left-5 top-[2.6rem] text-slate-400 group-focus-within:text-orange-500 transition-colors"></i>
                            <input type="tel" name="phone" id="cust_phone" required maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');" class="input-luxe"
                                placeholder="+91 ..." value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                        </div>

                        <div class="md:col-span-2 relative group mt-2">
                            <div class="flex justify-between items-end mb-2 ml-2 pr-2">
                                <label
                                    class="block text-[10px] font-black uppercase text-slate-400 transition-colors group-focus-within:text-orange-500">Delivery
                                    Address</label>
                            </div>
                            <i
                                class="fas fa-map-marker-alt absolute left-5 top-[3.2rem] text-slate-400 group-focus-within:text-orange-500 transition-colors"></i>
                            <textarea name="address" id="cust_address" required
                                class="input-luxe resize-none pt-[1.1rem]" rows="3"
                                placeholder="Enter Full Property Address..."></textarea>
                        </div>

                        <div class="relative group mt-2">
                            <label
                                class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-2 transition-colors group-focus-within:text-orange-500">City
                                Name</label>
                            <i
                                class="fas fa-city absolute left-5 top-[2.6rem] text-slate-400 group-focus-within:text-orange-500 transition-colors"></i>
                            <input type="text" name="city" id="cust_city" required class="input-luxe"
                                placeholder="e.g. Mumbai">
                        </div>

                        <div class="relative group mt-2">
                            <label
                                class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-2 transition-colors group-focus-within:text-orange-500">Pincode</label>
                            <i
                                class="fas fa-map-pin absolute left-5 top-[2.6rem] text-slate-400 group-focus-within:text-orange-500 transition-colors"></i>
                            <input type="text" name="pincode" id="cust_pincode" required class="input-luxe"
                                placeholder="e.g. 400001">
                        </div>
                    </div>
                </div>

                <!-- STEP 2: Payment Method -->
                <div class="exec-card p-6 sm:p-10 relative overflow-hidden">
                    <div class="absolute bottom-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl"></div>

                    <div class="flex items-center gap-4 mb-10 relative z-10">
                        <span class="step-pill">2</span>
                        <h3 class="text-3xl font-900 tracking-tight text-slate-800">Financial Setup</h3>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 relative z-10">
                        <label>
                            <input type="radio" name="payment" value="Razorpay Card" class="hidden pay-radio" checked
                                onclick="toggleOnlineArea(true); document.getElementById('upi_test_box').style.display='none';">
                            <div class="pay-box">
                                <i class="fa fa-credit-card text-3xl mb-3 icon transition-colors duration-300"></i>
                                <p class="font-black text-[11px] uppercase tracking-widest text-inherit">Bank Card</p>
                            </div>
                        </label>
                        <label>
                            <input type="radio" name="payment" value="Razorpay UPI" class="hidden pay-radio"
                                onclick="toggleOnlineArea(true); document.getElementById('upi_test_box').style.display='block';">
                            <div class="pay-box">
                                <i
                                    class="fa-brands fa-google-pay text-4xl mb-3 icon transition-colors duration-300"></i>
                                <p class="font-black text-[11px] uppercase tracking-widest text-inherit">UPI Fast</p>
                            </div>
                        </label>
                    </div>

                    <div id="upi_test_box" class="mt-6 p-5 bg-slate-50 border border-slate-200 rounded-[1rem] shadow-sm relative z-10" style="display:none;">
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Test UPI ID</label>
                        <input type="text" id="checkout_test_upi" class="input-luxe bg-white" placeholder="e.g. success@razorpay">
                        <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-2 ml-1"><i class="fa fa-info-circle mr-1"></i> Testing bypass for Developer Mode</p>
                    </div>

                    <div id="online_info"
                        class="mt-6 p-6 bg-slate-900 rounded-[1.5rem] flex items-center gap-5 shadow-inner border border-slate-800 relative z-10"
                        style="display:flex;">
                        <div
                            class="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-emerald-400 shadow-lg border border-slate-700 shrink-0">
                            <i class="fa fa-lock text-lg"></i>
                        </div>
                        <div>
                            <h4 class="text-white font-bold text-sm mb-0.5">Razorpay Vault Enabled</h4>
                            <p class="text-xs font-medium text-slate-400">Card details are encrypted globally via
                                PCI-DSS layer.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Receipt Area (Right Side) -->
            <div class="w-full lg:w-[420px] 2xl:w-[460px]">
                <div class="receipt-bg p-8 lg:p-10 sticky top-28 shadow-2xl relative overflow-hidden group">
                    <!-- Receipt Decals -->
                    <div
                        class="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full blur-3xl group-hover:bg-orange-500/10 transition-colors duration-700">
                    </div>
                    <div
                        class="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 via-rose-500 to-indigo-500">
                    </div>

                    <h3
                        class="text-3xl font-900 uppercase italic tracking-tight mb-10 border-b border-white/10 pb-6 text-white flex justify-between items-center">
                        Invoice
                        <i class="fas fa-file-invoice text-slate-600 text-3xl"></i>
                    </h3>

                    <div class="space-y-6 mb-10 pb-10 border-b border-dashed border-white/20">
                        <div class="flex justify-between items-center text-slate-300 font-bold text-sm">
                            <span>Cart Evaluation</span>
                            <span
                                class="text-white font-black text-lg">&#8377;<?= number_format($subtotal, 2); ?></span>
                        </div>

                        <?php if ($promo_discount > 0): ?>
                            <div
                                class="flex justify-between items-center text-emerald-400 font-bold text-sm bg-emerald-400/10 p-4 rounded-xl border border-emerald-400/20">
                                <span class="flex items-center gap-2"><i class="fas fa-percent"></i> Voucher Claimed</span>
                                <span class="font-black">- &#8377;<?= number_format($promo_discount, 2); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if (isset($vip_discount) && $vip_discount > 0): ?>
                            <div
                                class="flex justify-between items-center text-amber-400 font-bold text-sm bg-amber-400/10 p-4 rounded-xl border border-amber-400/20">
                                <span class="flex items-center gap-2"><i class="fas fa-crown"></i> VIP Privilege
                                    <?= $vip_discount_type_applied ?></span>
                                <span class="font-black">- &#8377;<?= number_format($vip_discount, 2); ?></span>
                            </div>
                        <?php endif; ?>

                        <div class="flex justify-between items-center text-slate-300 font-bold text-sm">
                            <span>Logistics Fee</span>
                            <?php if ($delivery_fee == 0): ?>
                                <span
                                    class="text-emerald-400 font-black px-2 py-1 bg-emerald-400/10 rounded uppercase text-[10px] tracking-widest">Complimentary</span>
                            <?php else: ?>
                                <span class="text-white font-black">&#8377;<?= number_format($delivery_fee, 2); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-12">
                        <p
                            class="text-[10px] font-black uppercase text-orange-500 tracking-[0.2em] mb-2 drop-shadow-sm">
                            Total Execution Amount</p>
                        <h2 class="text-5xl font-900 tracking-tighter text-white drop-shadow-md">
                            &#8377;<?= number_format($grand_total, 2); ?></h2>
                    </div>

                    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
                    <input type="hidden" name="final_place_order" value="1">

                    <button type="button" onclick="handleCheckout()"
                        class="relative group/btn overflow-hidden w-full bg-orange-500 text-white py-6 rounded-2xl font-black uppercase text-sm tracking-[0.2em] shadow-[0_20px_40px_-10px_rgba(249,115,22,0.4)] transition-all active:scale-95 border border-orange-400">
                        <div
                            class="absolute inset-0 bg-white/20 translate-y-[100%] group-hover/btn:translate-y-0 transition-transform duration-300 ease-out">
                        </div>
                        <span class="relative z-10 flex items-center justify-center gap-3">Secure Execution <i
                                class="fas fa-lock"></i></span>
                    </button>

                    <div class="mt-8 flex flex-col items-center justify-center gap-2 text-slate-500">
                        <img src="./images/razorpay-logo.png" style="height:24px;" alt="Razorpay">
                        <span class="text-[8px] font-black uppercase tracking-[0.4em] opacity-60">Level 1 PCI
                            Compliant</span>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script>
        function toggleOnlineArea(show) {
            document.getElementById('online_info').style.display = show ? 'flex' : 'none';
        }

        function handleCheckout() {
            const paymentMethod = document.querySelector('input[name="payment"]:checked').value;
            const name = document.getElementById('cust_name').value;
            const phone = document.getElementById('cust_phone').value;
            const address = document.getElementById('cust_address').value;
            const city = document.getElementById('cust_city').value;
            const pincode = document.getElementById('cust_pincode').value;

            if (!name || !phone || !address || !city || !pincode) {
                alert("⚠️ Please complete the Logistics details perfectly.");
                return;
            }

            if (paymentMethod.includes("Razorpay")) {
                const orderId = "<?= $razorpay_order_id ?>";
                const apiKey = "<?= $razorpay_key_id ?>";
                const amountPaise = <?= round($grand_total * 100) ?>;

                if (!orderId) {
                    alert("Critical System Interruption: Secure gateway unavailable.");
                    return;
                }

                const options = {
                    "key": apiKey,
                    "amount": amountPaise,
                    "currency": "INR",
                    "name": "FOODIE'S HEAVEN",
                    "description": "Premium Order Transaction",
                    "order_id": orderId,
                    "handler": function (response) {
                        document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
                        document.getElementById('orderForm').submit();
                    },
                    "prefill": { 
                        "name": name, 
                        "contact": phone,
                        "method": (paymentMethod === "Razorpay UPI") ? "upi" : "card"
                    },
                    "theme": { "color": "#0f172a" },
                    "modal": { "backdrop_color": "rgba(15, 23, 42, 0.9)" }
                };
                
                const testUpiInput = document.getElementById('checkout_test_upi').value;
                if (paymentMethod === "Razorpay UPI" && testUpiInput.trim() !== '') {
                    options.prefill.vpa = testUpiInput.trim();
                }

                const rzp = new Razorpay(options);
                rzp.open();
            } else {
                alert("Only secure digital payments are supported.");
            }
        }

    </script>

</body>

</html>