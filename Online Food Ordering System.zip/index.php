<?php
session_set_cookie_params(86400 * 30);
session_start();
$conn = new mysqli("localhost", "root", "", "online_food");
if ($conn->connect_error) { die("Connection Failed: " . $conn->connect_error); }

if (isset($_POST['ajax_add_to_cart'])) {
    $food_id = $_POST['food_id'];
    $quantity = (int)$_POST['quantity'];
    $sql = "SELECT * FROM food_items WHERE food_id='$food_id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if ($row) {
        if (!isset($_SESSION['cart'])) { $_SESSION['cart'] = array(); }
        if (isset($_SESSION['cart'][$food_id])) {
            $_SESSION['cart'][$food_id]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$food_id] = array(
                "food_id"   => $row['food_id'],
                "food_name" => $row['food_name'],
                "price"     => $row['price'],
                "image"     => $row['image'],
                "quantity"  => $quantity
            );
        }
        header('Content-Type: application/json');
        echo json_encode(["status" => "success", "cart_count" => count($_SESSION['cart'])]);
        exit();
    }
    echo json_encode(["status" => "error"]);
    exit();
}

$today = date("Y-m-d");
$discount = null;
$discount_sql = "SELECT * FROM promo_codes WHERE status='Active' AND valid_from <= '$today' AND valid_to >= '$today' LIMIT 1";
$discount_result = mysqli_query($conn, $discount_sql);
if($discount_result) { $discount = mysqli_fetch_assoc($discount_result); }

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : "";
$where = " WHERE status='Available' ";
if($search != "") { $where .= " AND food_name LIKE '%$search%'"; }
if(isset($_GET['category_id']) && $_GET['category_id'] != ""){
    $category_id = intval($_GET['category_id']);
    $where .= " AND category_id = $category_id";
}

$categories = $conn->query("SELECT * FROM categories WHERE status='Active'");

$foods_query = "
    SELECT f.*, 
           (SELECT AVG(fb.rating) FROM feedback fb JOIN order_items oi ON fb.order_id = oi.order_id WHERE oi.food_id = f.food_id) as avg_rating,
           (SELECT COUNT(DISTINCT fb.feedback_id) FROM feedback fb JOIN order_items oi ON fb.order_id = oi.order_id WHERE oi.food_id = f.food_id) as rev_count
    FROM food_items f
    $where
";
$foods = $conn->query($foods_query);

$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foodie's Heaven | Premium Delivery</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #fafafa;
            color: #0f172a;
            -webkit-font-smoothing: antialiased;
        }

        .glass-nav {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.5);
            transition: all 0.4s ease;
        }

        .glass-nav.scrolled {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 10px 40px -10px rgba(0,0,0,0.08);
        }

        .hero-section {
            background-image: url('https://images.unsplash.com/photo-1543353071-873f17a7a088?q=80&w=2070&auto=format&fit=crop');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            position: relative;
        }

        .hero-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to right, rgba(15, 23, 42, 0.95) 0%, rgba(15, 23, 42, 0.4) 100%);
        }

        .food-card {
            background: #ffffff;
            border-radius: 2rem;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            outline: 1px solid transparent;
        }
        .food-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 30px 60px -15px rgba(0,0,0,0.1);
            outline: 1px solid rgba(249, 115, 22, 0.3);
        }

        .smooth-btn {
            transition: all 0.3s ease;
        }
        .smooth-btn:active {
            transform: scale(0.95);
        }

        .img-hover img {
            transition: transform 0.7s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .img-hover:hover img {
            transform: scale(1.08);
        }

        .category-pill {
            transition: all 0.3s;
        }
        .category-pill.active {
            background: #0f172a;
            color: #ffffff;
            box-shadow: 0 10px 20px -5px rgba(15, 23, 42, 0.4);
        }
        .category-pill:not(.active):hover {
            background: #f1f5f9;
        }

        /* Toast */
        #toast {
            position: fixed;
            bottom: -100px;
            left: 50%;
            transform: translateX(-50%);
            background: #0f172a;
            color: white;
            padding: 16px 24px;
            border-radius: 100px;
            font-weight: 700;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
            transition: bottom 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
            z-index: 9999;
        }
        #toast.show {
            bottom: 40px;
        }

        .qty-stepper button {
            transition: all 0.2s;
        }
        .qty-stepper button:hover {
            color: #f97316;
        }

        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>
<body>

<div id="toast">
    <div class="bg-orange-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">
        <i class="fas fa-check"></i>
    </div>
    <span>Item added to your selection</span>
</div>

<nav id="main-nav" class="glass-nav fixed w-full top-0 z-50 py-4 px-6 md:px-12">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
        <!-- Logo -->
        <a href="index.php" class="flex items-center gap-3 group">
            <div class="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:bg-orange-600 transition-colors">
                <i class="fas fa-leaf text-white text-lg"></i>
            </div>
            <span class="text-xl font-900 tracking-tighter text-slate-900">Foodie's <span class="text-orange-500 italic">Heaven.</span></span>
        </a>

        <!-- Desktop Links -->
        <div class="hidden lg:flex items-center gap-8">
            <a href="index.php" class="text-sm font-bold text-orange-500 transition-colors">Discover</a>
            <a href="my_orders.php" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">Live Tracking</a>
            <?php if(isset($_SESSION['customer_id'])): ?>
                <a href="profile.php" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">My Profile</a>
                <a href="logout.php" class="text-sm font-bold text-slate-400 hover:text-rose-500 transition-colors">Sign Out</a>
            <?php else: ?>
                <a href="login.php" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">Log In</a>
                <a href="register.php" class="text-sm font-bold px-5 py-2 bg-slate-100 rounded-full hover:bg-slate-200 transition-colors text-slate-800">Sign Up</a>
            <?php endif; ?>
        </div>

        <!-- Notifications & Cart -->
        <div class="flex items-center gap-4">
            <?php if(isset($_SESSION['customer_id'])):
                $cust_id = $_SESSION['customer_id'];
                $unread_q = $conn->query("SELECT * FROM notifications WHERE user_id='$cust_id' AND user_type='customer' AND is_read=0 ORDER BY created_at DESC LIMIT 20");
                $unread_count = $unread_q->num_rows;
            ?>
                <div class="relative group">
                    <button class="w-11 h-11 bg-white border border-slate-200 rounded-xl flex items-center justify-center text-slate-600 hover:text-orange-500 hover:border-orange-200 transition-all shadow-sm">
                        <i class="fas fa-bell"></i>
                        <?php if($unread_count > 0): ?>
                            <span class="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white animate-pulse"><?= $unread_count ?></span>
                        <?php endif; ?>
                    </button>
                    <!-- Dropdown -->
                    <div class="absolute right-0 mt-3 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 p-4">
                        <div class="flex items-center justify-between mb-4 pb-2 border-b border-slate-50">
                            <h4 class="text-sm font-900 uppercase tracking-tight">Alerts Feed</h4>
                            <?php if($unread_count > 0): ?>
                                <a href="clear_notifications.php?type=customer" class="text-[10px] font-black uppercase text-orange-500 hover:underline">Clear All</a>
                            <?php endif; ?>
                        </div>
                        <div class="space-y-3 max-h-[200px] overflow-y-auto custom-scrollbar pr-2">
                            <?php if($unread_count == 0): ?>
                                <p class="text-xs text-slate-400 font-medium text-center py-4">No new alerts for you.</p>
                            <?php else: ?>
                                <?php while($n = $unread_q->fetch_assoc()): ?>
                                    <a href="my_orders.php" class="block p-3 bg-slate-50 rounded-xl border border-slate-100/50 hover:bg-slate-100 transition-colors cursor-pointer">
                                        <p class="text-[11px] font-bold text-slate-800 leading-snug"><?= htmlspecialchars($n['message']) ?></p>
                                        <span class="text-[9px] text-slate-400 font-black uppercase mt-2 block tracking-widest"><?= date('h:i A', strtotime($n['created_at'])) ?></span>
                                    </a>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Cart Action -->
            <a href="cart.php" class="relative bg-slate-900 hover:bg-slate-800 text-white p-3 md:px-6 md:py-3 md:rounded-full rounded-xl flex items-center gap-3 smooth-btn shadow-xl shadow-slate-900/20">
                <i class="fas fa-shopping-bag text-base"></i>
                <span class="hidden md:inline font-bold text-sm">Bag</span>
                <span id="cartCount" class="absolute -top-2 -right-2 md:relative md:top-0 md:right-0 w-6 h-6 md:w-auto md:h-auto md:px-2 rounded-full bg-orange-500 text-white font-black text-xs flex items-center justify-center"><?= $cart_count ?></span>
            </a>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero-section min-h-[90vh] md:min-h-screen flex items-center pt-20">
    <div class="hero-overlay"></div>
    <div class="relative z-10 w-full max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-12 text-white">

        <div class="flex-1 space-y-8 max-w-2xl mt-12 md:mt-0">
            <?php if($discount): ?>
            <div class="inline-flex items-center gap-3 bg-white/10 backdrop-blur-md border border-white/20 px-4 py-2 rounded-full animate-bounce">
                <span class="bg-orange-500 text-white text-[10px] font-black tracking-widest px-2 py-0.5 rounded shadow-lg uppercase">Offer Active</span>
                <span class="text-sm font-bold">Use code <?= htmlspecialchars($discount['promo_code']) ?> for <?= $discount['discount_percent'] ?>% OFF!</span>
            </div>
            <?php endif; ?>

            <h1 class="text-6xl md:text-8xl font-900 tracking-tighter leading-[1.05]">
                Crave It.<br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-rose-500">Get It.</span>
            </h1>

            <p class="text-lg md:text-xl text-slate-300 font-medium leading-relaxed max-w-lg">
                Experience world-class culinary masterpieces delivered directly to your door in minutes. Track your order live.
            </p>

            <form method="GET" action="index.php" class="relative max-w-md group">
                <div class="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                    <i class="fas fa-search text-slate-400"></i>
                </div>
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="What are you hungry for?"
                class="w-full bg-white/10 backdrop-blur-xl border border-white/20 text-white placeholder-slate-400 rounded-full py-5 pl-12 pr-32 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all font-semibold">
                <button type="submit" class="absolute right-2 top-2 bottom-2 bg-orange-500 hover:bg-orange-600 text-white rounded-full px-6 font-bold text-sm smooth-btn">Explore</button>
            </form>
        </div>

        <div class="hidden lg:block flex-1 relative">
            <div class="w-[500px] h-[500px] bg-orange-500/20 rounded-full blur-[100px] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
            <img src="https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=1000&auto=format&fit=crop" class="relative z-10 w-full max-w-lg mx-auto rounded-[3rem] shadow-[0_30px_100px_rgba(0,0,0,0.5)] border-4 border-white/10 -rotate-3 hover:rotate-0 transition-transform duration-700">
        </div>

    </div>
</section>

<!-- Menu Section -->
<section id="menu-section" class="py-24 px-6 md:px-12 max-w-7xl mx-auto">

    <div class="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
        <div>
            <h2 class="text-4xl font-900 tracking-tighter text-slate-900 mb-2">Our Menu<span class="text-orange-500">.</span></h2>
            <p class="text-slate-500 font-medium">Discover flavors carefully crafted by top chefs.</p>
        </div>

        <!-- Categories -->
        <div class="flex gap-3 overflow-x-auto no-scrollbar pb-4 md:pb-0 w-full md:w-auto">
            <a href="index.php#menu-section" class="category-pill whitespace-nowrap px-6 py-2.5 rounded-full text-sm font-bold <?= !isset($_GET['category_id']) ? 'active' : 'bg-white text-slate-600 border border-slate-200' ?>">All Items</a>
            <?php while($cat = $categories->fetch_assoc()): ?>
                <a href="index.php?category_id=<?= $cat['category_id'] ?>#menu-section" class="category-pill whitespace-nowrap px-6 py-2.5 rounded-full text-sm font-bold <?= (isset($_GET['category_id']) && $_GET['category_id'] == $cat['category_id']) ? 'active' : 'bg-white text-slate-600 border border-slate-200' ?>">
                    <?= $cat['category_name'] ?>
                </a>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- Food Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        <?php if($foods->num_rows == 0): ?>
            <div class="col-span-full py-20 text-center">
                <div class="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400 text-3xl"><i class="fas fa-search"></i></div>
                <h3 class="text-2xl font-bold text-slate-800">No dishes found.</h3>
                <p class="text-slate-500 font-medium mt-2">Try adjusting your search or category filter.</p>
            </div>
        <?php else: ?>
            <?php while($food = $foods->fetch_assoc()):
                $final_price = $food['price'];
                if($discount) { $final_price = $food['price'] * (1 - ($discount['discount_percent'] / 100)); }
                
                $stars = round($food['avg_rating'] ?? 0, 1);
                $rev_count = $food['rev_count'] ?? 0;
            ?>
            <div class="food-card flex flex-col group h-full">
                <!-- Image Frame -->
                <div class="relative h-56 w-full img-hover overflow-hidden rounded-t-[2rem]">
                    <a href="food_details.php?id=<?= $food['food_id'] ?>" class="block h-full">
                        <img src="images/<?= $food['image'] ?>" class="w-full h-full object-cover" onerror="this.src='https://placehold.co/600x400?text=Delicious+Food'">
                    </a>
                    <?php if($discount): ?>
                        <div class="absolute top-4 left-4 bg-rose-500/90 backdrop-blur-md text-white px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-lg border border-rose-400">
                            VIP SALE
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Content -->
                <div class="p-6 flex flex-col flex-1">
                    <div class="flex justify-between items-start mb-2">
                        <h3 class="text-xl font-800 text-slate-900 leading-tight flex-1"><?= htmlspecialchars($food['food_name']) ?></h3>
                        <div class="bg-orange-50 text-orange-600 px-3 py-1 rounded-xl font-black text-lg shadow-sm border border-orange-100 whitespace-nowrap ml-3">
                            &#8377;<?= number_format($final_price, 0) ?>
                            <?php if($discount): ?>
                                <span class="text-[10px] text-orange-400/80 line-through block -mt-1 text-right">&#8377;<?= number_format($food['price']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="flex items-center gap-2 mb-4">
                        <div class="bg-slate-50 border border-slate-100 px-2 py-1.5 rounded-lg flex items-center gap-1.5 shadow-sm">
                            <i class="fas fa-star text-amber-500 text-xs"></i>
                            <span class="font-bold text-xs text-slate-700"><?= $stars > 0 ? $stars : 'New' ?></span>
                        </div>
                        <span class="text-[9px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50/50 border border-slate-100 px-2 py-1.5 rounded-lg">(<?= $rev_count ?> Reviews)</span>
                    </div>
                    <p class="text-sm font-medium text-slate-500 mb-6 line-clamp-2 leading-relaxed flex-1">
                        <?= !empty($food['description']) ? htmlspecialchars($food['description']) : 'A signature selection crafted by our executive chefs.' ?>
                    </p>

                    <!-- Actions -->
                    <form class="addToCartForm mt-auto pt-4 border-t border-slate-100 flex items-center justify-between gap-4">
                        <input type="hidden" name="food_id" value="<?= $food['food_id'] ?>">

                        <div class="qty-stepper flex items-center bg-slate-100 rounded-xl p-1 shrink-0">
                            <button type="button" class="minus-btn w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-slate-600 font-black"><i class="fas fa-minus text-[10px]"></i></button>
                            <input type="number" class="hidden-qty w-8 text-center bg-transparent font-black text-sm text-slate-800 border-none outline-none appearance-none" name="quantity" value="1" min="1" max="10" readonly>
                            <button type="button" class="plus-btn w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-slate-600 font-black"><i class="fas fa-plus text-[10px]"></i></button>
                        </div>

                        <button type="submit" class="flex-1 bg-slate-900 hover:bg-orange-500 text-white font-bold text-sm py-3 rounded-xl smooth-btn shadow-lg shadow-slate-900/10 flex items-center justify-center gap-2">
                            <i class="fas fa-shopping-bag"></i> Add
                        </button>
                    </form>
                </div>
            </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

<!-- Footer -->
<footer class="bg-slate-900 pt-20 pb-10 border-t border-slate-800">
    <div class="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-3 gap-12 mb-16 text-center md:text-left">
        <div>
            <h3 class="text-2xl font-900 tracking-tighter text-white mb-4">Foodie's <span class="text-orange-500 italic">Heaven.</span></h3>
            <p class="text-slate-400 font-medium leading-relaxed max-w-sm mx-auto md:mx-0">Premium quality dining experiences delivered directly to your doorstep. Experience the extraordinary.</p>
        </div>
        <div class="md:mx-auto">
            <h4 class="text-white font-bold uppercase tracking-widest text-xs mb-6">Quick Links</h4>
            <ul class="space-y-4 text-slate-400 font-medium">
                <li><a href="index.php" class="hover:text-orange-500 transition-colors">Menu Selection</a></li>
                <li><a href="my_orders.php" class="hover:text-orange-500 transition-colors">Order Tracking</a></li>
                <li><a href="register.php" class="hover:text-orange-500 transition-colors">Create Account</a></li>
            </ul>
        </div>
        <div class="md:mx-auto">
            <h4 class="text-white font-bold uppercase tracking-widest text-xs mb-6">Contact Us</h4>
            <ul class="space-y-4 text-slate-400 font-medium">
                <li class="flex items-start justify-center md:justify-start gap-3 text-left"><i class="fas fa-map-marker-alt text-orange-500 mt-1"></i> Foodie's Heaven, Near Charusat College,<br>Anand District, Gujarat, India 388421</li>
                <li class="flex items-center justify-center md:justify-start gap-3"><i class="fas fa-envelope text-orange-500"></i> support@foodiesheaven.com</li>
                <li class="flex items-center justify-center md:justify-start gap-3"><i class="fas fa-phone text-orange-500"></i> +91 83476 40423</li>
            </ul>
        </div>
    </div>
    <div class="text-center pt-8 border-t border-slate-800 text-slate-500 font-semibold text-xs tracking-widest uppercase">
        &copy; 2026 Foodie's Heaven. All rights reserved.
    </div>
</footer>

<script>
    // Navbar Scroll Effect
    window.addEventListener('scroll', () => {
        const nav = document.getElementById('main-nav');
        if (window.scrollY > 20) { nav.classList.add('scrolled'); }
        else { nav.classList.remove('scrolled'); }
    });

    // Qty Stepper Logic
    document.querySelectorAll('.qty-stepper').forEach(stepper => {
        const minus = stepper.querySelector('.minus-btn');
        const plus = stepper.querySelector('.plus-btn');
        const input = stepper.querySelector('.hidden-qty');

        minus.addEventListener('click', () => {
            let val = parseInt(input.value);
            if(val > 1) input.value = val - 1;
        });
        plus.addEventListener('click', () => {
            let val = parseInt(input.value);
            if(val < 10) input.value = val + 1;
        });
    });

    // AJAX Add to Cart
    document.querySelectorAll('.addToCartForm').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            formData.append('ajax_add_to_cart', '1');

            const btn = this.querySelector('button[type="submit"]');
            const ogText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            btn.disabled = true;

            fetch('index.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    document.getElementById('cartCount').innerText = data.cart_count;
                    showToast();
                } else {
                    alert("Error adding item to cart.");
                }
            })
            .catch(err => console.error(err))
            .finally(() => {
                btn.innerHTML = ogText;
                btn.disabled = false;
            });
        });
    });

    // Toast Logic
    function showToast() {
        const toast = document.getElementById('toast');
        toast.classList.add('show');
        setTimeout(() => { toast.classList.remove('show'); }, 3000);
    }
</script>

</body>
</html>
