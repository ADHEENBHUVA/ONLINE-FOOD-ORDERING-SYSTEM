<?php
// Set System Timezone appropriately for India specifically
date_default_timezone_set('Asia/Kolkata');

// Database Configuration
$servername = "localhost";
$username   = "root";
$password   = "";
$database   = "online_food";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    // If connection fails, show a beautiful Error Page instead of plain text
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Database Error | FOODIE'S HEAVEN</title>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <style>
            body {
                font-family: 'Poppins', sans-serif;
                background-color: #f8f9fa;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }
            .error-card {
                text-align: center;
                background: white;
                padding: 40px;
                border-radius: 20px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                max-width: 450px;
            }
            .error-card i {
                font-size: 60px;
                color: #ff6b6b;
                margin-bottom: 20px;
            }
            .error-card h1 {
                margin: 0;
                color: #2d3436;
                font-size: 24px;
            }
            .error-card p {
                color: #636e72;
                margin: 15px 0;
                line-height: 1.6;
            }
            .retry-btn {
                background: #ff6b6b;
                color: white;
                padding: 12px 25px;
                text-decoration: none;
                border-radius: 10px;
                display: inline-block;
                margin-top: 10px;
                font-weight: 600;
                transition: 0.3s;
            }
            .retry-btn:hover {
                background: #ee5253;
                box-shadow: 0 5px 15px rgba(255,107,107,0.3);
            }
            .tech-details {
                font-size: 11px;
                color: #b2bec3;
                margin-top: 25px;
                border-top: 1px solid #eee;
                padding-top: 15px;
            }
        </style>
    </head>
    <body>
        <div class="error-card">
            <i class="fas fa-plug"></i>
            <h1>Connection Lost</h1>
            <p>Our servers are taking a short break. We’re unable to connect to the kitchen database right now.</p>

            <a href="javascript:location.reload()" class="btn retry-btn">
                <i class="fas fa-sync-alt"></i> Try Again
            </a>

            <div class="tech-details">
                <strong>Admin Note:</strong> <?php echo mysqli_connect_error(); ?>
            </div>
        </div>
    </body>
    </html>
    <?php
    die(); // Stop further execution
}

/**
 * System-wide Notification Helper
 * @param mysqli $conn Database connection object
 * @param int|null $user_id Recipient ID (null for all admins/delivery)
 * @param string $user_type 'admin', 'delivery', or 'customer'
 * @param string $message The notification message text
 * @param int $order_id Related Order ID
 */
if (!function_exists('addNotification')) {
    function addNotification($conn, $user_id, $user_type, $message, $order_id) {
        $user_id_val = is_null($user_id) ? "NULL" : "'".mysqli_real_escape_string($conn, $user_id)."'";
        $user_type = mysqli_real_escape_string($conn, $user_type);
        $message = mysqli_real_escape_string($conn, $message);
        $order_id = intval($order_id);

        $sql = "INSERT INTO notifications (user_id, user_type, message, order_id)
                VALUES ($user_id_val, '$user_type', '$message', $order_id)";
        return mysqli_query($conn, $sql);
    }
}

/**
 * Calculates Rider Earning centrally to avoid 0 amounts and secure visibility
 */
if (!function_exists('calculateRiderEarning')) {
    function calculateRiderEarning($conn, $order_id) {
        $fee_q = $conn->query("SELECT o.delivery_fee, c.is_vip, c.address_km FROM orders o JOIN customers c ON o.customer_id = c.customer_id WHERE o.order_id='$order_id'");
        $rider_earning = 0;
        if ($fee_q && $fee_q->num_rows > 0) {
            $order_data = $fee_q->fetch_assoc();
            if ($order_data['is_vip'] == 1) {
                $set_q = $conn->query("SELECT gen_delivery_type, gen_delivery_fee, gen_free_km, gen_charge_per_km FROM delivery_settings WHERE id=1");
                if ($set_q && $set_q->num_rows > 0) {
                    $rules = $set_q->fetch_assoc();
                    if ($rules['gen_delivery_type'] == 'km') {
                        $user_km = (float)($order_data['address_km'] ?? 0);
                        $free_km = (float)$rules['gen_free_km'];
                        $charge_km = (float)$rules['gen_charge_per_km'];
                        $rider_earning = ($user_km > $free_km) ? ($user_km - $free_km) * $charge_km : 0;
                    } else {
                        $rider_earning = (float)$rules['gen_delivery_fee'];
                    }
                }
            } else {
                $rider_earning = (float)$order_data['delivery_fee'];
            }

            // FALLBACK: If rider still has 0, pay from Gen Settings
            if ($rider_earning <= 0) {
                $set_q = $conn->query("SELECT gen_delivery_fee FROM delivery_settings WHERE id=1");
                if ($set_q && $set_q->num_rows > 0) {
                    $rider_earning = (float)$set_q->fetch_assoc()['gen_delivery_fee'];
                }
            }
        }
        return $rider_earning > 0 ? $rider_earning : 0;
    }
}
?>