<?php
session_set_cookie_params(['lifetime' => 86400 * 30]);
session_start();
include("../db.php");

// Auth Gateway
if (!isset($_SESSION['delivery_id'])) {
    header("Location: login.php");
    exit();
}

$rider_id = $_SESSION['delivery_id'];
$message = "";

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_bank'])) {
    $bank_name = $conn->real_escape_string($_POST['bank_name']);
    $account_number = $conn->real_escape_string($_POST['account_number']);
    $ifsc_code = $conn->real_escape_string($_POST['ifsc_code']);

    $query = "UPDATE delivery_person SET bank_name='$bank_name', account_number='$account_number', ifsc_code='$ifsc_code' WHERE id='$rider_id'";
    if ($conn->query($query)) {
        $message = "Bank settings successfully paired and encrypted!";
    } else {
        $message = "Error pairing account: " . $conn->error;
    }
}

// Fetch Current Data
$rider_query = $conn->query("SELECT bank_name, account_number, ifsc_code, name FROM delivery_person WHERE id='$rider_id'");
$rider = $rider_query->fetch_assoc();

// Fetch Withdrawal History
$history_query = $conn->query("SELECT * FROM rider_withdrawals WHERE rider_id='$rider_id' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Configuration | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #020617 0%, #0f172a 100%);
            color: #e2e8f0;
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.6);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            box-shadow: 0 20px 40px -10px rgba(0,0,0,0.5);
        }
        .input-dark {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            transition: all 0.3s ease;
        }
        .input-dark:focus {
            border-color: #f97316;
            outline: none;
            box-shadow: 0 0 15px rgba(249, 115, 22, 0.2);
            background: rgba(15, 23, 42, 0.9);
        }
    </style>
</head>
<body class="min-h-screen py-10 px-4">

    <!-- Top Navigation -->
    <nav class="max-w-3xl mx-auto mb-10 flex justify-between items-center">
        <a href="dashboard.php" class="text-slate-400 hover:text-orange-500 font-bold text-sm flex items-center gap-2 transition-colors">
            <i data-lucide="arrow-left" class="w-4 h-4"></i> Return to Fleet
        </a>
        <div class="flex items-center gap-4">
            <div class="flex flex-col text-right">
                <span class="text-sm font-bold text-white"><?= htmlspecialchars($rider['name']) ?></span>
                <span class="text-[10px] text-emerald-400 font-black uppercase tracking-widest flex items-center gap-1 justify-end"><div class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div> Authorized</span>
            </div>
            <a href="profile.php" class="bg-slate-800 hover:bg-blue-500/20 text-slate-400 hover:text-blue-400 transition-colors w-10 h-10 rounded-xl flex items-center justify-center relative group" title="My Profile">
                <i data-lucide="user-cog" class="w-5 h-5"></i>
            </a>
        </div>
    </nav>

    <main class="max-w-3xl mx-auto">
        <?php if($message): ?>
            <div class="mb-8 p-5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-4 text-emerald-400 font-semibold shadow-lg">
                <i data-lucide="shield-check" class="w-6 h-6"></i>
                <?= $message ?>
            </div>
        <?php endif; ?>

        <div class="glass-card rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden">
            <!-- Decorative Glow -->
            <div class="absolute -top-40 -right-40 w-96 h-96 bg-orange-500/20 rounded-full blur-[100px] pointer-events-none"></div>

            <div class="flex items-center gap-5 mb-10 border-b border-slate-800 pb-8">
                <div class="w-16 h-16 rounded-2xl bg-orange-500/10 flex items-center justify-center border border-orange-500/20 shadow-inner">
                    <i data-lucide="landmark" class="w-8 h-8 text-orange-500"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-900 text-white italic tracking-tighter uppercase">Direct Deposit</h1>
                    <p class="text-[11px] font-black tracking-widest uppercase text-slate-500 mt-1">Configure your payout architecture</p>
                </div>
            </div>

            <form method="POST" class="space-y-6">

                <div class="space-y-2">
                    <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">Official Bank Name</label>
                    <div class="relative">
                        <i data-lucide="building-2" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500"></i>
                        <input type="text" name="bank_name" value="<?= htmlspecialchars($rider['bank_name'] ?? '') ?>" placeholder="e.g. State Bank of India" required class="w-full input-dark rounded-xl py-4 pl-12 pr-4 text-sm font-bold placeholder-slate-600 focus:placeholder-transparent">
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-2">
                        <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">Account Number</label>
                        <div class="relative">
                            <i data-lucide="credit-card" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500"></i>
                            <input type="text" name="account_number" value="<?= htmlspecialchars($rider['account_number'] ?? '') ?>" placeholder="Account Number" required class="w-full input-dark rounded-xl py-4 pl-12 pr-4 text-sm font-bold font-mono tracking-widest placeholder-slate-600 focus:placeholder-transparent">
                        </div>
                    </div>

                    <div class="space-y-2">
                        <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">IFSC / SWIFT Code</label>
                        <div class="relative">
                            <i data-lucide="key" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500"></i>
                            <input type="text" name="ifsc_code" value="<?= htmlspecialchars($rider['ifsc_code'] ?? '') ?>" placeholder="Code" required class="w-full input-dark rounded-xl py-4 pl-12 pr-4 text-sm font-bold uppercase placeholder-slate-600 focus:placeholder-transparent">
                        </div>
                    </div>
                </div>

                <div class="pt-8">
                    <button type="submit" name="update_bank" class="w-full py-5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-white rounded-xl font-black text-xs uppercase tracking-[0.2em] shadow-[0_10px_30px_-10px_rgba(249,115,22,0.5)] transition-all active:scale-95 flex items-center justify-center gap-3">
                        <i data-lucide="lock" class="w-4 h-4"></i> Secure Transmission
                    </button>
                    <p class="text-center text-[9px] font-bold text-slate-600 uppercase tracking-widest mt-4">Protected by AES-256 equivalent logic</p>
                </div>

            </form>
        </div>

        <!-- Withdrawal History Section -->
        <div class="mt-12 glass-card rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden">
            <div class="flex items-center gap-4 mb-8 border-b border-slate-800 pb-6">
                <i data-lucide="history" class="w-6 h-6 text-slate-400"></i>
                <div>
                    <h2 class="text-xl font-900 text-white tracking-tight uppercase">Payout History</h2>
                    <p class="text-[10px] uppercase font-bold text-slate-500 tracking-widest mt-1">Audit Log of Withdrawals</p>
                </div>
            </div>

            <?php if ($history_query->num_rows == 0): ?>
                <div class="text-center py-10 bg-slate-900/50 rounded-2xl border border-slate-800">
                    <i data-lucide="folder-open" class="w-10 h-10 text-slate-600 mx-auto mb-3"></i>
                    <p class="text-slate-400 text-sm font-bold">No payouts recorded yet.</p>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php while($hx = $history_query->fetch_assoc()): ?>
                    <div class="bg-slate-900/60 border border-slate-800 hover:border-orange-500/30 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center text-slate-400 border border-slate-700">
                                <i data-lucide="<?= $hx['status'] == 'Completed' ? 'check-circle' : 'loader' ?>" class="<?= $hx['status'] == 'Completed' ? 'text-emerald-500' : 'text-orange-500 animate-spin-slow' ?> w-5 h-5"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-black text-lg">&#8377;<?= number_format($hx['amount'], 2) ?></h4>
                                <p class="text-[10px] font-bold text-slate-500 tracking-widest uppercase mt-0.5">
                                    <?= htmlspecialchars($hx['bank_name']) ?> <span class="text-slate-600">(*<?= substr($hx['account_number'], -4) ?>)</span>
                                </p>
                            </div>
                        </div>
                        <div class="text-right flex flex-col items-end">
                            <span class="px-3 py-1 text-[9px] font-black uppercase tracking-widest rounded-lg <?= $hx['status'] == 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-orange-500/10 text-orange-400 border border-orange-500/20' ?>">
                                <?= $hx['status'] ?>
                            </span>
                            <span class="text-[10px] text-slate-500 font-bold mt-2"><i class="far fa-clock mr-1"></i><?= date('d M Y, h:i A', strtotime($hx['created_at'])) ?></span>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>
