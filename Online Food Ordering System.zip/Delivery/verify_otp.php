<?php
session_set_cookie_params(['lifetime' => 86400 * 30]);
session_start();

if (!isset($_SESSION['rider_reset_email']) || !isset($_SESSION['rider_reset_otp'])) {
    header("Location: forgot_password.php");
    exit();
}

$error = "";

if (isset($_POST['verify_otp'])) {
    $entered_otp = preg_replace("/[^0-9]/", "", $_POST['otp1'] . $_POST['otp2'] . $_POST['otp3'] . $_POST['otp4'] . $_POST['otp5'] . $_POST['otp6']);

    if ($entered_otp == $_SESSION['rider_reset_otp']) {
        $_SESSION['rider_reset_authorized'] = true;
        header("Location: reset_password.php");
        exit();
    } else {
        $error = "Access Denied: Invalid Authorization Token.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Token | FOODIE'S HEAVEN</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; overflow: hidden; }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 100% 0%, rgba(16, 185, 129, 0.15) 0, transparent 50%), radial-gradient(at 0% 100%, rgba(15, 23, 42, 1) 0, transparent 50%); }
        .otp-input { width: 3.5rem; height: 4rem; text-align: center; font-size: 1.5rem; font-weight: 800; background: rgba(2, 6, 23, 0.5); border: 1px solid rgba(30, 41, 59, 1); color: white; border-radius: 1rem; backdrop-filter: blur(8px); transition: 0.3s; outline: none; }
        .otp-input:focus { border-color: #10b981; box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.5); transform: translateY(-2px); }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade { animation: fadeIn 0.6s ease-out forwards; }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex items-center justify-center relative">

    <div class="mesh-bg"></div>

    <div class="w-full max-w-lg p-8 md:p-10 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[2.5rem] shadow-2xl relative z-10 animate-fade mx-4">

        <div class="flex justify-center mb-8">
            <div class="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(16,185,129,0.2)]">
                <i data-lucide="shield-check" class="w-8 h-8 text-emerald-500"></i>
            </div>
        </div>

        <div class="text-center mb-10">
            <h1 class="text-3xl font-800 text-white mb-3 tracking-tight">Security Token</h1>
            <p class="text-slate-400 text-sm leading-relaxed px-4">Enter the 6-digit access token sent to your email.</p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-2xl mb-8 flex items-center gap-3">
                <i data-lucide="alert-triangle" class="w-5 h-5 flex-shrink-0"></i>
                <span class="text-[10px] font-bold uppercase tracking-[0.2em] leading-relaxed"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="flex justify-center gap-2 sm:gap-4 mb-10">
                <input type="text" name="otp1" maxlength="1" class="otp-input" required autofocus oninput="moveToNext(this, 'otp2')">
                <input type="text" name="otp2" maxlength="1" id="otp2" class="otp-input" required oninput="moveToNext(this, 'otp3')" onkeydown="moveToPrev(event, this, 'otp1')">
                <input type="text" name="otp3" maxlength="1" id="otp3" class="otp-input" required oninput="moveToNext(this, 'otp4')" onkeydown="moveToPrev(event, this, 'otp2')">
                <input type="text" name="otp4" maxlength="1" id="otp4" class="otp-input" required oninput="moveToNext(this, 'otp5')" onkeydown="moveToPrev(event, this, 'otp3')">
                <input type="text" name="otp5" maxlength="1" id="otp5" class="otp-input" required oninput="moveToNext(this, 'otp6')" onkeydown="moveToPrev(event, this, 'otp4')">
                <input type="text" name="otp6" maxlength="1" id="otp6" class="otp-input" required onkeydown="moveToPrev(event, this, 'otp5')">
            </div>

            <button type="submit" name="verify_otp"
                    class="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-900 py-4 rounded-2xl shadow-xl shadow-emerald-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 active:scale-[0.98]">
                Verify Identity Token <i data-lucide="unlock" class="w-4 h-4"></i>
            </button>
        </form>

        <div class="mt-8 text-center border-t border-slate-800 pt-6">
            <a href="login.php" class="text-slate-500 hover:text-white text-[10px] font-bold uppercase tracking-[0.2em] transition-colors flex items-center justify-center gap-2">
                <i data-lucide="arrow-left" class="w-3 h-3"></i> Return to Authentication
            </a>
        </div>

    </div>

    <script>
        lucide.createIcons();
        function moveToNext(current, nextFieldID) {
            current.value = current.value.replace(/[^0-9]/g, '');
            if (current.value.length === 1) document.getElementById(nextFieldID).focus();
        }
        function moveToPrev(event, current, prevFieldID) {
            if (event.key === "Backspace" && current.value === "") document.getElementById(prevFieldID).focus();
        }
    </script>
</body>
</html>
