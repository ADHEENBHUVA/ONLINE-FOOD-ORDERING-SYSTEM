<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

$error = "";

if(isset($_POST['login'])) {
    // Escaping inputs to prevent basic SQL Injection
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Removed status='Active' constraint to allow riders to clock in and go online.
    $sql = "SELECT * FROM delivery_person
            WHERE email='$email'
            AND password='$password'";

    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_assoc($result);
        $_SESSION['delivery_id'] = $row['id'];
        $_SESSION['delivery_name'] = $row['name'];

        // Automatically clock-in / mark Active for Admin Tracking
        mysqli_query($conn, "UPDATE delivery_person SET status='Active' WHERE id=" . $row['id']);

        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Login | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        }
        .glass {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6">

    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-20 h-20 bg-orange-500 rounded-3xl shadow-lg shadow-orange-500/20 mb-4">
                <i data-lucide="truck" class="text-white w-10 h-10"></i>
            </div>
            <h1 class="text-3xl font-800 text-white tracking-tight">FOODIE'S HEAVEN <span class="text-orange-500">Fleet</span></h1>
            <p class="text-slate-400 mt-2">Log in to start your delivery shift</p>
        </div>

        <div class="glass p-8 rounded-[2.5rem] shadow-2xl">
            <?php if($error): ?>
                <div class="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-2xl flex items-center gap-3 text-red-400 text-sm font-semibold">
                    <i data-lucide="alert-circle" class="w-5 h-5"></i>
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 ml-1">Email Address</label>
                    <div class="relative">
                        <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500"></i>
                        <input type="email" name="email" required placeholder="name@company.com"
                            class="w-full bg-slate-900/50 border border-slate-700 text-white pl-12 pr-4 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 ml-1">Password</label>
                    <div class="relative">
                        <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500"></i>
                        <input type="password" name="password" id="login_password" required placeholder="••••••••"
                            class="w-full bg-slate-900/50 border border-slate-700 text-white pl-12 pr-12 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all">
                        <button type="button" onclick="toggleVisibility('login_password')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-orange-500 transition-colors focus:outline-none">
                            <i data-lucide="eye" class="w-5 h-5"></i>
                        </button>
                    </div>
                </div>

                <button name="login" class="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-orange-500/30 transition-all transform active:scale-95 flex items-center justify-center gap-2">
                    <span>Go Online</span>
                    <i data-lucide="arrow-right" class="w-5 h-5"></i>
                </button>
            </form>

            <div class="mt-8 text-center flex flex-col gap-3">
                <p class="text-slate-500 text-sm mb-2">Want to join the fleet? <a href="register.php" class="text-orange-500 font-semibold hover:underline">Apply Here</a></p>
                <a href="forgot_password.php" class="text-orange-400 text-sm font-bold hover:text-orange-300 transition-colors hover:underline">Forgot your Password?</a>
            </div>
        </div>

        <p class="text-center text-slate-600 text-xs mt-10 tracking-widest uppercase font-bold">
            Secure Rider Access Portal
        </p>
    </div>

    <script>
        // Initialize Icons
        lucide.createIcons();

        function toggleVisibility(inputId) {
            const passInput = document.getElementById(inputId);
            passInput.type = (passInput.type === "password") ? "text" : "password";
        }
    </script>
</body>
</html>