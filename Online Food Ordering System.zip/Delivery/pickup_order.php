<?php
session_set_cookie_params(['lifetime' => 86400 * 30]);
session_start();
include("../db.php");

// Auth Gateway
if (!isset($_SESSION['delivery_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['order_id'])) {
    header("Location: dashboard.php");
    exit();
}

$order_id = intval($_GET['order_id']);
$rider_id = $_SESSION['delivery_id'];

// Fetch Order Details: Using 'c.name' instead of 'c.customer_name' to fix Fatal Error
$order_res = $conn->query("SELECT o.*, c.name, c.phone, c.address FROM orders o JOIN customers c ON o.customer_id = c.customer_id WHERE o.order_id='$order_id' AND o.delivery_person_id='$rider_id'");
if ($order_res && $order_res->num_rows > 0) {
    $order = $order_res->fetch_assoc();
} else {
    header("Location: dashboard.php");
    exit();
}

// Handle Pick Up Confirmation: Sync with Order Status Enum
if (isset($_POST['confirm_pickup'])) {
    $conn->query("UPDATE orders SET delivery_status='Picked Up', order_status='In Transit' WHERE order_id='$order_id' AND delivery_person_id='$rider_id'");

    // Notification Trigger
    $cust_q = $conn->query("SELECT customer_id FROM orders WHERE order_id='$order_id'");
    $cust_data = $cust_q->fetch_assoc();
    $customer_id = $cust_data['customer_id'] ?? null;

    addNotification($conn, null, 'admin', "Order #$order_id is now in transit.", $order_id);
    if ($customer_id) {
        addNotification($conn, $customer_id, 'customer', "Your Order is on the way! Watch out for our rider.", $order_id);
        
        // --- EMAIL NOTIFICATION ---
        require_once "../email_helper.php";
        $cust_email_q = $conn->query("SELECT email, name FROM customers WHERE customer_id='$customer_id'");
        if ($cust_email_q && $cust_email_q->num_rows > 0) {
            $cust_row = $cust_email_q->fetch_assoc();
            $customer_email = $cust_row['email'];
            $customer_name = $cust_row['name'];
            
            if (!empty($customer_email)) {
                $subject = "Your Order is on the way! (Order #$order_id)";
                $body = "<h3>Hello $customer_name,</h3>
                         <p>Great news! Your order (<strong>#$order_id</strong>) has been picked up by our delivery executive and is on its way to you.</p>
                         <p>Get ready to enjoy your meal!</p>";
                sendOrderEmail($customer_email, $subject, $body);
            }
        }
        // --------------------------
    }

    header("Location: dashboard.php?message=Order Picked Up! Head to customer location.");
    exit();
}

// Fetch Items
$items_q = $conn->query("SELECT oi.quantity, f.food_name, f.image FROM order_items oi JOIN food_items f ON oi.food_id = f.food_id WHERE oi.order_id='$order_id'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pick Up Delivery Route | Fleet</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #020617; color: white; }
        .glass-card { background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.05); }
    </style>
</head>
<body class="min-h-screen pb-20">

    <div class="max-w-md mx-auto p-6">
        <header class="flex items-center justify-between mb-8">
            <a href="dashboard.php" class="p-3 bg-slate-800 rounded-2xl text-slate-400 hover:text-white transition">
                <i data-lucide="arrow-left"></i>
            </a>
            <div class="text-right">
                <span class="text-[10px] font-black uppercase tracking-widest text-slate-500">Pickup Phase</span>
                <h1 class="text-xl font-900 italic uppercase tracking-tighter">Dispatch Job</h1>
            </div>
        </header>

        <div class="glass-card rounded-[2.5rem] p-8 mb-6 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl -mr-10 -mt-10"></div>

            <div class="flex items-center gap-4 mb-8">
                <div class="w-16 h-16 bg-orange-500 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/20">
                    <i data-lucide="utensils" class="w-8 h-8 text-white"></i>
                </div>
                <div>
                    <h2 class="text-lg font-900 uppercase italic">Restaurant</h2>
                    <p class="text-slate-400 text-xs font-bold">Foodie's Heaven Central</p>
                </div>
            </div>

            <div class="space-y-6">
                <div class="bg-slate-900/50 rounded-3xl p-6 border border-slate-800">
                    <p class="text-[10px] font-black uppercase tracking-widest text-orange-500 mb-4 flex items-center gap-2">
                        <i data-lucide="check-circle-2" class="w-3 h-3 text-orange-500"></i> Manual Verification Checklist
                    </p>
                    <ul class="space-y-4" id="checklist">
                        <?php while ($item = $items_q->fetch_assoc()): ?>
                            <li class="flex items-center justify-between group cursor-pointer" onclick="toggleCheck(this)">
                                <div class="flex items-center gap-4">
                                    <div class="w-6 h-6 rounded-lg bg-slate-800 border-2 border-slate-700 flex items-center justify-center transition-all checkbox-box group-hover:border-orange-500/50">
                                        <i data-lucide="check" class="w-4 h-4 text-orange-500 opacity-0 transition-opacity"></i>
                                    </div>
                                    <div class="flex flex-col">
                                        <span class="font-bold text-sm text-slate-200"><?= htmlspecialchars($item['food_name']) ?></span>
                                        <span class="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Qty: <?= $item['quantity'] ?></span>
                                    </div>
                                </div>
                                <input type="checkbox" class="hidden item-check" onchange="validateChecklist()">
                            </li>
                        <?php endwhile; ?>
                    </ul>
                </div>

                <div class="flex items-start gap-4 p-4 bg-orange-500/10 border border-orange-500/20 rounded-2xl">
                    <i data-lucide="shield-alert" class="w-5 h-5 text-orange-400 shrink-0"></i>
                    <p class="text-[10px] text-orange-300 leading-relaxed font-bold uppercase tracking-wide">
                        Safety Protocol: Verify all items to unlock the pickup confirmation. Failure to check may result in inaccurate delivery.
                    </p>
                </div>
            </div>
        </div>

        <form method="POST" class="mt-10" id="pickupForm">
            <button type="submit" name="confirm_pickup" id="submitBtn" disabled
                class="w-full bg-slate-800 text-slate-500 cursor-not-allowed py-5 rounded-[2rem] font-900 uppercase tracking-[0.2em] text-sm shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95">
                Confirm Pick Up <i data-lucide="lock" class="w-4 h-4"></i>
            </button>
        </form>
    </div>

    <script>
        lucide.createIcons();

        function toggleCheck(el) {
            const checkbox = el.querySelector('.item-check');
            const icon = el.querySelector('[data-lucide="check"]');
            const box = el.querySelector('.checkbox-box');

            checkbox.checked = !checkbox.checked;

            if(checkbox.checked) {
                icon.style.opacity = '1';
                box.classList.add('border-orange-500', 'bg-orange-500/10');
            } else {
                icon.style.opacity = '0';
                box.classList.remove('border-orange-500', 'bg-orange-500/10');
            }
            validateChecklist();
        }

        function validateChecklist() {
            const checks = document.querySelectorAll('.item-check');
            const submitBtn = document.getElementById('submitBtn');
            const allChecked = Array.from(checks).every(c => c.checked);

            if(allChecked && checks.length > 0) {
                submitBtn.disabled = false;
                submitBtn.classList.remove('bg-slate-800', 'text-slate-500', 'cursor-not-allowed');
                submitBtn.classList.add('bg-orange-500', 'text-white', 'shadow-orange-500/40');
                submitBtn.innerHTML = 'Confirm Pick Up <i data-lucide="chevron-right"></i>';
                lucide.createIcons();
            } else {
                submitBtn.disabled = true;
                submitBtn.classList.add('bg-slate-800', 'text-slate-500', 'cursor-not-allowed');
                submitBtn.classList.remove('bg-orange-500', 'text-white', 'shadow-orange-500/40');
                submitBtn.innerHTML = 'Confirm Pick Up <i data-lucide="lock"></i>';
                lucide.createIcons();
            }
        }
    </script>
</body>
</html>
