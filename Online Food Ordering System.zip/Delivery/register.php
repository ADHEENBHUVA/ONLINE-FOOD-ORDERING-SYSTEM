<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

$error = "";
$success = "";

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $vehicle_type = mysqli_real_escape_string($conn, $_POST['vehicle_type']);
    $vehicle_number = strtoupper(mysqli_real_escape_string($conn, $_POST['vehicle_number']));

    // Check if email or phone already exists
    $check = $conn->query("SELECT id FROM delivery_person WHERE email='$email' OR phone='$phone'");
    if ($check->num_rows > 0) {
        $error = "A rider with this Email or Phone is already registered.";
    } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        $error = "Invalid name! Only alphabets and spaces are allowed.";
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $error = "Invalid phone number! Please enter exactly 10 digits.";
    } else {
        // Strict Password Regex matching the overall system
        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';

        if (!preg_match($pattern, $password)) {
            $error = "Security Policy: Password requires 8-16 chars, Uppercase, Lowercase, Number & Special Char.";
        } else {
            // Auto-Activate for immediate testing as requested by User
            $stmt = $conn->prepare("INSERT INTO delivery_person (name, email, phone, password, vehicle_type, vehicle_number, status) VALUES (?, ?, ?, ?, ?, ?, 'Active')");
            $stmt->bind_param("ssssss", $name, $email, $phone, $password, $vehicle_type, $vehicle_number);

            if ($stmt->execute()) {
                $success = "Application Approved! You have been successfully enlisted into the Fleet.";
                echo "<script>setTimeout(function(){ window.location.href = 'login.php'; }, 2000);</script>";
            } else {
                $error = "System Database Fault. Registration failed.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Registration | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            overflow-x: hidden;
        }
        .glass {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        /* Custom scrollbar for form */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-thumb { background: #f97316; border-radius: 10px; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6 py-12">

    <div class="w-full max-w-2xl">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-blue-500 rounded-2xl shadow-lg shadow-blue-500/20 mb-4">
                <i data-lucide="map-pin" class="text-white w-8 h-8"></i>
            </div>
            <h1 class="text-3xl font-800 text-white tracking-tight">Join The <span class="text-blue-500">Fleet</span></h1>
            <p class="text-slate-400 mt-2">Become a premium delivery executive today.</p>
        </div>

        <div class="glass p-8 md:p-10 rounded-[2.5rem] shadow-2xl">
            <?php if ($error): ?>
                <div class="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-2xl flex items-center gap-3 text-red-400 text-sm font-semibold">
                    <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0"></i>
                    <span><?= $error ?></span>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/50 rounded-2xl flex items-center gap-3 text-emerald-400 text-sm font-semibold">
                    <i data-lucide="check-circle-2" class="w-5 h-5 flex-shrink-0"></i>
                    <span><?= $success ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Personal Info -->
                    <div>
                        <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2 ml-1">Full Legal Name</label>
                        <div class="relative">
                            <i data-lucide="user" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="text" name="name" required placeholder="John Doe" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');"
                                class="w-full bg-slate-900/50 border border-slate-700 text-white pl-11 pr-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm">
                        </div>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2 ml-1">Phone Number</label>
                        <div class="relative">
                            <i data-lucide="phone" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="tel" name="phone" required placeholder="9876543210" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');"
                                class="w-full bg-slate-900/50 border border-slate-700 text-white pl-11 pr-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm">
                        </div>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2 ml-1">Email Address</label>
                        <div class="relative">
                            <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="email" name="email" required placeholder="rider@domain.com"
                                class="w-full bg-slate-900/50 border border-slate-700 text-white pl-11 pr-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm">
                        </div>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2 ml-1">Security Key (Password)</label>
                        <div class="relative">
                            <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="password" name="password" id="reg_password" required placeholder="••••••••"
                                class="w-full bg-slate-900/50 border border-slate-700 text-white pl-11 pr-12 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm">
                            <button type="button" onclick="toggleVisibility('reg_password')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-500 transition-colors focus:outline-none">
                                <i data-lucide="eye" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Logistics Info -->
                    <div>
                        <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2 ml-1">Vehicle Platform</label>
                        <div class="relative">
                            <i data-lucide="bike" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 z-10"></i>
                            <select name="vehicle_type" required class="w-full bg-slate-900/50 border border-slate-700 text-white pl-11 pr-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm appearance-none cursor-pointer">
                                <option value="Motorcycle" class="bg-slate-900 text-white">Motorcycle</option>
                                <option value="Scooter" class="bg-slate-900 text-white">Scooter</option>
                                <option value="Bicycle" class="bg-slate-900 text-white">Bicycle</option>
                                <option value="Car" class="bg-slate-900 text-white">Car</option>
                            </select>
                            <i data-lucide="chevron-down" class="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none"></i>
                        </div>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2 ml-1">License Plate No.</label>
                        <div class="relative">
                            <i data-lucide="hash" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="text" name="vehicle_number" required placeholder="MH01-XX-9999" oninput="this.value = this.value.toUpperCase();"
                                class="w-full bg-slate-900/50 border border-slate-700 text-white pl-11 pr-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm uppercase">
                        </div>
                    </div>
                </div>

                <div class="pt-4 border-t border-slate-800">
                    <button name="register" <?php if($success) echo "disabled"; ?> class="w-full bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white font-900 py-4.5 py-4 rounded-xl shadow-xl shadow-blue-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 active:scale-[0.98]">
                        Submit Application <i data-lucide="file-check" class="w-4 h-4"></i>
                    </button>
                </div>
            </form>

            <div class="mt-8 text-center">
                <p class="text-slate-500 text-sm">Already in the fleet? <a href="login.php" class="text-blue-500 font-bold hover:underline ml-1">Access Terminal</a></p>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function toggleVisibility(inputId) {
            const passInput = document.getElementById(inputId);
            passInput.type = (passInput.type === "password") ? "text" : "password";
        }
    </script>
</body>
</html>
