<?php
session_set_cookie_params(['lifetime' => 86400 * 30]);
session_start();
include("../db.php");

if (!isset($_SESSION['rider_reset_authorized']) || $_SESSION['rider_reset_authorized'] !== true) {
    header("Location: forgot_password.php");
    exit();
}

$error = "";
$success = "";

if (isset($_POST['reset_secure'])) {
    $new_password = $_POST['npass'];
    $confirm_password = $_POST['cpass'];
    $rider_id = $_SESSION['rider_reset_id'];

    if ($new_password !== $confirm_password) {
        $error = "Validation Fault: The new passwords do not match.";
    } else {
        // Strict Password Regex matching the overall system
        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';

        if (!preg_match($pattern, $new_password)) {
            $error = "Security Policy: Password requires 8-16 chars, Uppercase, Lowercase, Number & Special Char.";
        } else {
            $stmt = $conn->prepare("UPDATE delivery_person SET password=? WHERE id=?");
            $stmt->bind_param("si", $new_password, $rider_id);

            if ($stmt->execute()) {
                // Clear sessions
                unset($_SESSION['rider_reset_email']);
                unset($_SESSION['rider_reset_otp']);
                unset($_SESSION['rider_reset_id']);
                unset($_SESSION['rider_reset_authorized']);

                $success = "Master Key updated! You can now access the terminal.";
                echo "<script>setTimeout(function(){ window.location.href = 'login.php'; }, 2000);</script>";
            } else {
                $error = "System Database Fault. Could not update Master Key.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Key Override | FOODIE'S HEAVEN</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; overflow: hidden; }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 0% 0%, rgba(59, 130, 246, 0.15) 0, transparent 50%), radial-gradient(at 100% 100%, rgba(15, 23, 42, 1) 0, transparent 50%); }
        .input-focus:focus { box-shadow: 0 0 0 2px #3b82f6; border-color: #3b82f6; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade { animation: fadeIn 0.6s ease-out forwards; }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex items-center justify-center relative">

    <div class="mesh-bg"></div>

    <div class="w-full max-w-md p-8 md:p-12 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[2.5rem] shadow-2xl relative z-10 animate-fade mx-4">

        <div class="flex justify-center mb-8">
            <div class="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(59,130,246,0.2)]">
                <i data-lucide="scan-face" class="w-8 h-8 text-blue-500"></i>
            </div>
        </div>

        <div class="text-center mb-10">
            <h1 class="text-3xl font-800 text-white mb-3 tracking-tight">Key Override</h1>
            <p class="text-slate-400 text-sm leading-relaxed px-4">Identity verified. Please configure your new Master Key.</p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-2xl mb-8 flex items-center gap-3 animate-fade">
                <i data-lucide="shield-alert" class="w-5 h-5 flex-shrink-0"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest leading-relaxed"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <?php if($success != ""): ?>
            <div class="bg-emerald-500/10 border border-emerald-500/50 text-emerald-400 p-4 rounded-2xl mb-8 flex items-center gap-3 animate-fade">
                <i data-lucide="check-circle" class="w-6 h-6 flex-shrink-0"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest leading-relaxed"><?php echo $success; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="space-y-6" onsubmit="return validatePassword();">

            <div>
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 ml-1">New System Master Key</label>
                <div class="relative group">
                    <i data-lucide="key-round" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600 group-focus-within:text-blue-500 transition-colors"></i>
                    <input type="password" name="npass" id="npass" required placeholder="••••••••"
                           class="w-full bg-slate-950/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-12 text-white outline-none input-focus transition-all tracking-widest font-bold text-sm">
                    <button type="button" onclick="toggleVisibility('npass', 'eye1')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-500 transition-colors focus:outline-none">
                        <i id="eye1" data-lucide="eye" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>

            <div>
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 ml-1">Re-enter Master Key</label>
                <div class="relative group">
                    <i data-lucide="check-circle-2" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600 group-focus-within:text-blue-500 transition-colors"></i>
                    <input type="password" name="cpass" id="cpass" required placeholder="••••••••"
                           class="w-full bg-slate-950/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-12 text-white outline-none input-focus transition-all tracking-widest font-bold text-sm">
                    <button type="button" onclick="toggleVisibility('cpass', 'eye2')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-500 transition-colors focus:outline-none">
                        <i id="eye2" data-lucide="eye" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>

            <div class="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                <p class="flex items-center gap-2 text-[9px] text-slate-500 font-bold uppercase tracking-widest leading-relaxed">
                    <i data-lucide="info" class="w-4 h-4 text-orange-500 flex-shrink-0"></i> Policy: 8-16 chars, include A, a, 1, and @$!%*?&
                </p>
            </div>

            <button type="submit" name="reset_secure"
                    <?php if($success != "") echo 'disabled'; ?>
                    class="w-full bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white font-900 py-4 rounded-2xl shadow-xl shadow-blue-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 active:scale-[0.98]">
                Override Master Key <i data-lucide="upload-cloud" class="w-4 h-4"></i>
            </button>
        </form>
    </div>

    <script>
        lucide.createIcons();

        function toggleVisibility(inputId, iconId) {
            const passInput = document.getElementById(inputId);
            passInput.type = (passInput.type === "password") ? "text" : "password";
            // Note: lucide doesn't have an eye-slash, so we'll just leave it or you can swap the icon completely.
        }

        function validatePassword() {
            const p1 = document.getElementById('npass').value;
            const p2 = document.getElementById('cpass').value;
            if(p1 !== p2){
                alert("Keys do not match!"); return false;
            }
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
            if (!regex.test(p1)) {
                alert("Security Violation: Your password must be 8-16 characters and contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
