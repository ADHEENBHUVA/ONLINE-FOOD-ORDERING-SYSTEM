<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Auth Gateway
if (!isset($_SESSION['delivery_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['order_id'])) {
    header("Location: dashboard.php");
    exit();
}

$order_id = intval($_GET['order_id']);
$rider_id = $_SESSION['delivery_id'];
$error = "";

$order_res = $conn->query("SELECT customer_name, phone, address, total_amount, payment_method, order_status FROM orders WHERE order_id='$order_id' AND delivery_person_id='$rider_id'");
if($order_res && $order_res->num_rows > 0) {
    $order_data = $order_res->fetch_assoc();
    if ($order_data['order_status'] == 'Delivered') {
        echo "<script>alert('Order already delivered!'); window.location.href='dashboard.php';</script>";
        exit();
    }
} else {
    header("Location: dashboard.php");
    exit();
}

// Calculate Rider Earning for Display (Admin bears the cost for VIP)
$rider_earning = calculateRiderEarning($conn, $order_id);

if (isset($_POST['verify_otp'])) {
    $entered_otp = trim($_POST['otp']);

    // Fetch OTP from DB
    $otp_res = $conn->query("SELECT delivery_otp FROM orders WHERE order_id='$order_id'");
    if ($otp_res && $otp_res->num_rows > 0) {
        $real_otp = $otp_res->fetch_assoc()['delivery_otp'];

        if (!empty($real_otp) && $entered_otp == $real_otp) {
            // SUCCESSFUL DELIVERY EVENT!

            // 1. Update Order Status
            $conn->query("UPDATE orders SET delivery_status='Delivered', order_status='Delivered' WHERE order_id='$order_id' AND delivery_person_id='$rider_id'");

            // 2. Calculate Rider Earning (Admin bears the cost for VIP)
            // (Moved outside POST check to calculate for display)

            // 3. Fund Rider Wallet (+ rider_earning)
            $conn->query("UPDATE delivery_person SET wallet_balance = wallet_balance + $rider_earning WHERE id='$rider_id'");

            // 4. Secure Cleanup
            $conn->query("UPDATE orders SET delivery_otp = NULL WHERE order_id='$order_id'");

            // Notification Trigger
            $cust_q = $conn->query("SELECT customer_id FROM orders WHERE order_id='$order_id'");
            $cust_data = $cust_q->fetch_assoc();
            $customer_id = $cust_data['customer_id'] ?? null;

            addNotification($conn, null, 'admin', "Order #$order_id has been successfully delivered.", $order_id);
            if ($customer_id) {
                addNotification($conn, $customer_id, 'customer', "Your Order has been delivered. Enjoy your meal!", $order_id);
            }

            echo "<script>alert('Delivery Verified securely! &#8377;".number_format($rider_earning, 2)." paid to your wallet.'); window.location.href='dashboard.php';</script>";
            exit();
        } else {
            $error = "Invalid OTP matching. Please ask customer to check their Order Page.";
        }
    } else {
         $error = "OTP mismatch or order missing. Please return to the dashboard and trigger Handover again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Handover | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #020617; color: white; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6 bg-slate-900 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-900 via-[#020617] to-[#020617]">

    <div class="w-full max-w-sm">
        <a href="dashboard.php" class="text-slate-500 hover:text-white transition flex items-center gap-2 mb-6 font-bold text-sm">
            <i data-lucide="arrow-left" class="w-4 h-4"></i> Abort Handover
        </a>

        <div class="bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-8 rounded-[2rem] shadow-2xl relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>

            <div class="inline-flex items-center justify-center w-16 h-16 bg-orange-500/20 text-orange-500 rounded-2xl mb-6 border border-orange-500/30">
                <i data-lucide="shield-check" class="w-8 h-8"></i>
            </div>

            <h2 class="text-2xl font-900 tracking-tight text-white mb-2">Secure Handover</h2>
            <p class="text-slate-400 text-sm mb-6 leading-relaxed">Ask the customer for the 6-digit OTP sent to their email to officially close this order and release your payment.</p>

            <div class="bg-slate-900/50 border border-slate-700/50 rounded-2xl p-5 mb-6 text-left space-y-3 shadow-inner">
                <div class="flex items-center justify-between border-b border-slate-700/30 pb-3">
                    <span class="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Customer</span>
                    <span class="text-white font-900 text-sm tracking-tight"><?= htmlspecialchars($order_data['customer_name'] ?? 'N/A') ?></span>
                </div>
                <div class="flex flex-col border-b border-slate-700/30 pb-3">
                    <span class="text-[10px] uppercase font-bold text-slate-500 tracking-widest mb-1.5">Drop-off Point</span>
                    <span class="text-slate-300 font-medium text-xs leading-relaxed"><?= htmlspecialchars($order_data['address'] ?? 'N/A') ?></span>
                </div>
                <div class="flex items-center justify-between border-b border-slate-700/30 pb-3">
                    <span class="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Contact</span>
                    <a href="tel:<?= htmlspecialchars($order_data['phone'] ?? '') ?>" class="text-emerald-400 hover:text-emerald-300 font-bold text-sm transition-colors flex items-center gap-1.5"><i data-lucide="phone" class="w-3 h-3"></i> <?= htmlspecialchars($order_data['phone'] ?? 'N/A') ?></a>
                </div>
                <div class="flex items-center justify-between pt-1">
                    <span class="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Delivery Earnings</span>
                    <div class="text-right">
                        <span class="text-orange-400 font-black tracking-tight text-lg">&#8377;<?= number_format($rider_earning, 2) ?></span>
                        <span class="block text-[9px] uppercase font-black text-emerald-500 tracking-[0.2em] mt-0.5">PAYOUT</span>
                    </div>
                </div>
            </div>

            <?php if($error): ?>
                <div class="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-3 text-red-400 text-xs font-bold">
                    <i data-lucide="alert-circle" class="w-4 h-4 mt-0.5 shrink-0"></i>
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div>
                    <label class="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2 ml-1">Customer OTP</label>
                    <div class="relative">
                        <i data-lucide="key-round" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500"></i>
                        <input type="text" name="otp" required placeholder="123456" maxlength="6" pattern="\d{6}"
                            class="w-full bg-slate-900/50 border border-slate-700 text-white pl-12 pr-4 py-4 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none transition-all text-xl font-mono tracking-[0.5em] text-center">
                    </div>
                </div>

                <button type="submit" name="verify_otp" class="w-full bg-orange-500 hover:bg-orange-600 text-white font-900 py-4 rounded-xl shadow-lg shadow-orange-500/30 transition-all flex items-center justify-center gap-2 uppercase tracking-widest text-sm">
                    Verify & Complete
                </button>
            </form>
        </div>
    </div>

    <script> lucide.createIcons(); </script>
</body>
</html>
