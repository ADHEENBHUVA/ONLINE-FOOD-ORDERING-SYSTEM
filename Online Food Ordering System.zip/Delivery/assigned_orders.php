<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

// Protect the route
if(!isset($_SESSION['delivery_id'])){
    header("Location: login.php");
    exit();
}

$delivery_id = $_SESSION['delivery_id'];

// Fetch orders assigned to this rider that are currently in transit
$sql = "SELECT * FROM orders
        WHERE delivery_person_id='$delivery_id'
        AND order_status != 'Delivered'
        AND order_status != 'Cancelled'
        ORDER BY order_id DESC";

$result = mysqli_query($conn, $sql);
$order_count = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Dashboard | FOODIE'S HEAVEN Delivery</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f3f4f6; }
        .order-card { transition: transform 0.2s ease; }
        .order-card:active { transform: scale(0.98); }
    </style>
</head>
<body class="pb-20">

    <header class="bg-slate-900 text-white p-6 sticky top-0 z-50 shadow-lg">
        <div class="flex justify-between items-center max-w-2xl mx-auto">
            <div>
                <h1 class="text-xl font-800 tracking-tight">Active Tasks</h1>
                <p class="text-slate-400 text-xs uppercase font-bold tracking-widest mt-1">
                    <?= $order_count ?> Orders to Deliver
                </p>
            </div>
            <a href="logout.php" class="bg-slate-800 p-2 rounded-full text-red-400">
                <i data-lucide="log-out" class="w-5 h-5"></i>
            </a>
        </div>
    </header>

    <main class="p-4 max-w-2xl mx-auto space-y-4">

        <?php if($order_count > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
            <div class="order-card bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">

                <div class="p-5 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                    <div class="flex items-center gap-3">
                        <div class="bg-blue-600 text-white p-2 rounded-xl">
                            <i data-lucide="package" class="w-5 h-5"></i>
                        </div>
                        <span class="font-bold text-slate-800">Order #<?= $row['order_id'] ?></span>
                    </div>
                    <span class="text-blue-700 bg-blue-50 px-3 py-1 rounded-full text-xs font-bold uppercase">
                        <?= $row['order_status'] == 'In Transit' ? 'In Transit' : 'In Kitchen' ?>
                    </span>
                </div>

                <div class="p-5 space-y-4">
                    <div class="flex items-center justify-between">
                        <span class="text-slate-500 text-sm font-medium">Delivery Payout:</span>
                        <span class="text-2xl font-extrabold text-slate-900">&#8377;<?= number_format(calculateRiderEarning($conn, $row['order_id']), 2) ?></span>
                    </div>

                    <hr class="border-slate-100">

                    <div class="flex gap-4">
                        <div class="flex flex-col items-center">
                            <div class="w-2 h-2 rounded-full bg-blue-600"></div>
                            <div class="w-0.5 h-10 bg-slate-200"></div>
                            <div class="w-3 h-3 rounded-full border-2 border-blue-600 bg-white"></div>
                        </div>
                        <div class="flex-1">
                            <p class="text-[10px] uppercase font-extrabold text-slate-400 tracking-widest">Delivery Address</p>
                            <p class="text-slate-700 font-semibold mt-1 leading-relaxed">
                                <?= htmlspecialchars($row['address']) ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="p-5 pt-0 grid grid-cols-2 gap-3">
                    <a href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($row['address']) ?>"
                       target="_blank"
                       class="flex items-center justify-center gap-2 bg-slate-100 text-slate-700 font-bold py-4 rounded-2xl hover:bg-slate-200 transition">
                        <i data-lucide="map-pin" class="w-4 h-4"></i> Map
                    </a>

                    <form method="POST" action="dashboard.php" class="m-0 flex">
                        <input type="hidden" name="order_id" value="<?= $row['order_id'] ?>">
                        <input type="hidden" name="action" value="deliver">
                        <button type="submit" onclick="return confirm('You are arriving at the destination. We will send an OTP to the customer. Proceed?')"
                           class="w-full flex items-center justify-center gap-2 bg-green-500 text-white font-bold py-4 rounded-2xl shadow-lg shadow-green-200 hover:bg-green-600 transition">
                            <i data-lucide="check-circle" class="w-4 h-4"></i> Complete
                        </button>
                    </form>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center py-20 px-10">
                <div class="bg-slate-200 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="box" class="text-slate-400 w-10 h-10"></i>
                </div>
                <h2 class="text-xl font-bold text-slate-800">No Pending Deliveries</h2>
                <p class="text-slate-500 text-sm mt-2">Take a break or wait for new orders to be assigned.</p>
                <a href="dashboard.php" class="mt-6 inline-block text-blue-600 font-bold underline">Check History</a>
            </div>
        <?php endif; ?>

    </main>

    <nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-6 py-3 flex justify-around items-center z-50">
        <a href="dashboard.php" class="flex flex-col items-center text-slate-400">
            <i data-lucide="home" class="w-6 h-6"></i>
            <span class="text-[10px] mt-1 font-bold">Home</span>
        </a>
        <a href="#" class="flex flex-col items-center text-blue-600">
            <i data-lucide="truck" class="w-6 h-6"></i>
            <span class="text-[10px] mt-1 font-bold">Tasks</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center text-slate-400">
            <i data-lucide="user" class="w-6 h-6"></i>
            <span class="text-[10px] mt-1 font-bold">Profile</span>
        </a>
    </nav>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>