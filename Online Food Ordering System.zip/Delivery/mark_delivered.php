<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

if(!isset($_SESSION['delivery_id'])){
    header("Location: login.php");
    exit();
}

$order_id = mysqli_real_escape_string($conn, $_GET['id']);
$rider_id = $_SESSION['delivery_id'];
$rider_earning = 0;

// Check if already delivered
$check_q = $conn->query("SELECT order_status FROM orders WHERE order_id='$order_id'");
$curr_status = $check_q->fetch_assoc()['order_status'] ?? '';

if ($curr_status == 'Delivered') {
    header("Location: assigned_orders.php");
    exit();
}

// Update the database
$update = mysqli_query($conn, "UPDATE orders SET order_status='Delivered', delivery_status='Delivered' WHERE order_id='$order_id'");

if($update) {
    // 2. Calculate Rider Earning (Admin bears the cost for VIP)
    $fee_q = $conn->query("SELECT o.delivery_fee, c.is_vip, c.address_km FROM orders o JOIN customers c ON o.customer_id = c.customer_id WHERE o.order_id='$order_id'");
    if ($fee_q && $fee_q->num_rows > 0) {
        $order_data = $fee_q->fetch_assoc();
        if ($order_data['is_vip'] == 1) {
            $set_q = $conn->query("SELECT gen_delivery_type, gen_delivery_fee, gen_free_km, gen_charge_per_km FROM delivery_settings WHERE id=1");
            if ($set_q && $set_q->num_rows > 0) {
                $rules = $set_q->fetch_assoc();
                if ($rules['gen_delivery_type'] == 'km') {
                    $user_km = (float)($order_data['address_km'] ?? 0);
                    $free_km = (float)$rules['gen_free_km'];
                    $charge_km = (float)$rules['gen_charge_per_km'];
                    $rider_earning = ($user_km > $free_km) ? ($user_km - $free_km) * $charge_km : 0;
                } else {
                    $rider_earning = (float)$rules['gen_delivery_fee'];
                }
            }
        } else {
            $rider_earning = (float)$order_data['delivery_fee'];
        }

        // FALLBACK: If rider still has 0 (Free Promo for Regulars), pay from Gen Settings
        if ($rider_earning <= 0) {
            $set_q = $conn->query("SELECT gen_delivery_fee FROM delivery_settings WHERE id=1");
            if ($set_q && $set_q->num_rows > 0) {
                $rider_earning = (float)$set_q->fetch_assoc()['gen_delivery_fee'];
            }
        }
    }

    // 3. Fund Rider Wallet (+ rider_earning)
    $conn->query("UPDATE delivery_person SET wallet_balance = wallet_balance + $rider_earning WHERE id='$rider_id'");

    // 4. Secure Cleanup
    $conn->query("UPDATE orders SET delivery_otp = NULL WHERE order_id='$order_id'");

    // Notification Trigger
    $cust_q = $conn->query("SELECT customer_id FROM orders WHERE order_id='$order_id'");
    $cust_data = $cust_q->fetch_assoc();
    $customer_id = $cust_data['customer_id'] ?? null;

    addNotification($conn, null, 'admin', "Order #$order_id has been successfully delivered.", $order_id);
    if ($customer_id) {
        addNotification($conn, $customer_id, 'customer', "Your Order has been delivered. Enjoy your meal!", $order_id);
        
        // --- EMAIL NOTIFICATION ---
        require_once "../email_helper.php";
        $cust_email_q = $conn->query("SELECT email, name FROM customers WHERE customer_id='$customer_id'");
        if ($cust_email_q && $cust_email_q->num_rows > 0) {
            $cust_row = $cust_email_q->fetch_assoc();
            $customer_email = $cust_row['email'];
            $customer_name = $cust_row['name'];
            
            // 1. Email to Customer
            if (!empty($customer_email)) {
                $subject = "Order Delivered! (Order #$order_id)";
                $body = "<h3>Hello $customer_name,</h3>
                         <p>Your order (<strong>#$order_id</strong>) has been successfully delivered!</p>
                         <p>We hope you enjoy your meal. Thank you for choosing Foodie's Heaven.</p>";
                sendOrderEmail($customer_email, $subject, $body);
            }
        }
        
        // 2. Email to Admin
        $admin_subject = "Order Delivered (Order #$order_id)";
        $admin_body = "<h3>Admin Alert: Delivery Completed</h3>
                       <p>Order <strong>#$order_id</strong> has been successfully delivered to the customer.</p>";
        sendOrderEmail(ADMIN_EMAIL, $admin_subject, $admin_body);

        // 3. Email to Delivery Person
        $rider_email_q = $conn->query("SELECT email, name FROM delivery_person WHERE id='$rider_id'");
        if ($rider_email_q && $rider_email_q->num_rows > 0) {
            $rider_row = $rider_email_q->fetch_assoc();
            $rider_email = $rider_row['email'];
            $rider_name = $rider_row['name'];
            if (!empty($rider_email)) {
                $rider_subject = "Delivery Successful! (Order #$order_id)";
                $rider_body = "<h3>Well done $rider_name,</h3>
                               <p>You have successfully delivered order <strong>#$order_id</strong>.</p>
                               <p>Earnings of <strong>₹".number_format($rider_earning, 2)."</strong> have been added to your wallet.</p>
                               <p>Keep up the great work!</p>";
                sendOrderEmail($rider_email, $rider_subject, $rider_body);
            }
        }
        // --------------------------
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Success | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .checkmark-circle {
            animation: grow 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }
        @keyframes grow {
            from { transform: scale(0); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
    </style>
    <meta http-equiv="refresh" content="3;url=assigned_orders.php">
</head>
<body class="bg-slate-900 min-h-screen flex items-center justify-center p-6">

    <div class="text-center">
        <div class="checkmark-circle bg-emerald-500 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(16,185,129,0.4)]">
            <i data-lucide="check" class="text-white w-12 h-12 stroke-[4]"></i>
        </div>

        <h1 class="text-white text-3xl font-800 tracking-tight mb-2">Great Job!</h1>
        <p class="text-slate-400 font-medium mb-4">Order #<?php echo $order_id; ?> marked as delivered.</p>

        <?php if($rider_earning > 0): ?>
        <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-black tracking-widest uppercase text-xs py-3 px-8 rounded-full inline-block mb-8 shadow-sm">
            + &#8377;<?= number_format($rider_earning, 2) ?> Added to Wallet
        </div>
        <?php else: ?>
        <div class="mb-8"></div>
        <?php endif; ?>

        <div class="w-48 h-1.5 bg-slate-800 rounded-full mx-auto overflow-hidden">
            <div class="h-full bg-blue-500 transition-all duration-[2500ms] ease-linear w-full"></div>
        </div>

        <p class="text-slate-500 text-xs mt-4 uppercase tracking-widest font-bold">Returning to tasks...</p>

        <a href="assigned_orders.php" class="mt-8 inline-block text-blue-400 font-bold text-sm hover:underline">
            Click here if not redirected
        </a>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>