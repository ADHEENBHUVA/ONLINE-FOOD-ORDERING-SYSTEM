<?php
session_set_cookie_params(86400 * 30);
session_start();
include("../db.php");

if (isset($_SESSION['delivery_id'])) {
    $r_id = intval($_SESSION['delivery_id']);
    $conn->query("UPDATE delivery_person SET status='Offline' WHERE id='$r_id'");
}

unset($_SESSION['delivery_id']);
unset($_SESSION['delivery_name']);
header("Location: login.php");
exit();
?>