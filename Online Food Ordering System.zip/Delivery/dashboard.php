<?php
session_set_cookie_params(['lifetime' => 86400 * 30]);
session_start();
include("../db.php");

// Auth Gateway
if (!isset($_SESSION['delivery_id'])) {
    header("Location: login.php");
    exit();
}

$rider_id = $_SESSION['delivery_id'];
$rider_name = $_SESSION['delivery_name'];

$message = isset($_GET['message']) ? $_GET['message'] : "";
$active_orders_res = $conn->query("SELECT COUNT(*) as total FROM orders WHERE order_status IN ('Pending', 'Preparing')");
$simulate_alert = false;
$simulated_otp = "";

// Handle Actions (Accept Order / Initiate Delivery / Withdraw)
if (isset($_POST['action'])) {

    // Removed pickup action, handled by pickup_order.php

    if ($_POST['action'] == 'accept' && isset($_POST['order_id'])) {
        $order_id = intval($_POST['order_id']);

        // Block double-accepts
        $active_check = $conn->query("SELECT order_id FROM orders WHERE delivery_person_id='$rider_id' AND order_status != 'Delivered' AND order_status != 'Cancelled'");

        if ($active_check->num_rows > 0) {
            $message = "🚫 Request Denied: You must deliver your current order before accepting a new one!";
        } else {
            $check = $conn->query("SELECT delivery_person_id FROM orders WHERE order_id='$order_id'");
            $row = $check->fetch_assoc();
            if (is_null($row['delivery_person_id'])) {
                $conn->query("UPDATE orders SET delivery_person_id='$rider_id', delivery_status='Accepted', order_status='Preparing' WHERE order_id='$order_id'");
                $message = "Order #$order_id successfully claimed! Proceed to Restaurant for Pick Up.";

                // Get customer_id for notification
                $cust_q = $conn->query("SELECT customer_id FROM orders WHERE order_id='$order_id'");
                if ($cust_q && $cust_q->num_rows > 0) {
                    $cust_data = $cust_q->fetch_assoc();
                    $customer_id = $cust_data['customer_id'] ?? null;
                    if ($customer_id) {
                        addNotification($conn, $customer_id, 'customer', "A rider has been assigned to your order and is heading to the kitchen!", $order_id);
                    }
                }
            } else {
                $message = "Order already claimed by another rider.";
            }
        }
    }

    if ($_POST['action'] == 'deliver' && isset($_POST['order_id'])) {
        $order_id = intval($_POST['order_id']);

        // Generate OTP Security Key
        $otp = rand(100000, 999999);
        $conn->query("UPDATE orders SET delivery_otp='$otp' WHERE order_id='$order_id'");

        // Get customer email
        $cust_q = $conn->query("SELECT customers.email FROM orders JOIN customers ON orders.customer_id = customers.customer_id WHERE orders.order_id='$order_id'");
        if($cust_q->num_rows > 0) {
            $cust_email = $cust_q->fetch_assoc()['email'];

            // Send OTP
            $subject = "Delivery OTP - FOODIE'S HEAVEN #$order_id";
            $body = "Your Rider is at the door!\n\nProvide them with this One Time Password to accept your food: $otp\n\nEnjoy your meal!";
            $headers = "From: security@foodiesheaven.com";

            // Try sending email. For local testing, we also trigger a JS alert if sendmail fails.
            $mail_sent = @mail($cust_email, $subject, $body, $headers);

            if(!$mail_sent) {
                $simulate_alert = true;
                $simulated_otp = $otp;
            }
        } else {
            // Customer mail not found, fallback alert
            $simulate_alert = true;
            $simulated_otp = $otp;
        }

        if(!$simulate_alert) {
             header("Location: verify_delivery.php?order_id=$order_id");
             exit();
        }
    }

    if ($_POST['action'] == 'withdraw') {
        $rider_check = $conn->query("SELECT bank_name, account_number FROM delivery_person WHERE id='$rider_id'");
        $r_data = $rider_check->fetch_assoc();

        if(empty($r_data['bank_name']) || empty($r_data['account_number'])) {
            $message = "Error: Please securely configure your Bank details in the Wallet module first.";
        } else {
            $wb_q = $conn->query("SELECT wallet_balance FROM delivery_person WHERE id='$rider_id'");
            $amt = (float)$wb_q->fetch_assoc()['wallet_balance'];
            if ($amt > 0) {
                $bn = $conn->real_escape_string($r_data['bank_name']);
                $an = $conn->real_escape_string($r_data['account_number']);
                $conn->query("INSERT INTO rider_withdrawals (rider_id, amount, bank_name, account_number, status) VALUES ('$rider_id', '$amt', '$bn', '$an', 'Processing')");
                $conn->query("UPDATE delivery_person SET wallet_balance = 0.00 WHERE id='$rider_id'");
                $message = "Withdrawal Executed! &#8377;$amt routing to " . htmlspecialchars($r_data['bank_name']) . " ending in *" . substr($r_data['account_number'], -4);
            } else {
                $message = "Error: Insufficient funds to withdraw.";
            }
        }
    }
}

// Fetch Wallet Balance
$wallet_q = $conn->query("SELECT wallet_balance FROM delivery_person WHERE id='$rider_id'");
$wallet_balance = ($wallet_q && $wallet_q->num_rows > 0) ? (float)$wallet_q->fetch_assoc()['wallet_balance'] : 0.00;

// Fetch Active Pool (Unclaimed Orders marked 'Preparing' by Admin)
$pool_query = "SELECT * FROM orders WHERE delivery_person_id IS NULL AND order_status='Preparing' ORDER BY order_date DESC";
$pool_result = $conn->query($pool_query);

// --- UPDATED FOR TRANSIT LOGIC ---
// Fetch My Assigned Tasks (Includes orders that are 'Out for Delivery' or 'In Transit')
$my_tasks_query = "SELECT * FROM orders WHERE delivery_person_id='$rider_id'
                   AND order_status IN ('Preparing', 'Out for Delivery', 'In Transit')
                   ORDER BY order_date DESC";
$my_tasks_result = $conn->query($my_tasks_query);
// ---------------------------------

// Fetch Delivery Stats
$stats = $conn->query("SELECT COUNT(*) as total_done FROM orders WHERE delivery_person_id='$rider_id' AND order_status='Delivered'")->fetch_assoc();
$total_delivered = $stats['total_done'] ?? 0;

// Fetch Completed Tasks
$completed_tasks_query = "SELECT * FROM orders WHERE delivery_person_id='$rider_id' AND order_status='Delivered' ORDER BY order_date DESC LIMIT 50";
$completed_tasks_result = $conn->query($completed_tasks_query);

// Fetch Withdrawal History
$history_query = $conn->query("SELECT * FROM rider_withdrawals WHERE rider_id='$rider_id' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fleet Dashboard | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #020617 0%, #0f172a 100%);
            color: #e2e8f0;
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.6);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .glass-card:hover { border-color: rgba(249, 115, 22, 0.3); transform: translateY(-3px); box-shadow: 0 10px 30px -10px rgba(0,0,0,0.5); }
        .tab-btn.active { background: #f97316; color: white; border-color: #f97316; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-thumb { background: #f97316; border-radius: 10px; }
    </style>
</head>
<body class="min-h-screen pb-20">

    <?php if($simulate_alert): ?>
    <script>
        alert("🔒 SYSTEM BYPASS: OTP generated is <?=$simulated_otp?>.\n(Since mail configuration fails locally, we display it to verify the system works).");
        window.location.href = "verify_delivery.php?order_id=<?=$_POST['order_id']?>";
    </script>
    <?php endif; ?>

    <!-- Top Navigation -->
    <nav class="sticky top-0 z-50 bg-[#020617]/90 backdrop-blur-md border-b border-slate-800 px-6 py-4 flex justify-between items-center shadow-2xl">
        <div class="flex items-center gap-3">
            <div class="bg-orange-500 w-10 h-10 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
                <i data-lucide="truck" class="text-white w-5 h-5"></i>
            </div>
            <div>
                <h1 class="font-900 tracking-tight text-white uppercase italic leading-none">Fleet Control</h1>
                <p class="text-[10px] uppercase tracking-widest text-orange-500 font-bold mt-1">Live Tracking</p>
            </div>
        </div>

        <div class="flex items-center gap-4">
            <div class="hidden md:flex flex-col text-right">
                <span class="text-sm font-bold text-white"><?= htmlspecialchars($rider_name) ?></span>
                <span class="text-[10px] text-emerald-400 font-black uppercase tracking-widest flex items-center gap-1 justify-end"><div class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div> Online</span>
            </div>
            <a href="bank_details.php" class="bg-slate-800 hover:bg-orange-500/20 text-slate-400 hover:text-orange-400 transition-colors w-10 h-10 rounded-xl flex items-center justify-center relative group" title="Bank Details">
                <i data-lucide="landmark" class="w-5 h-5"></i>
            </a>
            <a href="profile.php" class="bg-slate-800 hover:bg-blue-500/20 text-slate-400 hover:text-blue-400 transition-colors w-10 h-10 rounded-xl flex items-center justify-center relative group" title="My Profile">
                <i data-lucide="user-cog" class="w-5 h-5"></i>
            </a>
            <a href="logout.php" class="bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition-colors w-10 h-10 rounded-xl flex items-center justify-center" title="Log Out">
                <i data-lucide="power" class="w-5 h-5"></i>
            </a>
        </div>
    </nav>

    <main class="max-w-6xl mx-auto px-4 mt-8">

        <?php if($message): ?>
            <div class="mb-8 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-3 text-emerald-400 text-sm font-semibold capitalize animate-bounce">
                <i data-lucide="check-circle" class="w-5 h-5"></i>
                <?= $message ?>
            </div>
        <?php endif; ?>

        <!-- Notifications Card -->
        <?php
        $rider_notif_q = $conn->query("SELECT * FROM notifications WHERE user_type='delivery' AND is_read=0 ORDER BY created_at DESC LIMIT 20");
        if ($rider_notif_q->num_rows > 0):
        ?>
        <div class="mb-10 bg-gradient-to-br from-indigo-600 to-blue-700 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group border border-white/10">
            <div class="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div class="relative z-10 flex items-center justify-between">
                <div class="flex items-center gap-6">
                    <div class="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center text-white border border-white/20 shadow-inner">
                        <i data-lucide="bell" class="w-7 h-7 animate-bounce"></i>
                    </div>
                    <div>
                        <h2 class="text-white text-2xl font-900 tracking-tighter uppercase italic">Logistics Alert Feed</h2>
                        <p class="text-white/70 text-[10px] font-bold uppercase tracking-widest mt-1">Real-time Network Updates</p>
                    </div>
                </div>
                <a href="../clear_notifications.php?type=delivery" class="bg-white text-blue-700 px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest hover:scale-105 transition-all shadow-lg active:scale-95">Clear Alerts</a>
            </div>
            <div class="mt-8 space-y-3 max-h-[260px] overflow-y-auto custom-scrollbar pr-2">
                <?php while($n = $rider_notif_q->fetch_assoc()): ?>
                <a href="dashboard.php" onclick="switchTab('pool'); return true;" class="block bg-white/10 border border-white/10 p-4 rounded-2xl backdrop-blur-md group/item hover:bg-white/20 transition-all cursor-pointer">
                    <div class="flex items-center justify-between w-full">
                        <div class="flex items-center gap-4">
                            <span class="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
                            <p class="text-white font-bold text-sm"><?= htmlspecialchars($n['message']) ?></p>
                        </div>
                        <span class="text-white/50 text-[10px] font-black uppercase tracking-widest"><?= date('h:i A', strtotime($n['created_at'])) ?></span>
                    </div>
                </a>
                <?php endwhile; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Stats Overview -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
            <div class="glass-card rounded-[2rem] p-6 text-center">
                <i data-lucide="package" class="w-8 h-8 mx-auto text-blue-400 mb-3 opacity-80"></i>
                <h3 class="text-3xl font-900 text-white"><?= $my_tasks_result->num_rows ?></h3>
                <p class="text-[10px] uppercase tracking-widest font-bold text-slate-500 mt-1">Active Runs</p>
            </div>
            <div class="glass-card rounded-[2rem] p-6 text-center">
                <i data-lucide="check-square" class="w-8 h-8 mx-auto text-emerald-400 mb-3 opacity-80"></i>
                <h3 class="text-3xl font-900 text-white"><?= $total_delivered ?></h3>
                <p class="text-[10px] uppercase tracking-widest font-bold text-slate-500 mt-1">Lifetime Drops</p>
            </div>
            <div class="glass-card rounded-[2rem] p-6 text-center relative overflow-hidden flex flex-col items-center justify-center">
                <div class="absolute inset-0 bg-blue-500/5 pointer-events-none"></div>
                <h3 class="text-3xl font-900 text-emerald-400 drop-shadow-[0_0_15px_rgba(52,211,153,0.3)]">&#8377;<?= number_format($wallet_balance, 2) ?></h3>
                <p class="text-[10px] uppercase tracking-widest font-bold text-slate-500 mt-1 mb-3">Wallet Balance</p>
                <?php if($wallet_balance > 0): ?>
                    <form method="POST">
                        <input type="hidden" name="action" value="withdraw">
                        <button type="submit" onclick="return confirm('Withdraw &#8377;<?= number_format($wallet_balance, 2) ?> to your bank account with 0% fee?');" class="bg-blue-500 hover:bg-blue-400 text-white text-[9px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full transition-colors shadow-md shadow-blue-500/20">Withdraw</button>
                    </form>
                <?php else: ?>
                    <button disabled class="bg-slate-800 text-slate-500 text-[9px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full cursor-not-allowed">Withdraw</button>
                <?php endif; ?>
            </div>
            <div class="glass-card rounded-[2rem] p-6 text-center">
                <i data-lucide="radar" class="w-8 h-8 mx-auto text-orange-400 mb-3 opacity-80"></i>
                <h3 class="text-3xl font-900 text-white"><?= $pool_result->num_rows ?></h3>
                <p class="text-[10px] uppercase tracking-widest font-bold text-slate-500 mt-1">Available Pool</p>
            </div>
        </div>

        <!-- Terminal Tabs -->
        <div class="flex flex-wrap gap-4 mb-8">
            <button onclick="switchTab('active')" id="btn-active" class="tab-btn active flex-1 md:flex-none border border-slate-700 font-bold text-sm px-6 py-3 rounded-xl transition-all uppercase tracking-widest">My Routes (<?= $my_tasks_result->num_rows ?>)</button>
            <button onclick="switchTab('pool')" id="btn-pool" class="tab-btn flex-1 md:flex-none border border-slate-700 bg-slate-800 text-slate-400 font-bold text-sm px-6 py-3 rounded-xl transition-all uppercase tracking-widest">Available (<?= $pool_result->num_rows ?>)</button>
            <button onclick="switchTab('completed')" id="btn-completed" class="tab-btn flex-1 md:flex-none border border-slate-700 bg-slate-800 text-slate-400 font-bold text-sm px-6 py-3 rounded-xl transition-all uppercase tracking-widest">Completed (<?= $total_delivered ?>)</button>
            <button onclick="switchTab('withdrawals')" id="btn-withdrawals" class="tab-btn flex-1 md:flex-none border border-slate-700 bg-slate-800 text-slate-400 font-bold text-sm px-6 py-3 rounded-xl transition-all uppercase tracking-widest">Payouts (<?= $history_query->num_rows ?>)</button>
        </div>

        <!-- ACTIVE TASKS SECTION -->
        <div id="tab-active" class="space-y-6">
            <?php if($my_tasks_result->num_rows == 0): ?>
                <div class="text-center py-20 glass-card rounded-[3rem]">
                    <i data-lucide="map" class="w-16 h-16 text-slate-600 mx-auto mb-4"></i>
                    <h2 class="text-xl font-800 text-slate-400 uppercase tracking-widest">No Active Routes</h2>
                    <p class="text-slate-600 mt-2 text-sm">Check the Available Pool to accept orders.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <?php while($order = $my_tasks_result->fetch_assoc()): ?>
                        <div class="glass-card rounded-[2.5rem] p-8 relative overflow-hidden">
                            <div class="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>

                            <div class="flex justify-between items-start mb-6">
                                <div>
                                    <span class="bg-orange-500/20 text-orange-400 text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full border border-orange-500/30">Dispatch Route</span>
                                    <h3 class="text-2xl font-800 text-white mt-3"><?= htmlspecialchars($order['customer_name']) ?></h3>
                                </div>
                                <h2 class="text-3xl font-900 text-orange-400 tracking-tighter">&#8377;<?= number_format(calculateRiderEarning($conn, $order['order_id']), 2) ?></h2>
                            </div>

                            <div class="bg-slate-900/50 p-5 rounded-2xl mb-6 space-y-4 border border-slate-800/80">
                                <div class="flex items-start gap-3">
                                    <i data-lucide="map-pin" class="w-5 h-5 text-red-400 mt-0.5 shrink-0"></i>
                                    <p class="text-slate-300 text-sm leading-relaxed"><?= htmlspecialchars($order['address']) ?> <br><span class="text-slate-500 text-xs">PIN: <?= htmlspecialchars($order['pincode'] ?? 'N/A') ?></span></p>
                                </div>
                                <div class="flex items-center gap-3">
                                    <i data-lucide="phone" class="w-5 h-5 text-emerald-400 shrink-0"></i>
                                    <a href="tel:<?= htmlspecialchars($order['phone']) ?>" class="text-white font-bold hover:text-emerald-400 transition-colors"><?= htmlspecialchars($order['phone']) ?></a>
                                </div>
                                <div class="flex items-center gap-3">
                                    <i data-lucide="credit-card" class="w-5 h-5 text-blue-400 shrink-0"></i>
                                    <span class="text-slate-300 uppercase tracking-widest text-[10px] font-black"><?= htmlspecialchars($order['payment_method']) ?></span>
                                </div>

                                <?php
                                $oid = $order['order_id'];
                                $items_q = $conn->query("SELECT oi.quantity, f.food_name, f.description FROM order_items oi JOIN food_items f ON oi.food_id = f.food_id WHERE oi.order_id='$oid'");
                                if($items_q->num_rows > 0):
                                ?>
                                <div class="border-t border-slate-700/50 pt-4 mt-4">
                                    <p class="text-[10px] text-orange-400 font-black uppercase tracking-widest mb-3">Customer Order Contents</p>
                                    <ul class="space-y-3">
                                        <?php while($itm = $items_q->fetch_assoc()): ?>
                                            <li class="flex gap-3">
                                                <span class="text-slate-900 font-bold bg-orange-400 px-2.5 py-1 rounded-lg text-[10px] h-fit leading-none mt-0.5"><?= $itm['quantity'] ?>x</span>
                                                <div>
                                                    <p class="text-white font-bold text-sm leading-tight"><?= htmlspecialchars($itm['food_name']) ?></p>
                                                    <?php if(!empty($itm['description'])): ?>
                                                    <p class="text-slate-400 text-xs leading-relaxed mt-1 opacity-80 italic line-clamp-2"><?= htmlspecialchars($itm['description']) ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </li>
                                        <?php endwhile; ?>
                                    </ul>
                                </div>
                                <?php endif; ?>

                            </div>

                            <?php if ($order['order_status'] == 'Preparing'): ?>
                                <a href="pickup_order.php?order_id=<?= $order['order_id'] ?>"
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-900 uppercase tracking-widest text-xs py-4 rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.2)] transition-all flex items-center justify-center gap-2">
                                    Proceed to Pick Up <i data-lucide="map-pin" class="w-4 h-4 text-blue-300"></i>
                                </a>
                            <?php else: ?>
                                <form method="POST">
                                    <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                                    <input type="hidden" name="action" value="deliver">
                                    <button type="submit" onclick="return confirm('You are arriving at the destination. We will send an OTP array to the customer. Proceed?');"
                                        class="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-900 uppercase tracking-widest text-xs py-4 rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.2)] transition-all flex items-center justify-center gap-2">
                                        Order Delivered <i data-lucide="shield-check" class="w-4 h-4"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- AVAILABLE POOL SECTION -->
        <div id="tab-pool" class="hidden space-y-6">
            <?php if($pool_result->num_rows == 0): ?>
                <div class="text-center py-20 glass-card rounded-[3rem]">
                    <i data-lucide="coffee" class="w-16 h-16 text-slate-600 mx-auto mb-4"></i>
                    <h2 class="text-xl font-800 text-slate-400 uppercase tracking-widest">No Pending Orders</h2>
                    <p class="text-slate-600 mt-2 text-sm">Take a break. The pool is empty right now.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 gap-4">
                    <?php while($order = $pool_result->fetch_assoc()): ?>
                        <div class="glass-card rounded-[2rem] p-6 lg:p-8 flex flex-col md:flex-row items-center justify-between gap-6">

                            <div class="flex-1 w-full text-center md:text-left">
                                <div class="flex items-center gap-3 justify-center md:justify-start mb-2">
                                    <span class="bg-blue-500/20 text-blue-400 text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full border border-blue-500/30">Delivery Job</span>
                                    <span class="text-slate-500 text-[10px] font-bold uppercase tracking-widest"><i data-lucide="clock" class="w-3 h-3 inline pb-0.5"></i> <?= date('h:i A', strtotime($order['order_date'])) ?></span>
                                </div>
                                <h3 class="text-xl font-800 text-white"><?= htmlspecialchars($order['customer_name']) ?> <span class="text-slate-500 font-medium text-sm ml-2">- <?= htmlspecialchars($order['address']) ?></span></h3>
                            </div>

                            <div class="text-center md:text-right w-full md:w-auto">
                                <h2 class="text-2xl font-900 text-orange-400 tracking-tighter mb-2">&#8377;<?= number_format(calculateRiderEarning($conn, $order['order_id']), 2) ?></h2>
                                <span class="block text-[10px] uppercase font-black tracking-[0.2em] text-slate-500 mb-4"><?= htmlspecialchars($order['payment_method']) ?></span>

                                <?php
                                $oid = $order['order_id'];
                                $items_q = $conn->query("SELECT oi.quantity, f.food_name, f.description FROM order_items oi JOIN food_items f ON oi.food_id = f.food_id WHERE oi.order_id='$oid'");
                                if($items_q->num_rows > 0):
                                ?>
                                <div class="text-left bg-slate-800/50 p-4 rounded-xl mb-4 text-xs">
                                    <p class="text-[9px] text-orange-400 font-black uppercase tracking-widest mb-2 border-b border-slate-700 pb-1">Order Details</p>
                                    <ul class="space-y-2">
                                        <?php while($itm = $items_q->fetch_assoc()): ?>
                                            <li>
                                                <span class="text-orange-400 font-black mr-1"><?= $itm['quantity'] ?>x</span> <span class="text-slate-300 font-bold"><?= htmlspecialchars($itm['food_name']) ?></span>
                                                <?php if(!empty($itm['description'])): ?>
                                                <p class="text-slate-500 text-[10px] mt-0.5 line-clamp-1 pl-4 italic"><?= htmlspecialchars($itm['description']) ?></p>
                                                <?php endif; ?>
                                            </li>
                                        <?php endwhile; ?>
                                    </ul>
                                </div>
                                <?php endif; ?>

                                <form method="POST">
                                    <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                                    <input type="hidden" name="action" value="accept">
                                    <button type="submit" class="w-full md:w-auto bg-orange-500 hover:bg-orange-600 text-white font-900 uppercase tracking-widest text-[10px] py-3 px-8 rounded-xl shadow-[0_0_20px_rgba(249,115,22,0.3)] transition-all">
                                        Accept Route
                                    </button>
                                </form>
                            </div>

                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- COMPLETED TASKS SECTION -->
        <div id="tab-completed" class="hidden space-y-6">
            <?php if($completed_tasks_result->num_rows == 0): ?>
                <div class="text-center py-20 glass-card rounded-[3rem]">
                    <i data-lucide="check-circle" class="w-16 h-16 text-slate-600 mx-auto mb-4"></i>
                    <h2 class="text-xl font-800 text-slate-400 uppercase tracking-widest">No Completed Logs</h2>
                    <p class="text-slate-600 mt-2 text-sm">Your delivery history will appear here once you drop off packages.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <?php while($order = $completed_tasks_result->fetch_assoc()): ?>
                        <div class="glass-card rounded-[2.5rem] p-8 relative overflow-hidden border-emerald-500/20">
                            <div class="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>

                            <div class="flex justify-between items-start mb-6 border-b border-slate-800 pb-5">
                                <div>
                                    <span class="bg-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full border border-emerald-500/30">Completed Drop</span>
                                    <h3 class="text-2xl font-800 text-white mt-3"><?= htmlspecialchars($order['customer_name']) ?></h3>
                                    <p class="text-slate-500 text-xs font-bold mt-1"><i data-lucide="clock" class="w-3 h-3 inline"></i> Delivered <?= date('d M, h:i A', strtotime($order['order_date'])) ?></p>
                                </div>
                                <h2 class="text-3xl font-900 text-emerald-400 tracking-tighter">&#8377;<?= number_format(calculateRiderEarning($conn, $order['order_id']), 2) ?></h2>
                            </div>

                            <div class="flex items-start gap-3 mb-2">
                                <i data-lucide="map-pin" class="w-5 h-5 text-slate-500 mt-0.5 shrink-0"></i>
                                <p class="text-slate-400 text-sm leading-relaxed"><?= htmlspecialchars($order['address']) ?></p>
                            </div>
                            <div class="flex items-center gap-3">
                                <i data-lucide="credit-card" class="w-5 h-5 text-blue-400 shrink-0"></i>
                                <span class="text-slate-300 uppercase tracking-widest text-[10px] font-black"><?= htmlspecialchars($order['payment_method']) ?></span>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- WITHDRAWALS SECTION -->
        <div id="tab-withdrawals" class="hidden space-y-6">
            <?php if ($history_query->num_rows == 0): ?>
                <div class="text-center py-20 glass-card rounded-[3rem]">
                    <i data-lucide="folder-open" class="w-16 h-16 text-slate-600 mx-auto mb-4"></i>
                    <h2 class="text-xl font-800 text-slate-400 uppercase tracking-widest">No Payouts Yet</h2>
                    <p class="text-slate-600 mt-2 text-sm">Your withdrawal history will appear here once processed by Admin.</p>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php while($hx = $history_query->fetch_assoc()): ?>
                    <div class="glass-card border border-slate-800 hover:border-orange-500/30 p-6 rounded-[2.5rem] flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all">
                        <div class="flex items-center gap-5">
                            <div class="w-14 h-14 bg-slate-800/80 rounded-2xl flex items-center justify-center text-slate-400 border border-slate-700 shadow-inner">
                                <i data-lucide="<?= $hx['status'] == 'Completed' ? 'check-circle' : 'clock' ?>" class="<?= $hx['status'] == 'Completed' ? 'text-emerald-500' : 'text-orange-500' ?> w-6 h-6"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-900 text-2xl tracking-tight">&#8377;<?= number_format($hx['amount'], 2) ?></h4>
                                <p class="text-[10px] font-bold text-slate-500 tracking-widest uppercase mt-1">
                                    <?= htmlspecialchars($hx['bank_name']) ?> <span class="text-slate-600">(*<?= substr($hx['account_number'], -4) ?>)</span>
                                </p>
                            </div>
                        </div>
                        <div class="text-right flex flex-col items-end border-t border-slate-800 md:border-none pt-4 md:pt-0">
                            <span class="px-4 py-1.5 text-[9px] font-black uppercase tracking-widest rounded-lg <?= $hx['status'] == 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-orange-500/10 text-orange-400 border border-orange-500/20' ?>">
                                <?= $hx['status'] ?>
                            </span>
                            <span class="text-[10px] text-slate-500 font-bold mt-3"><i data-lucide="clock" class="w-3 h-3 inline pb-0.5 mr-1"></i><?= date('d M Y, h:i A', strtotime($hx['created_at'])) ?></span>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>

    </main>

    <script>
        lucide.createIcons();

        function switchTab(tab) {
            document.getElementById('tab-active').classList.add('hidden');
            document.getElementById('tab-pool').classList.add('hidden');
            document.getElementById('tab-completed').classList.add('hidden');
            document.getElementById('tab-withdrawals').classList.add('hidden');

            let defClass = "tab-btn flex-1 md:flex-none border border-slate-700 bg-slate-800 text-slate-400 font-bold text-sm px-6 py-3 rounded-xl transition-all uppercase tracking-widest";

            document.getElementById('btn-active').className = defClass;
            document.getElementById('btn-pool').className = defClass;
            document.getElementById('btn-completed').className = defClass;
            document.getElementById('btn-withdrawals').className = defClass;

            document.getElementById('tab-' + tab).classList.remove('hidden');
            document.getElementById('btn-' + tab).className = "tab-btn active flex-1 md:flex-none border border-orange-500 bg-orange-500 text-white font-bold text-sm px-6 py-3 rounded-xl transition-all uppercase tracking-widest";
        }
    </script>

    <?php if ($simulate_alert): ?>
    <script>
        alert("SIMULATION: OTP Gen triggered!\n\nEmail sending failed (typical in Localhost).\nOTP for this order is: <?= $simulated_otp ?>");
        window.location.href = "verify_delivery.php?order_id=<?= $order_id ?>";
    </script>
    <?php endif; ?>
</body>
</html>