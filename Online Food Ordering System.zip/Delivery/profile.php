<?php
session_set_cookie_params(['lifetime' => 86400 * 30]);
session_start();
include("../db.php");

// Auth Gateway
if (!isset($_SESSION['delivery_id'])) {
    header("Location: login.php");
    exit();
}

$rider_id = $_SESSION['delivery_id'];
$message_profile = "";
$message_security = "";
$error_security = "";
$error_profile = "";

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $vehicle_type = $conn->real_escape_string($_POST['vehicle_type']);
    $vehicle_number = strtoupper($conn->real_escape_string($_POST['vehicle_number']));

    // Check if email or phone is taken by another rider
    $check = $conn->query("SELECT id FROM delivery_person WHERE (email='$email' OR phone='$phone') AND id != '$rider_id'");
    if ($check->num_rows > 0) {
        $error_profile = "Another rider is already using this Email or Phone number.";
    } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        $error_profile = "Invalid name! Only alphabets and spaces are allowed.";
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $error_profile = "Invalid phone number! Please enter exactly 10 digits.";
    } else {
        $query = "UPDATE delivery_person SET name='$name', email='$email', phone='$phone', vehicle_type='$vehicle_type', vehicle_number='$vehicle_number' WHERE id='$rider_id'";
        if ($conn->query($query)) {
            $_SESSION['delivery_name'] = $name; // Update session name
            $message_profile = "Profile configuration successfully routed and saved!";
        } else {
            $error_profile = "Database integrity fault. Could not update profile.";
        }
    }
}

// Handle Security Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Verify current password
    $stmt = $conn->prepare("SELECT password FROM delivery_person WHERE id=?");
    $stmt->bind_param("i", $rider_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $db_pass = $res->fetch_assoc()['password'];

    // In this system, passwords are plain-text as defined by register.php
    if ($current_password !== $db_pass) {
        $error_security = "Access Denied: The current password you entered is incorrect.";
    } elseif ($new_password !== $confirm_password) {
        $error_security = "Validation Fault: The new passwords do not match.";
    } else {
        // Strict Password Regex matching the overall system
        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/';
        if (!preg_match($pattern, $new_password)) {
            $error_security = "Security Policy: Password requires 8-16 chars, Uppercase, Lowercase, Number & Special Char.";
        } else {
            // Update to new password
            $update_stmt = $conn->prepare("UPDATE delivery_person SET password=? WHERE id=?");
            $update_stmt->bind_param("si", $new_password, $rider_id);
            if ($update_stmt->execute()) {
                $message_security = "Master Key updated and securely encrypted.";
            } else {
                $error_security = "System Database Fault. Security key unassigned.";
            }
        }
    }
}

// Fetch Current Data
$rider_query = $conn->query("SELECT name, email, phone, vehicle_type, vehicle_number FROM delivery_person WHERE id='$rider_id'");
$rider = $rider_query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pilot Profile | FOODIE'S HEAVEN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #020617 0%, #0f172a 100%);
            color: #e2e8f0;
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.6);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            box-shadow: 0 20px 40px -10px rgba(0,0,0,0.5);
        }
        .input-dark {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            transition: all 0.3s ease;
        }
        .input-dark:focus {
            border-color: #3b82f6; /* Blue focus for profile */
            outline: none;
            box-shadow: 0 0 15px rgba(59, 130, 246, 0.2);
            background: rgba(15, 23, 42, 0.9);
        }
        .input-security:focus {
            border-color: #ef4444; /* Red focus for security */
            outline: none;
            box-shadow: 0 0 15px rgba(239, 68, 68, 0.2);
        }
    </style>
</head>
<body class="min-h-screen py-10 px-4">

    <!-- Top Navigation -->
    <nav class="max-w-4xl mx-auto mb-10 flex justify-between items-center">
        <a href="dashboard.php" class="text-slate-400 hover:text-blue-500 font-bold text-sm flex items-center gap-2 transition-colors">
            <i data-lucide="arrow-left" class="w-4 h-4"></i> Return to Fleet Dashboard
        </a>
        <div class="flex flex-col text-right">
            <span class="text-sm font-bold text-white"><?= htmlspecialchars($_SESSION['delivery_name']) ?></span>
            <span class="text-[10px] text-emerald-400 font-black uppercase tracking-widest flex items-center gap-1 justify-end"><div class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div> Local Authenticated</span>
        </div>
    </nav>

    <main class="max-w-4xl mx-auto space-y-10">

        <!-- Header Banner -->
        <div class="flex items-center gap-5 border-b border-slate-800 pb-8">
            <div class="w-16 h-16 rounded-2xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20 shadow-inner">
                <i data-lucide="user-cog" class="w-8 h-8 text-blue-500"></i>
            </div>
            <div>
                <h1 class="text-3xl font-900 text-white italic tracking-tighter uppercase">Operations <span class="text-blue-500">Profile</span></h1>
                <p class="text-[11px] font-black tracking-widest uppercase text-slate-500 mt-1">Configure your personal and security parameters</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <!-- Profile Details Section -->
            <div class="glass-card rounded-[2.5rem] p-8 md:p-10 relative overflow-hidden">
                <div class="absolute -top-40 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none"></div>

                <h2 class="text-xl font-800 text-white tracking-tight uppercase border-b border-slate-700/50 pb-4 mb-6 flex items-center gap-3">
                    <i data-lucide="contact" class="w-5 h-5 text-blue-400"></i> Personnel Data
                </h2>

                <?php if($message_profile): ?>
                    <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-3 text-emerald-400 text-xs font-semibold shadow-lg">
                        <i data-lucide="check-circle" class="w-5 h-5 flex-shrink-0"></i> <?= $message_profile ?>
                    </div>
                <?php endif; ?>
                <?php if($error_profile): ?>
                    <div class="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center gap-3 text-red-400 text-xs font-semibold shadow-lg">
                        <i data-lucide="alert-triangle" class="w-5 h-5 flex-shrink-0"></i> <?= $error_profile ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6 relative z-10">
                    <div class="space-y-2">
                        <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">Full Legal Name</label>
                        <div class="relative">
                            <i data-lucide="user" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="text" name="name" value="<?= htmlspecialchars($rider['name'] ?? '') ?>" required oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');" class="w-full input-dark rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold placeholder-slate-600">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">Email Address</label>
                            <div class="relative">
                                <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                                <input type="email" name="email" value="<?= htmlspecialchars($rider['email'] ?? '') ?>" required class="w-full input-dark rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold placeholder-slate-600">
                            </div>
                        </div>
                        <div class="space-y-2">
                            <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">Phone Number</label>
                            <div class="relative">
                                <i data-lucide="phone" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                                <input type="tel" name="phone" value="<?= htmlspecialchars($rider['phone'] ?? '') ?>" required maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');" class="w-full input-dark rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold placeholder-slate-600">
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">Vehicle Platform</label>
                            <div class="relative">
                                <i data-lucide="bike" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 z-10"></i>
                                <select name="vehicle_type" required class="w-full input-dark rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold appearance-none cursor-pointer">
                                    <option value="Motorcycle" <?= ($rider['vehicle_type'] == 'Motorcycle') ? 'selected' : '' ?>>Motorcycle</option>
                                    <option value="Scooter" <?= ($rider['vehicle_type'] == 'Scooter') ? 'selected' : '' ?>>Scooter</option>
                                    <option value="Bicycle" <?= ($rider['vehicle_type'] == 'Bicycle') ? 'selected' : '' ?>>Bicycle</option>
                                    <option value="Car" <?= ($rider['vehicle_type'] == 'Car') ? 'selected' : '' ?>>Car</option>
                                </select>
                                <i data-lucide="chevron-down" class="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none"></i>
                            </div>
                        </div>
                        <div class="space-y-2">
                            <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">License Plate No.</label>
                            <div class="relative">
                                <i data-lucide="hash" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                                <input type="text" name="vehicle_number" value="<?= htmlspecialchars($rider['vehicle_number'] ?? '') ?>" required class="w-full input-dark rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold uppercase placeholder-slate-600">
                            </div>
                        </div>
                    </div>

                    <div class="pt-4">
                        <button type="submit" name="update_profile" class="w-full py-4.5 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-black text-[10px] uppercase tracking-[0.2em] shadow-lg shadow-blue-500/20 transition-all active:scale-95 flex items-center justify-center gap-3">
                            Synchronize Identity <i data-lucide="refresh-cw" class="w-4 h-4"></i>
                        </button>
                    </div>
                </form>
            </div>

            <!-- Security Section -->
            <div class="glass-card rounded-[2.5rem] p-8 md:p-10 relative overflow-hidden border-rose-500/10 hover:border-rose-500/30">
                <div class="absolute inset-0 bg-rose-500/5 pointer-events-none opacity-50"></div>
                <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-rose-500/10 rounded-full blur-[100px] pointer-events-none"></div>

                <h2 class="text-xl font-800 text-white tracking-tight uppercase border-b border-rose-500/20 pb-4 mb-6 flex items-center gap-3 relative z-10">
                    <i data-lucide="shield-alert" class="w-5 h-5 text-rose-500"></i> Master Key Protocol
                </h2>

                <?php if($message_security): ?>
                    <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-3 text-emerald-400 text-xs font-semibold shadow-lg relative z-10">
                        <i data-lucide="check-circle" class="w-5 h-5 flex-shrink-0"></i> <?= $message_security ?>
                    </div>
                <?php endif; ?>
                <?php if($error_security): ?>
                    <div class="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center gap-3 text-red-400 text-xs font-semibold shadow-lg relative z-10">
                        <i data-lucide="shield-x" class="w-5 h-5 flex-shrink-0"></i> <?= $error_security ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6 relative z-10">
                    <div class="space-y-2">
                        <div class="flex justify-between items-center ml-2 mr-2">
                            <label class="text-[10px] uppercase font-black tracking-widest text-slate-400">Current Password</label>
                            <a href="forgot_password.php" class="text-[10px] text-rose-400 hover:text-rose-300 font-bold uppercase tracking-widest transition-colors hover:underline">Forgot?</a>
                        </div>
                        <div class="relative">
                            <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="password" name="current_password" id="cur_pass" required class="w-full input-dark input-security rounded-xl py-3.5 pl-12 pr-12 text-sm font-bold tracking-widest placeholder-slate-600">
                            <button type="button" onclick="toggleVisibility('cur_pass')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"><i data-lucide="eye" class="w-4 h-4"></i></button>
                        </div>
                    </div>

                    <div class="space-y-2 pt-2 border-t border-slate-700/50">
                        <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">New Password Request</label>
                        <div class="relative">
                            <i data-lucide="key-round" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-400"></i>
                            <input type="password" name="new_password" id="new_pass" required class="w-full input-dark input-security rounded-xl py-3.5 pl-12 pr-12 text-sm font-bold tracking-widest placeholder-slate-600">
                            <button type="button" onclick="toggleVisibility('new_pass')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"><i data-lucide="eye" class="w-4 h-4"></i></button>
                        </div>
                        <p class="text-[9px] font-bold text-slate-500 ml-2 mt-1">Requires 8-16 chars, upper/lower case, number, & special symbol.</p>
                    </div>

                    <div class="space-y-2">
                        <label class="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-2">Confirm Authorization</label>
                        <div class="relative">
                            <i data-lucide="check-circle-2" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"></i>
                            <input type="password" name="confirm_password" id="con_pass" required class="w-full input-dark input-security rounded-xl py-3.5 pl-12 pr-12 text-sm font-bold tracking-widest placeholder-slate-600">
                            <button type="button" onclick="toggleVisibility('con_pass')" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"><i data-lucide="eye" class="w-4 h-4"></i></button>
                        </div>
                    </div>

                    <div class="pt-4">
                        <button type="submit" name="update_password" onclick="return confirm('WARNING: You are about to override your core system authentication password. Proceed?');" class="w-full py-4.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-black text-[10px] uppercase tracking-[0.2em] shadow-lg shadow-rose-500/20 transition-all active:scale-95 flex items-center justify-center gap-3">
                            Override Key <i data-lucide="siren" class="w-4 h-4"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();
        function toggleVisibility(inputId) {
            const passInput = document.getElementById(inputId);
            passInput.type = (passInput.type === "password") ? "text" : "password";
        }
    </script>
</body>
</html>
