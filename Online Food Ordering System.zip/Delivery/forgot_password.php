<?php
session_set_cookie_params(['lifetime' => 86400 * 30]);
session_start();
include("../db.php");

$error = "";

if (isset($_POST['send_otp'])) {
    $email = $conn->real_escape_string($_POST['email']);

    // Verify rider email exists
    $stmt = $conn->prepare("SELECT id, name FROM delivery_person WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $otp = rand(100000, 999999);

        $_SESSION['rider_reset_email'] = $email;
        $_SESSION['rider_reset_otp'] = $otp;
        $_SESSION['rider_reset_id'] = $row['id'];

        require_once "../email_helper.php";
        $subject = "Foodie's Heaven Fleet: Password Recovery";
        $body = "<h3>Hello " . $row['name'] . ",</h3>
                 <p>Your 6-Digit Verification Code is: <strong style='font-size: 24px; color: #f97316;'> " . $otp . " </strong></p>
                 <p>Do not share this code with anyone. It is valid for this session only.</p>
                 <p>- Foodie's Heaven Fleet System</p>";
        
        sendOrderEmail($email, $subject, $body);

        echo "<script>
            alert('🔐 Local Delivery Development: OTP Code is [ " . $otp . " ].');
            window.location.href = 'verify_otp.php';
        </script>";
        exit();
    } else {
        $error = "This email address is not affiliated with any Fleet account.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fleet Recovery | FOODIE'S HEAVEN</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0f172a; overflow: hidden; }
        .mesh-bg { position: fixed; inset: 0; z-index: -1; background-image: radial-gradient(at 100% 0%, rgba(249, 115, 22, 0.15) 0, transparent 50%), radial-gradient(at 0% 100%, rgba(15, 23, 42, 1) 0, transparent 50%); }
        .input-focus:focus { box-shadow: 0 0 0 2px #f97316; border-color: #f97316; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade { animation: fadeIn 0.6s ease-out forwards; }
    </style>
</head>
<body class="antialiased text-slate-200 min-h-screen flex items-center justify-center relative">

    <div class="mesh-bg"></div>

    <div class="w-full max-w-md p-8 bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-[2.5rem] shadow-2xl relative z-10 animate-fade mx-4">

        <div class="flex justify-center mb-8">
            <div class="w-16 h-16 bg-orange-500/10 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(249,115,22,0.2)]">
                <i data-lucide="key" class="w-8 h-8 text-orange-500"></i>
            </div>
        </div>

        <div class="text-center mb-10">
            <h1 class="text-3xl font-800 text-white mb-3 tracking-tight">Security Checkpoint</h1>
            <p class="text-slate-400 text-sm leading-relaxed">Let's locate your profile. Provide your registered fleet email address to receive an authorization token.</p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-2xl mb-8 flex items-center gap-3">
                <i data-lucide="shield-alert" class="w-5 h-5 flex-shrink-0"></i>
                <span class="text-[10px] font-bold uppercase tracking-widest"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="space-y-6">
            <div>
                <label class="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 ml-1">Fleet Email</label>
                <div class="relative group">
                    <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600 group-focus-within:text-orange-500 transition-colors"></i>
                    <input type="email" name="email" required placeholder="rider@domain.com"
                           class="w-full bg-slate-950/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-white outline-none input-focus transition-all font-bold">
                </div>
            </div>

            <button type="submit" name="send_otp"
                    class="w-full bg-orange-500 hover:bg-orange-600 text-white font-900 py-4 rounded-2xl shadow-xl shadow-orange-500/20 transition-all uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-3 active:scale-[0.98]">
                Request Authorization <i data-lucide="shield-check" class="w-4 h-4"></i>
            </button>
        </form>

        <div class="mt-8 text-center border-t border-slate-800 pt-6">
            <a href="login.php" class="text-slate-500 hover:text-white text-[10px] font-bold uppercase tracking-[0.2em] transition-colors flex items-center justify-center gap-2">
                <i data-lucide="arrow-left" class="w-3 h-3"></i> Return to Authentication
            </a>
        </div>
    </div>

    <script> lucide.createIcons(); </script>
</body>
</html>
